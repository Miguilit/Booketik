/** Error page (404/403/500/503): status copy and the way-back links. */
export { ERROR_DESCRIPTIONS, ERROR_TITLES, errorPageCopy, useErrorPage } from './lib/errors';
