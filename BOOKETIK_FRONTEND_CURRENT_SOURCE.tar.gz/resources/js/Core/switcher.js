/** The theme switcher: `useThemeSwitcher()` for a header's "Themes" item. */
export { closeThemeSwitcher, openThemeSwitcher, useSwitcherOpen, useThemeSwitcher } from '../Switcher/store';
