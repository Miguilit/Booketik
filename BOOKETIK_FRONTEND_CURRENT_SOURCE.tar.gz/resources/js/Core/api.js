/** The `/api/v1` client, authenticated with the session's bearer token. */
export { createApi } from './lib/api';
