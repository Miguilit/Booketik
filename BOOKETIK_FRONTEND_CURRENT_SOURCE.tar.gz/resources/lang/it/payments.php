<?php

declare(strict_types=1);

return [
    'qris_step_1' => 'Apri un\'app che legge i codici QRIS: GoPay, DANA, OVO, ShopeePay o l\'app della tua banca.',
    'qris_step_2' => 'Scansiona il codice e controlla che l\'importo sia giusto prima di confermare.',
    'qris_step_3' => 'I tuoi biglietti vengono emessi in automatico appena il pagamento va a buon fine. Tieni aperta questa pagina.',
    'va_step_1' => 'Copia il numero del conto virtuale qui sotto.',
    'va_step_2' => 'Paga dall\'app della banca, da un ATM o dall\'internet banking entro la scadenza.',
    'va_step_3' => 'I tuoi biglietti vengono emessi in automatico appena la banca conferma il bonifico.',
    'ewallet_step_1' => 'Tocca il pulsante per aprire l\'app del tuo wallet.',
    'ewallet_step_2' => 'Controlla l\'importo, poi conferma il pagamento.',
    'ewallet_step_3' => 'Torna qui: i tuoi biglietti vengono emessi appena il pagamento va a buon fine.',
    'expired' => 'Questo codice di pagamento è scaduto. Generane uno nuovo per riprovare.',
    'pending' => 'Pagamento ricevuto. Il tuo account si aggiornerà appena la banca lo conferma.',
];
