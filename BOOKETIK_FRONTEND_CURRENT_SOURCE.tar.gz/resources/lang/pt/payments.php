<?php

declare(strict_types=1);

/*
 | Checkout instructions (Portuguese). See resources/lang/en/payments.php.
 */

return [
    'qris_step_1' => 'Abra qualquer app que leia QRIS — GoPay, DANA, OVO, ShopeePay ou o app do seu banco.',
    'qris_step_2' => 'Escaneie o código e confira se o valor está correto antes de confirmar.',
    'qris_step_3' => 'Seus ingressos são emitidos automaticamente assim que o pagamento for compensado. Mantenha esta página aberta.',
    'va_step_1' => 'Copie o número da conta virtual abaixo.',
    'va_step_2' => 'Pague pelo app do banco, caixa eletrônico ou internet banking antes do prazo.',
    'va_step_3' => 'Seus ingressos são emitidos automaticamente assim que o banco confirmar a transferência.',
    'ewallet_step_1' => 'Toque no botão para abrir o app da sua carteira digital.',
    'ewallet_step_2' => 'Confira o valor e confirme o pagamento.',
    'ewallet_step_3' => 'Volte aqui — seus ingressos são emitidos assim que o pagamento for compensado.',
    'expired' => 'Este código de pagamento expirou. Gere um novo para tentar de novo.',
    'pending' => 'Pagamento recebido. Sua conta será atualizada assim que o banco confirmar.',
];
