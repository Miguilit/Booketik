<?php

declare(strict_types=1);

return [
    'qris_step_1' => 'Abre cualquier app que escanee QRIS: GoPay, DANA, OVO, ShopeePay o la app de tu banco.',
    'qris_step_2' => 'Escanea el código y comprueba que el importe coincide antes de confirmar.',
    'qris_step_3' => 'Tus entradas se emiten automáticamente en cuanto se confirma el pago. Mantén esta página abierta.',
    'va_step_1' => 'Copia el número de cuenta virtual que aparece abajo.',
    'va_step_2' => 'Págalo desde la app de tu banco, un cajero o la banca online antes de que termine el plazo.',
    'va_step_3' => 'Tus entradas se emiten automáticamente cuando el banco confirma la transferencia.',
    'ewallet_step_1' => 'Toca el botón para abrir la app de tu cartera digital.',
    'ewallet_step_2' => 'Comprueba el importe y confirma el pago.',
    'ewallet_step_3' => 'Vuelve aquí: tus entradas se emiten en cuanto se confirma el pago.',
    'expired' => 'Este código de pago ha caducado. Genera uno nuevo para intentarlo otra vez.',
    'pending' => 'Pago recibido. Tu cuenta se actualizará en cuanto el banco lo confirme.',
];
