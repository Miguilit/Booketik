<?php

return [
    'failed' => '입력한 정보가 등록된 정보와 일치하지 않아요.',
    'password' => '비밀번호가 올바르지 않아요.',
    'throttle' => '로그인 시도가 너무 많아요. :seconds초 후 다시 시도하세요.',
];
