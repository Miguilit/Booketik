<?php

declare(strict_types=1);

return [
    'qris_step_1' => 'QRIS okutabilen herhangi bir uygulamayı aç — GoPay, DANA, OVO, ShopeePay ya da banka uygulaman.',
    'qris_step_2' => 'Kodu okut ve onaylamadan önce tutarın doğru olduğunu kontrol et.',
    'qris_step_3' => 'Ödeme onaylanınca biletlerin otomatik olarak oluşturulur. Bu sayfayı açık tut.',
    'va_step_1' => 'Aşağıdaki sanal hesap numarasını kopyala.',
    'va_step_2' => 'Son tarihten önce banka uygulamandan, ATM\'den ya da internet bankacılığından öde.',
    'va_step_3' => 'Banka havaleyi onaylayınca biletlerin otomatik olarak oluşturulur.',
    'ewallet_step_1' => 'E-cüzdan uygulamanı açmak için butona dokun.',
    'ewallet_step_2' => 'Tutarı kontrol et, sonra ödemeyi onayla.',
    'ewallet_step_3' => 'Buraya geri dön — ödeme onaylanır onaylanmaz biletlerin oluşturulur.',
    'expired' => 'Bu ödeme kodunun süresi doldu. Tekrar denemek için yeni bir kod oluştur.',
    'pending' => 'Ödeme alındı. Banka onaylar onaylamaz hesabın güncellenecek.',
];
