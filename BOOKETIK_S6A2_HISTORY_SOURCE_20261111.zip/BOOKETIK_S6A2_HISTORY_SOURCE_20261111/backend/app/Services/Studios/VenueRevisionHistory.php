<?php

declare(strict_types=1);

namespace App\Services\Studios;

use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/** Provider-only, read-only history plus append-only restore. No mutation of published revisions. */
final class VenueRevisionHistory
{
    public function __construct(private readonly StudioStore $store, private readonly VenuePublication $publication) {}

    private function access(object $provider, string $venueId): void
    {
        $this->store->ownsVenue($provider, $venueId);
    }

    public function index(object $provider, string $venueId, int $page = 1): array
    {
        $this->access($provider, $venueId);
        $page = max(1, min($page, 10000));
        $limit = 15;
        $query = DB::table('booketik_venue_layout_revisions')->where('venue_id', $venueId);
        $rows = (clone $query)->orderByDesc('revision')->offset(($page - 1) * $limit)->limit($limit + 1)
            ->get(['id', 'revision', 'plan', 'created_at']);
        $published = $this->publication->publishedLayout($venueId);
        $items = [];
        foreach ($rows->take($limit) as $row) {
            $plan = json_decode($row->plan, true, 512, JSON_THROW_ON_ERROR);
            $items[] = [
                'id' => $row->id, 'revision' => (int) $row->revision, 'created_at' => $row->created_at,
                'seat_count' => count($plan['seats'] ?? []),
                'zone_count' => count($plan['zones'] ?? []),
                'shape_count' => count($plan['geometry']['objects'] ?? []),
                'published' => $published && $published->id === $row->id,
            ];
        }
        return [
            'items' => $items, 'page' => $page, 'has_more' => $rows->count() > $limit,
            'latest_revision' => (int) ($this->store->latestLayout($venueId)?->revision ?? 0),
            'published_revision' => $published ? (int) $published->revision : null,
        ];
    }

    public function show(object $provider, string $venueId, int $revision): array
    {
        $this->access($provider, $venueId);
        abort_unless($revision >= 1 && $revision <= 10000000, 404);
        $row = DB::table('booketik_venue_layout_revisions')
            ->where('venue_id', $venueId)->where('revision', $revision)->firstOrFail();
        $published = $this->publication->publishedLayout($venueId);
        return [
            'revision' => (int) $row->revision, 'created_at' => $row->created_at,
            'published' => $published && $published->id === $row->id,
            'plan' => json_decode($row->plan, true, 512, JSON_THROW_ON_ERROR),
        ];
    }

    public function restore(object $provider, string $venueId, int $revision, int $actor, int $expected): void
    {
        $this->access($provider, $venueId);
        $source = $this->show($provider, $venueId, $revision);
        if ($revision === $expected) {
            throw ValidationException::withMessages(['revision' => 'Cette version est déjà le dernier brouillon.']);
        }
        // saveLayout checks expected_revision under the venue row lock; it always inserts a new revision.
        $this->store->saveLayout($provider, $venueId, $actor, $source['plan'], $expected);
    }
}
