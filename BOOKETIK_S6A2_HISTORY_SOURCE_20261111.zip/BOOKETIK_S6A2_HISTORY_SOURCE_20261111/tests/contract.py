from pathlib import Path
root=Path(__file__).resolve().parents[1]
ctrl=(root/'backend/app/Http/Controllers/Studios/StudioController.php').read_text()
routes=(root/'backend/routes/booketik_studios.php').read_text()
service=(root/'backend/app/Services/Studios/VenueRevisionHistory.php').read_text()
main=(root/'frontend/resources/js/Themes/civic/Pages/Dashboard/BooketikVenueManager.jsx').read_text()
layouts=(root/'frontend/resources/js/Themes/civic/components/dashboard/VenueManager/Layouts.jsx').read_text()
checks={
 'owns_venue': 'ownsVenue($provider, $venueId)' in service,
 'immutable_save': '$this->store->saveLayout(' in service,
 'concurrency': '$expected' in service and 'expected_revision' in ctrl,
 "history_page": "orderByDesc('revision')" in service,
 "history_show": "->where('revision', $revision)" in service,
 'restore_server': 'providerRevisionRestore' in ctrl,
 'restore_route': 'providerRevisionRestore' in routes,
 'auth_route': "middleware(['setLocale', 'auth'])" in routes,
 'csrf_post': "Route::post('venue-provider/venues/{venue}/revisions/{revision}/restore'" in routes,
 'read_only': 'Cache-Control' in ctrl and 'private, no-store' in ctrl,
 'history_ui': 'HistoryForVenue' in layouts,
 'preview_ui': 'RevisionPreview' in layouts,
 'compare_ui': 'comparePlans' in layouts,
 'restore_ui': 'router.post(' in layouts,
 'main_wiring': 'publications={publications}' in main and 'selectedRoom={roomId}' in main,
 'publication_unchanged': 'VenuePublication' in ctrl,
}
for key,ok in checks.items():
    print(('PASS' if ok else 'FAIL')+':'+key)
assert all(checks.values()), 'SOURCE_CONTRACT_FAIL'
