# BOOKETIK S6A2 — Historique des révisions de plans (SOURCE uniquement)

**Socle requis : S6A actif et vérifié.** Lot complémentaire sans migration SQL. Laravel 13 monolithique, Inertia/React, aucun changement des prix, stocks, paiements ou checkout.

## Fonctions

- « Configurations » affiche les versions v1…vN de chaque salle (paginées par 15) avec date, nombres de sièges, zones et formes.
- Aperçu graphique d'une ancienne version **sans possibilité de modifier**.
- Comparaison avec le dernier brouillon (sièges ajoutés, retirés, déplacés, zones, PMR, formes, scène).
- « Restaurer » exige confirmation, verrouillage optimiste de la révision et crée **une nouvelle révision**. La version publiée reste épinglée tant qu'elle n'est pas explicitement publiée à nouveau.
- Les endpoints sont accessibles uniquement au propriétaire de la salle, avec authentification, vérification email et protections CSRF de Laravel.

## Ce que ce lot n'inclut PAS

- Plusieurs configurations nommées et publiables indépendamment pour une même salle (p. ex. « Théâtre », « Cocktail »). Le schéma actuel est une série de révisions par salle : ce point exige une migration dédiée et une modification du modèle de publication, à traiter séparément.
- Le formulaire de création d'événement organisateur Eventgoo (S6B).
- L'alignement individuel des sièges (dette S5D).

## GitHub — compilation

Les archives suivantes à la racine du dépôt :
`BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz`,
`BOOKETIK_S4C_CRUD_20261111.zip`,
`BOOKETIK_S5C_GEOMETRY_SOURCE_20261111.zip`,
`BOOKETIK_S5D_AUTO_SEATING_SOURCE_20261111.zip`,
`BOOKETIK_S6A_PUBLICATION_SOURCE_20261111.zip`,
`BOOKETIK_S6A2_HISTORY_SOURCE_20261111.zip`.

Créer `.github/workflows/booketik-s6a2-history.yml` à partir de `github/booketik-s6a2-history.yml`. Le résultat sera `booketik-s6a2-history-compiled.zip`.

## Hostinger — contrôle lecture seule

Placer le ZIP S6A2 source dans `booketik.com/_private/`, puis depuis `booketik.com` :

```bash
unzip -q _private/BOOKETIK_S6A2_HISTORY_SOURCE_20261111.zip -d _private/
bash _private/BOOKETIK_S6A2_HISTORY_SOURCE_20261111/scripts/check_hostinger.sh
```

Ce script vérifie les SHA des fichiers Laravel S6A actifs et des manifestes Vite/SSR. Il n'installe **rien**. Si un composant a été modifié depuis S6A (par exemple dans un autre chantier), le préflight refuse la livraison ; ne pas neutraliser le contrôle.

**Pas de commande `--activate` dans ce kit**. Une fois le build GitHub et le préflight transmis, préparer séparément un déploiement versionné avec fusion additive et rollback vers S6A.
