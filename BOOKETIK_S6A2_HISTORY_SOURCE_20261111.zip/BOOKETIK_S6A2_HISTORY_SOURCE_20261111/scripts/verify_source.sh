#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'S6A2_SOURCE_SHA=FAIL'; exit 3; }
php -l "$KIT/backend/app/Http/Controllers/Studios/StudioController.php" >/dev/null
php -l "$KIT/backend/app/Services/Studios/VenueRevisionHistory.php" >/dev/null
php -l "$KIT/backend/routes/booketik_studios.php" >/dev/null
python3 "$KIT/tests/contract.py"
echo 'S6A2_SOURCE_TESTS=PASS'
