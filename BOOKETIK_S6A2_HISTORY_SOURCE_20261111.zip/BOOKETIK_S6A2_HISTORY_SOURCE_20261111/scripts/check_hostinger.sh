#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
DOMAIN="$(cd "$KIT/../.." && pwd -P)"
APP="$DOMAIN/eventgoo"
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'S6A2_PACKAGE_SHA=FAIL'; exit 3; }
[[ -f "$APP/artisan" && -d "$APP/public/build" && -d "$APP/bootstrap/ssr" ]] || { echo 'S6A2_APP_ROOT=FAIL'; exit 4; }
while read -r expected path; do
  if [[ "$path" == app/* || "$path" == routes/* ]]; then target="$APP/$path"; else target="$APP/$path"; fi
  [[ -f "$target" && "$(sha256sum "$target" | cut -d' ' -f1)" == "$expected" ]] || { echo "S6A2_S6A_BASELINE=FAIL FILE=$path"; exit 5; }
done < "$KIT/scripts/host_baseline.sha256"
echo 'S6A2_S6A_BASELINE=PASS'
for file in "$KIT"/backend/app/Http/Controllers/Studios/StudioController.php "$KIT"/backend/app/Services/Studios/VenueRevisionHistory.php "$KIT"/backend/routes/booketik_studios.php; do
  /opt/alt/php84/usr/bin/php -l "$file" >/dev/null || { echo 'S6A2_PHP_LINT=FAIL'; exit 6; }
done
echo 'S6A2_PHP_LINT=PASS'
echo 'S6A2_READONLY_PREFLIGHT=PASS'
echo 'DATABASE_WRITES=0'
echo 'APPLICATION_WRITES=0'
