BOOKETIK R3-B8-O4 — Guarded localisation and marketing build kit.

Build inputs: the unchanged R3-B8-O2 source TAR.GZ already at the root of your private Github build repository + this O4 ZIP.
Installs all 12 existing locale JSON dictionaries into the frontend build and adds an initial Dutch dictionary of 205 priority strings.
Preserves all old English/German/Spanish etc dictionaries; no file is removed from Laravel on this kit-only operation.
Marketing copy is updated in the PHP EventPageController payload and in the O3 inline claim panel presentation.
No payment, ticketing, subscription, database, source-import or organizer-verification changes.

This is a BUILD KIT, not a production ZIP. Do not deploy this kit to Hostinger directly.
Build through .github/workflows/booketik-o4.yml, then provide compiled artefact for separate guarded Hostinger package.

NL status: 205 translated priority labels, not a complete translation of all 3,117 Eventgoo strings.
FR: Existing 3,123-entry dictionary included in Vite build. English remains the existing native fallback.
