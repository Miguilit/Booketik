#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
INPUT="${1:?Original R3-B8-O2 frontend TAR.GZ required}"
OUT="${2:-$PWD}"
INPUT="$(cd "$(dirname "$INPUT")" && pwd -P)/$(basename "$INPUT")"
mkdir -p "$OUT"; OUT="$(cd "$OUT" && pwd -P)"
[[ "$(sha256sum "$INPUT" | cut -d' ' -f1)" == '181cbe78ccfa1668c0fb8efec4377ad0faf9980cb42bb9bc38fedb5ed361a92f' ]] || { echo 'SOURCE_ARCHIVE_SHA=FAIL'; exit 2; }
( cd "$KIT" && sha256sum -c dictionary_hashes.txt >/dev/null && sha256sum -c base_theme_hashes.txt >/dev/null ) || { echo 'KIT_HASHES=FAIL'; exit 2; }
( cd "$KIT/patch/files" && sha256sum -c "$KIT/patch/package_hashes.txt" >/dev/null ) || { echo 'PATCH_HASHES=FAIL'; exit 2; }
command -v node >/dev/null && command -v npm >/dev/null || { echo 'NODE_NPM_MISSING'; exit 2; }
node -e 'const v=process.versions.node.split(".").map(Number);if(v[0]<22||(v[0]===22&&v[1]<12))process.exit(1)' || { echo 'NODE_22_12_REQUIRED'; exit 2; }
if tar -tzf "$INPUT" | grep -Eq '(^/|(^|/)\.\.(/|$))'; then echo 'SOURCE_ARCHIVE_UNSAFE'; exit 2; fi
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
tar -xzf "$INPUT" -C "$WORK"
SRC="$WORK/source"
( cd "$SRC" && sha256sum -c "$WORK/source_sha256.txt" >/dev/null ) || { echo 'ORIGINAL_SOURCE_SHA=FAIL'; exit 2; }
( cd "$SRC" && sha256sum -c "$KIT/frontend_base_hashes.txt" >/dev/null ) || { echo 'FRONTEND_BASE_SHA=FAIL'; exit 2; }
for THEME in civic almanac marquee; do
 PATHREL="resources/js/Themes/$THEME/Pages/Site/Event.jsx"
 cp "$KIT/theme_source/$PATHREL" "$SRC/$PATHREL"
done
mkdir -p "$SRC/resources/js/Core/components" "$SRC/resources/lang"
cp "$KIT/patch/files/resources/js/Core/components/ExternalClaimInline.jsx" "$SRC/resources/js/Core/components/ExternalClaimInline.jsx"
cp "$KIT"/dictionaries/*.json "$SRC/resources/lang/"
node - "$SRC/resources/lang" <<'NODE'
const fs=require('fs'); const path=process.argv[2];
for(const k of ['fr','nl','en','de']){
 const map=JSON.parse(fs.readFileSync(`${path}/${k}.json`,'utf8'));
 if(Object.keys(map).length<(k==='nl'?150:3000)) throw new Error('LOCALE_INCOMPLETE_'+k);
}
for(const k of ['Welcome back','Create your account','Sign in','Language']){
 if(!JSON.parse(fs.readFileSync(`${path}/nl.json`,'utf8'))[k]) throw new Error('NL_UI_MISSING_'+k);
}
console.log('FR_NL_EN_DICTIONARIES=PASS');
NODE
echo '===== NPM CI ====='
( cd "$SRC" && npm ci --no-audit --no-fund )
echo '===== VITE BUILD ====='
( cd "$SRC" && npm run build )
node "$KIT/verify_manifest.mjs" "$SRC"
[[ -f "$SRC/bootstrap/ssr/ssr.js" ]] || { echo 'SSR_OUTPUT_MISSING'; exit 2; }
# Verify that locale chunks exist; a valid source file not bundled is not sufficient.
node - "$SRC/public/build/manifest.json" <<'NODE'
const fs=require('fs'); const manifest=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const entries=Object.keys(manifest);
for(const k of ['fr','nl','de']) {
 if(!entries.some(e=>e.includes(`lang/${k}.json`) || e.includes(`lang\\${k}.json`))) {
  throw Error('LOCALE_CHUNK_NOT_IN_MANIFEST_'+k);
 }
}
console.log('LOCALE_MANIFEST=PASS');
NODE
RELEASE="$WORK/release"
mkdir -p "$RELEASE/assets/public" "$RELEASE/assets/bootstrap"
cp -a "$KIT/patch" "$RELEASE/package"
cp -a "$SRC/public/build" "$RELEASE/assets/public/build"
cp -a "$SRC/bootstrap/ssr" "$RELEASE/assets/bootstrap/ssr"
( cd "$RELEASE" && find assets -type f -print0 | sort -z | xargs -0 sha256sum > asset_hashes.txt && sha256sum -c asset_hashes.txt >/dev/null )
printf 'BUILD=R3B8O4_LOCALES_PRO_PROMO\nNODE=%s\nNPM=%s\nNL_KEYS=%s\n' "$(node -v)" "$(npm -v)" "$(node -e 'console.log(Object.keys(require(process.argv[1])).length)' "$KIT/dictionaries/nl.json")" > "$RELEASE/BUILD_INFO.txt"
FILE='BOOKETIK_R3B8O4_COMPILED_FOR_HOSTINGER_20261110.tar.gz'
( cd "$WORK" && tar -czf "$OUT/$FILE" release )
( cd "$OUT" && sha256sum "$FILE" > "$FILE.sha256" )
echo 'BUILD=PASS LOCALES=FR_NL_EN SSR_FILES=PASS'
echo "ARTIFACT=$OUT/$FILE"
