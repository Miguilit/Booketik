#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
REPO="$(cd "${1:-$PWD}" && pwd -P)"
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'S4C_PACKAGE_SHA=FAIL'; exit 3; }
SOURCE="$REPO/BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz"
[[ -s "$SOURCE" ]] || { echo 'SOURCE_ARCHIVE=MISSING'; exit 4; }
DEST="$REPO/_booketik_s4c_build"
[[ ! -e "$DEST" ]] || { echo 'BUILD_DIR=ALREADY_EXISTS'; exit 5; }
mkdir -p "$DEST"
python3 - "$SOURCE" "$DEST" <<'PY'
import pathlib, sys, tarfile
src, dest = sys.argv[1:]
with tarfile.open(src, 'r:gz') as ar:
    seen = set()
    for entry in ar:
        name = entry.name
        parts = pathlib.PurePosixPath(name).parts
        if not name or name.startswith('/') or '..' in parts or entry.issym() or entry.islnk() or entry.isdev() or not (entry.isfile() or entry.isdir()):
            raise SystemExit('SOURCE_ARCHIVE=UNSAFE')
        if name in seen or any(p in ('.env','vendor','node_modules','.git') for p in parts):
            raise SystemExit('SOURCE_ARCHIVE=UNSAFE_OR_DUPLICATE')
        seen.add(name)
    ar.extractall(dest, filter='data')
PY
if [[ ! -f "$DEST/package.json" && -f "$DEST/source/package.json" ]]; then
    shopt -s dotglob nullglob
    mv "$DEST"/source/* "$DEST"/
    rmdir "$DEST/source"
    shopt -u dotglob nullglob
fi
[[ -f "$DEST/package-lock.json" && -f "$DEST/vite.config.js" && -f "$DEST/resources/js/pages.jsx" ]] || { echo 'REACT_SOURCE_LAYOUT=FAIL'; exit 6; }
python3 - "$KIT" "$DEST" <<'PY'
import pathlib, shutil, sys
kit, dest = [pathlib.Path(v) for v in sys.argv[1:]]
for root in (kit/'dependencies/s3t3-react', kit/'frontend'):
    for src in sorted(root.rglob('*')):
        if not src.is_file():
            continue
        rel = src.relative_to(root)
        dst = dest/rel
        if dst.exists() and dst.read_bytes() != src.read_bytes():
            raise SystemExit('SOURCE_DRIFT_OR_CONFLICT=' + str(rel))
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not dst.exists():
            shutil.copy2(src, dst)
print('REACT_OVERLAY=PASS')
PY
cd "$DEST"
npm ci --no-audit --no-fund
npm run build
node - <<'JS'
const fs = require('fs');
const client = JSON.parse(fs.readFileSync('public/build/manifest.json', 'utf8'));
const ssr = JSON.parse(fs.readFileSync('bootstrap/ssr/ssr-manifest.json', 'utf8'));
for (const [label, manifest] of [['CLIENT', client], ['SSR', ssr]]) {
  for (const suffix of ['/BooketikVenueManager.jsx', '/BooketikStudiosStandalone.jsx']) {
    if (!Object.keys(manifest).some(k => k.endsWith(suffix))) throw Error(label + '_MISSING_' + suffix);
  }
  console.log('S4C_' + label + '_ENTRIES=' + Object.keys(manifest).length);
}
JS
OUT="$REPO/BOOKETIK_S4C_CRUD_COMPILED_20261111.tar.gz"
tar -czf "$OUT" public/build bootstrap/ssr
(cd "$REPO" && sha256sum "$(basename "$OUT")" > "$(basename "$OUT").sha256")
echo 'S4C_REACT_BUILD=PASS'
