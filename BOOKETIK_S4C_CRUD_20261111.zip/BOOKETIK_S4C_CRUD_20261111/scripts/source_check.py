from pathlib import Path
import re
root = Path(__file__).resolve().parent.parent
controller = (root/'backend/app/Http/Controllers/Studios/StudioController.php').read_text()
routes = (root/'backend/routes/booketik_studios.php').read_text()
store = (root/'backend/app/Services/Studios/StudioStore.php').read_text()
service = (root/'backend/app/Services/Studios/VenueLifecycle.php').read_text()
assert 'public function archiveVenue' in controller
assert 'public function restoreVenue' in controller
assert 'public function searchOrganizers' in controller
assert "name('provider.venue.archive')" in routes
assert "name('provider.venue.restore')" in routes
assert "whereNull('pv.archived_at')" in store
assert "where('venue_id', $venueId)->exists()" in service
assert 'whereNotNull(\'archived_at\')' in (root/'backend/database/migrations/2026_11_11_020001_add_archive_to_booketik_provider_venues.php').read_text()
assert 'delete(' not in service
print('S4C_CRUD_CONTRACT=PASS')
