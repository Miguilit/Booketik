#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
PRIVATE="$(dirname "$KIT")"
ROOT="$(dirname "$PRIVATE")"
[[ "$PRIVATE" == */_private && -d "$ROOT/eventgoo/app" ]] || { echo 'S4C_PATH=FAIL'; exit 2; }
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'S4C_PACKAGE_SHA=FAIL'; exit 3; }
PHP=/opt/alt/php84/usr/bin/php
[[ -x "$PHP" ]] || { echo 'PHP84=MISSING'; exit 4; }
for f in "$KIT"/backend/app/Services/Studios/*.php "$KIT"/backend/app/Http/Controllers/Studios/*.php "$KIT"/backend/routes/*.php "$KIT"/backend/database/migrations/*.php; do
  "$PHP" -l "$f" >/dev/null || { echo 'PHP_LINT=FAIL'; exit 5; }
done
while IFS=$'\t' read -r path hash; do
  [[ -f "$ROOT/eventgoo/$path" ]] || { echo "S4C_SOURCE_MISSING=$path"; exit 6; }
  [[ "$(sha256sum "$ROOT/eventgoo/$path" | awk '{print $1}')" == "$hash" ]] || { echo "S4C_SOURCE_DRIFT=$path"; exit 7; }
done < "$KIT/scripts/live_source_baseline.tsv"
grep -Fq "require __DIR__.'/booketik_studios.php';" "$ROOT/eventgoo/routes/web.php" || { echo 'S4C_ROUTE_HOOK=MISSING'; exit 8; }
"$PHP" -r 'chdir($argv[1]);require "vendor/autoload.php";$app=require "bootstrap/app.php";$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();echo "S4C_BASE_TABLES=".(\Illuminate\Support\Facades\Schema::hasTable("booketik_provider_venues")?"PASS":"FAIL").PHP_EOL;echo "S4C_ARCHIVE_COLUMN=".(\Illuminate\Support\Facades\Schema::hasColumn("booketik_provider_venues","archived_at")?"PRESENT":"PENDING").PHP_EOL;' "$ROOT/eventgoo"
echo 'S4C_PREFLIGHT=PASS'
echo 'APPLICATION_WRITES=0'
echo 'DATABASE_WRITES=0'
