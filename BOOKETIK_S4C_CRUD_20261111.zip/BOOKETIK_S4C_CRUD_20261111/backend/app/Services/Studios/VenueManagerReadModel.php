<?php

declare(strict_types=1);

namespace App\Services\Studios;

use Illuminate\Support\Facades\DB;

final class VenueManagerReadModel
{
    public function forProvider(object $provider): array
    {
        $rooms = DB::table('booketik_provider_venues as pv')
            ->join('venues as v', 'v.id', '=', 'pv.venue_id')
            ->where('pv.provider_id', $provider->id)
            ->orderBy('v.name')
            ->get(['v.id', 'v.name', 'v.address_line1', 'v.city', 'v.timezone', 'pv.archived_at']);

        $ids = $rooms->pluck('id')->all();
        if ($ids === []) {
            return [
                'metrics' => [
                    'venue_count' => 0,
                    'configured_venue_count' => 0,
                    'seat_count' => 0,
                    'partner_count' => 0,
                    'archived_count' => 0,
                ],
                'rooms' => [],
            ];
        }

        $latest = DB::table('booketik_venue_layout_revisions')
            ->select('venue_id')
            ->selectRaw('MAX(revision) as latest_revision')
            ->whereIn('venue_id', $ids)
            ->groupBy('venue_id');

        $layouts = DB::table('booketik_venue_layout_revisions as r')
            ->joinSub($latest, 'lr', function ($join): void {
                $join->on('r.venue_id', '=', 'lr.venue_id')
                    ->on('r.revision', '=', 'lr.latest_revision');
            })
            ->get(['r.venue_id', 'r.revision', 'r.plan', 'r.updated_at'])
            ->keyBy('venue_id');

        $grants = DB::table('booketik_venue_grants')
            ->whereIn('venue_id', $ids)
            ->where('status', 'granted')
            ->select('venue_id')
            ->selectRaw('COUNT(*) as total')
            ->groupBy('venue_id')
            ->pluck('total', 'venue_id');

        $configured = 0;
        $seats = 0;
        $partners = 0;
        $archived = 0;
        $summary = [];

        foreach ($rooms as $room) {
            $layout = $layouts->get($room->id);
            $plan = $layout ? json_decode($layout->plan, true) : null;
            $seatCount = is_array($plan) && isset($plan['seats']) && is_array($plan['seats'])
                ? count($plan['seats']) : 0;
            $zoneCount = is_array($plan) && isset($plan['zones']) && is_array($plan['zones'])
                ? count($plan['zones']) : 0;
            $partnerCount = (int) ($grants->get($room->id) ?? 0);

            $isArchived = $room->archived_at !== null;
            $archived += $isArchived ? 1 : 0;
            if (!$isArchived) {
                $configured += $layout ? 1 : 0;
                $seats += $seatCount;
                $partners += $partnerCount;
            }
            $summary[] = [
                'id' => $room->id,
                'name' => $room->name,
                'address' => $room->address_line1,
                'city' => $room->city,
                'timezone' => $room->timezone,
                'layout_revision' => (int) ($layout?->revision ?? 0),
                'seat_count' => $seatCount,
                'zone_count' => $zoneCount,
                'partner_count' => $partnerCount,
                'archived' => $isArchived,
            ];
        }

        return [
            'metrics' => [
                'venue_count' => count($summary) - $archived,
                'archived_count' => $archived,
                'configured_venue_count' => $configured,
                'seat_count' => $seats,
                'partner_count' => $partners,
            ],
            'rooms' => $summary,
        ];
    }
}
