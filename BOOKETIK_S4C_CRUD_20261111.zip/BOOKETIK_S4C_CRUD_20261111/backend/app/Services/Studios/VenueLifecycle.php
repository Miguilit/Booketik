<?php

declare(strict_types=1);

namespace App\Services\Studios;

use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

final class VenueLifecycle
{
    private function owned(object $provider, string $venueId, bool $lock = false): object
    {
        abort_unless($provider->status === 'active', 403);
        $q = DB::table('booketik_provider_venues')
            ->where('provider_id', $provider->id)
            ->where('venue_id', $venueId);
        $row = ($lock ? $q->lockForUpdate() : $q)->first();
        abort_unless($row, 404);
        return $row;
    }

    public function assertActive(object $provider, string $venueId): void
    {
        abort_unless($this->owned($provider, $venueId)->archived_at === null, 404);
    }

    public function update(object $provider, string $venueId, array $data): void
    {
        DB::transaction(function () use ($provider, $venueId, $data): void {
            abort_unless($this->owned($provider, $venueId, true)->archived_at === null, 404);
            $changes = ['name' => trim($data['name']), 'updated_at' => now()];
            foreach (['address_line1', 'city', 'timezone'] as $field) {
                if (array_key_exists($field, $data)) {
                    $changes[$field] = $data[$field];
                }
            }
            DB::table('venues')->where('id', $venueId)->update($changes);
        });
    }

    public function archive(object $provider, string $venueId, int $userId): void
    {
        DB::transaction(function () use ($provider, $venueId, $userId): void {
            $row = $this->owned($provider, $venueId, true);
            if ($row->archived_at !== null) {
                throw ValidationException::withMessages(['venue' => 'Cette salle est déjà archivée.']);
            }
            if (DB::table('events')->where('venue_id', $venueId)->exists()) {
                throw ValidationException::withMessages(['venue' => 'Impossible d’archiver une salle liée à des événements.']);
            }
            DB::table('booketik_venue_grants')->where('venue_id', $venueId)->where('status', 'granted')
                ->update(['status' => 'revoked', 'updated_at' => now()]);
            DB::table('booketik_provider_venues')->where('id', $row->id)->update([
                'archived_at' => now(), 'archived_by_user_id' => $userId, 'updated_at' => now(),
            ]);
        });
    }

    public function restore(object $provider, string $venueId): void
    {
        DB::transaction(function () use ($provider, $venueId): void {
            $row = $this->owned($provider, $venueId, true);
            abort_unless($row->archived_at !== null, 409);
            DB::table('booketik_provider_venues')->where('id', $row->id)->update([
                'archived_at' => null, 'archived_by_user_id' => null, 'updated_at' => now(),
            ]);
        });
    }

    public function renameProvider(object $provider, string $name): void
    {
        abort_unless($provider->status === 'active', 403);
        DB::table('booketik_venue_providers')->where('id', $provider->id)
            ->where('status', 'active')->update(['name' => trim($name), 'updated_at' => now()]);
    }

    public function searchOrganizers(object $provider, string $term): array
    {
        abort_unless($provider->status === 'active', 403);
        $term = trim($term);
        if (mb_strlen($term) < 2 || mb_strlen($term) > 80) {
            return [];
        }
        $safe = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $term);
        return DB::table('organizers')->whereNull('deleted_at')
            ->where('name', 'like', '%'.$safe.'%')
            ->orderBy('name')->limit(10)->get(['id', 'name'])
            ->map(fn ($row) => ['id' => $row->id, 'name' => $row->name])->all();
    }
}
