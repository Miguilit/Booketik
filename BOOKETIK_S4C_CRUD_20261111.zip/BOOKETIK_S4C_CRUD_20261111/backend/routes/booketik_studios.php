<?php

declare(strict_types=1);

use App\Http\Controllers\Studios\StudioController;
use Illuminate\Support\Facades\Route;

Route::prefix('{locale}')->middleware(['setLocale', 'auth'])->name('booketik.studios.')->group(function (): void {
    Route::get('venue-provider/studio', [StudioController::class, 'providerPage'])->name('provider.page');
    Route::middleware(['verified.email', 'throttle:30,1'])->group(function (): void {
        Route::post('venue-provider/register', [StudioController::class, 'register'])->name('provider.register');
        Route::post('venue-provider/venues', [StudioController::class, 'createVenue'])->name('provider.venues.create');
        Route::post('venue-provider/venues/{venue}/details', [StudioController::class, 'updateVenue'])->whereUuid('venue')->name('provider.venue.update');
        Route::post('venue-provider/venues/{venue}/archive', [StudioController::class, 'archiveVenue'])->whereUuid('venue')->name('provider.venue.archive');
        Route::post('venue-provider/venues/{venue}/restore', [StudioController::class, 'restoreVenue'])->whereUuid('venue')->name('provider.venue.restore');
        Route::get('venue-provider/organizers/search', [StudioController::class, 'searchOrganizers'])->name('provider.organizers.search');
        Route::post('venue-provider/profile', [StudioController::class, 'renameProvider'])->name('provider.profile.update');
        Route::post('venue-provider/venues/{venue}/layout', [StudioController::class, 'saveLayout'])->whereUuid('venue')->name('provider.layout.save');
        Route::post('venue-provider/venues/{venue}/grants', [StudioController::class, 'grant'])->whereUuid('venue')->name('provider.grant');
    });
    Route::prefix('organizer/dashboard/{org}/studios/events/{event}')
        ->where(['org' => '[a-z0-9-]+', 'event' => '[0-9a-fA-F-]{36}'])
        ->middleware('organizer.page:editor')->name('organizer.')->group(function (): void {
            Route::get('/', [StudioController::class, 'organizerPage'])->name('page');
            Route::post('seating-draft', [StudioController::class, 'saveMapping'])->middleware('throttle:30,1')->name('mapping.save');
            Route::post('ticket-design', [StudioController::class, 'saveDesign'])->middleware('throttle:30,1')->name('design.save');
        });
    Route::get('admin/venue-studios', [StudioController::class, 'governance'])->middleware('admin')->name('governance');
});
