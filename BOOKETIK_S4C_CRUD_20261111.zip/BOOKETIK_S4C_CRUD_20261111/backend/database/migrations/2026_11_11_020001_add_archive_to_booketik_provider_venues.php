<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('booketik_provider_venues', function (Blueprint $table): void {
            $table->timestamp('archived_at')->nullable()->index();
            $table->foreignId('archived_by_user_id')->nullable()->constrained('users')->nullOnDelete();
        });
    }

    public function down(): void
    {
        if (DB::table('booketik_provider_venues')->whereNotNull('archived_at')->exists()) {
            throw new RuntimeException('ARCHIVED_VENUES_PRESENT: restore before rollback');
        }
        Schema::table('booketik_provider_venues', function (Blueprint $table): void {
            $table->dropForeign(['archived_by_user_id']);
            $table->dropIndex(['archived_at']);
            $table->dropColumn(['archived_at', 'archived_by_user_id']);
        });
    }
};
