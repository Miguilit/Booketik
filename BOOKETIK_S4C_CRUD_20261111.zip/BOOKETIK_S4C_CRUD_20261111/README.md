# BOOKETIK — S4C : gestion des salles et des accès

Lot source préparatoire, non installable directement en production.

## Inclus

- Modifier le nom, l'adresse, la ville et le fuseau horaire d'une salle.
- Archiver une salle avec confirmation nominative ; restauration réversible.
- Refus de l'archivage si la salle est utilisée par au moins un événement.
- Révocation des accès organisateurs lors de l'archivage, sans suppression de l'historique.
- Rechercher les organisateurs par nom et accorder/révoquer les accès à une salle.
- Renommer le profil fournisseur.
- Pas de suppression physique de la salle, de ses plans ou de ses événements.
- Pas de changement des prix, des billets ou du checkout.
- Sans restriction d'abonnement.

## Contrats

- Migration additive obligatoire avant activation du nouveau backend : `archived_at`, `archived_by_user_id` dans `booketik_provider_venues`.
- Après la migration, installer de manière atomique le backend, les routes et les nouveaux assets client/SSR. Ne jamais remplacer les assets par une version antérieure à S4B.
- Le moteur `StudioStore` et `VenueManagerReadModel` sont modifiés pour gérer l'archivage : toutes les écritures sur une salle archivée sont bloquées, sauf sa restauration.
- L'archive est désactivée dès qu'un événement utilise la salle. Les accès actifs sont révoqués dans la même transaction.
- Une autorisation peut être rétablie explicitement après restauration.

## GitHub

Déposer le ZIP à la racine du dépôt privé avec `BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz` (la source de référence utilisée pour S4A) et créer le workflow `github/booketik-venue-manager-s4c.yml` dans `.github/workflows/`.

Exécuter **BOOKETIK Venue Manager S4C CRUD React**. Le résultat est un build client/SSR, pas un déploiement.

## Hostinger : lecture seule

Placer et décompresser le ZIP dans `booketik.com/_private/`, puis, depuis `booketik.com`, exécuter :

```bash
bash _private/BOOKETIK_S4C_CRUD_20261111/scripts/check_hostinger.sh
```

Aucune migration et aucune activation ne sont réalisées par ce script.

## Avant toute migration

Effectuer une nouvelle sauvegarde SQL (distincte de S3/T3), vérifier l'absence de migration non prévue, contrôler les SHA des sources live, préparer les assets et un rollback coordonné. Ne pas exécuter `php artisan migrate` sans ciblage ni validation du package de déploiement.

## Reste à développer

Suppression définitive d'une salle inutilisée avec audit référentiel complet, invitations par email, calendrier d'occupation et rôles équipe. La prochaine phase S5 concerne l'édition géométrique avancée.
