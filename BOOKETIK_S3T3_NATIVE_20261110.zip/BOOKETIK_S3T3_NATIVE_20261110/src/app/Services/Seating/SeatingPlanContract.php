<?php

declare(strict_types=1);
namespace App\Services\Seating;
use InvalidArgumentException;

/** Physical seating layout only. No checkout, prices, holds or QR. */
final class SeatingPlanContract
{
    public const VERSION = 'booketik.seating.v1';

    public static function normalize(array $input): array
    {
        self::need(($input['schema'] ?? null) === self::VERSION, 'unsupported_schema');
        $canvas = $input['canvas'] ?? null;
        self::need(is_array($canvas), 'invalid_canvas');
        $w = self::num($canvas['width'] ?? null, 320, 10000, 'canvas_width');
        $h = self::num($canvas['height'] ?? null, 240, 10000, 'canvas_height');
        $zones = $input['zones'] ?? null; $seats = $input['seats'] ?? null;
        self::need(is_array($zones) && array_is_list($zones) && count($zones) >= 1 && count($zones) <= 100, 'invalid_zones');
        self::need(is_array($seats) && array_is_list($seats) && count($seats) <= 20000, 'invalid_seats');
        $known=[]; $cleanZones=[];
        foreach ($zones as $i=>$z) {
            self::need(is_array($z), "zone_{$i}_invalid");
            $id=self::key($z['id'] ?? null, "zone_{$i}_id");
            self::need(!isset($known[$id]), "duplicate_zone_{$id}"); $known[$id]=true;
            $cleanZones[]=['id'=>$id,'label'=>self::label($z['label']??null,80,"zone_{$i}_label"),'color'=>self::hex($z['color']??null,"zone_{$i}_color")];
        }
        $seatIds=[]; $cleanSeats=[];
        foreach ($seats as $i=>$s) {
            self::need(is_array($s),"seat_{$i}_invalid");
            $id=self::key($s['id']??null,"seat_{$i}_id");
            self::need(!isset($seatIds[$id]),"duplicate_seat_{$id}"); $seatIds[$id]=true;
            $zone=self::key($s['zone_id']??null,"seat_{$i}_zone");
            self::need(isset($known[$zone]),"seat_{$i}_unknown_zone");
            $cleanSeats[]=[
                'id'=>$id,'row'=>self::label($s['row']??null,12,"seat_{$i}_row"),
                'number'=>self::label($s['number']??null,12,"seat_{$i}_number"),
                'x'=>self::num($s['x']??null,0,$w,"seat_{$i}_x"),
                'y'=>self::num($s['y']??null,0,$h,"seat_{$i}_y"),
                'zone_id'=>$zone,'accessible'=>($s['accessible']??false)===true,
            ];
        }
        $stage=$input['stage']??null; self::need(is_array($stage),'invalid_stage');
        $sx=self::num($stage['x']??null,0,$w,'stage_x'); $sy=self::num($stage['y']??null,0,$h,'stage_y');
        $sw=self::num($stage['width']??null,1,$w,'stage_width'); $sh=self::num($stage['height']??null,1,$h,'stage_height');
        self::need($sx+$sw<=$w && $sy+$sh<=$h,'stage_outside_canvas');
        return [
            'schema'=>self::VERSION,'canvas'=>['width'=>$w,'height'=>$h],
            'stage'=>['label'=>self::label($stage['label']??'Scène',80,'stage_label'), 'x'=>$sx,'y'=>$sy,'width'=>$sw,'height'=>$sh],
            'zones'=>$cleanZones,'seats'=>$cleanSeats,
        ];
    }
    private static function need(bool $ok,string $reason): void {if(!$ok)throw new InvalidArgumentException($reason);}
    private static function key(mixed $v,string $field): string {
        self::need(is_string($v) && preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/D',$v)===1,$field); return $v;
    }
    private static function label(mixed $v,int $max,string $field): string {
        self::need(is_string($v) && trim($v)!=='' && strlen($v)<=$max && preg_match('/[\x00-\x1F\x7F]/u',$v)!==1,$field);return trim($v);
    }
    private static function hex(mixed $v,string $field): string {
        self::need(is_string($v) && preg_match('/^#[0-9A-Fa-f]{6}$/D',$v)===1,$field);return strtoupper($v);
    }
    private static function num(mixed $v,float $min,float $max,string $field): int|float {
        self::need((is_int($v)||is_float($v)) && is_finite((float)$v) && $v>=$min && $v<=$max,$field);return $v;
    }
}
