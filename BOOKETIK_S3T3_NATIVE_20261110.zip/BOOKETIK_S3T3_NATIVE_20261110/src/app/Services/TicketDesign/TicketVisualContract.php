<?php

declare(strict_types=1);
namespace App\Services\TicketDesign;
use InvalidArgumentException;

/** Branding only. Cannot change QR signatures, status, buyer, money or check-in. */
final class TicketVisualContract
{
    public const VERSION = 'booketik.ticket-design.v1';

    public static function normalize(array $input): array
    {
        if (($input['schema']??null)!==self::VERSION)throw new InvalidArgumentException('unsupported_schema');
        $layout=$input['layout']??'classic';
        if (!is_string($layout)||!in_array($layout,['classic','poster','minimal'],true))throw new InvalidArgumentException('invalid_layout');
        $accent=self::hex($input['accent']??'#0C5A52','accent');
        $background=self::hex($input['background']??'#FFFFFF','background');
        $foreground=self::hex($input['foreground']??'#13201F','foreground');
        if (self::contrast($foreground,$background)<4.5)throw new InvalidArgumentException('insufficient_text_contrast');
        if ($layout==='poster' && self::contrast('#FFFFFF',$accent)<4.5)throw new InvalidArgumentException('insufficient_poster_contrast');
        $heading=$input['heading']??'Votre billet';
        if (!is_string($heading)||trim($heading)===''||strlen($heading)>80||preg_match('/[\x00-\x1F\x7F]/u',$heading)===1)throw new InvalidArgumentException('invalid_heading');
        $logo=$input['logo_media_id']??null;
        if ($logo!==null&&(!is_int($logo)||$logo<1))throw new InvalidArgumentException('invalid_logo_media_id');
        return [
            'schema'=>self::VERSION,'layout'=>$layout,'heading'=>trim($heading),
            'accent'=>$accent,'background'=>$background,'foreground'=>$foreground,
            'logo_media_id'=>$logo,'show_gate'=>($input['show_gate']??true)===true,
            'show_seat'=>($input['show_seat']??true)===true,
            'qr_frame'=>['dark'=>'#13201F','light'=>'#FFFFFF'],
        ];
    }
    private static function hex(mixed $value,string $field): string {
        if(!is_string($value)||preg_match('/^#[0-9A-Fa-f]{6}$/D',$value)!==1)throw new InvalidArgumentException('invalid_'.$field);
        return strtoupper($value);
    }
    private static function contrast(string $a,string $b):float {
        $x=self::lum($a);$y=self::lum($b);return (max($x,$y)+.05)/(min($x,$y)+.05);
    }
    private static function lum(string $hex):float {
        $v=[];for($i=1;$i<=5;$i+=2){$x=hexdec(substr($hex,$i,2))/255;$v[]=$x<=.04045?$x/12.92:(($x+.055)/1.055)**2.4;}
        return .2126*$v[0]+.7152*$v[1]+.0722*$v[2];
    }
}
