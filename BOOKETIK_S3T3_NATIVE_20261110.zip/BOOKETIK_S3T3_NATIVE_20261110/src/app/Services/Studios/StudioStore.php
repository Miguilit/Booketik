<?php

declare(strict_types=1);

namespace App\Services\Studios;

use App\Models\Event;
use App\Models\Venue;
use App\Services\Seating\SeatingPlanContract;
use App\Services\TicketDesign\TicketVisualContract;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use InvalidArgumentException;

final class StudioStore
{
    private function fail(string $key, string $reason): never
    {
        throw ValidationException::withMessages([$key => $reason]);
    }

    public function provider(int $userId): ?object
    {
        return DB::table('booketik_venue_providers')->where('owner_user_id', $userId)->first();
    }

    public function register(int $userId, string $name): object
    {
        return DB::transaction(function () use ($userId, $name): object {
            $existing = $this->provider($userId);
            if ($existing) {
                return $existing;
            }
            DB::table('booketik_venue_providers')->insert([
                'id' => (string) Str::uuid(), 'owner_user_id' => $userId,
                'name' => trim($name), 'status' => 'active',
                'created_at' => now(), 'updated_at' => now(),
            ]);
            return $this->provider($userId);
        });
    }

    public function venues(object $provider): array
    {
        return DB::table('booketik_provider_venues as pv')
            ->join('venues as v', 'v.id', '=', 'pv.venue_id')
            ->where('pv.provider_id', $provider->id)
            ->orderBy('v.name')->get(['v.id', 'v.name', 'v.address_line1', 'v.city', 'v.timezone'])
            ->map(fn ($v) => (array) $v)->all();
    }

    public function ownsVenue(object $provider, string $venueId, bool $lock = false): object
    {
        $query = DB::table('booketik_provider_venues')->where('provider_id', $provider->id)->where('venue_id', $venueId);
        $row = $lock ? $query->lockForUpdate()->first() : $query->first();
        abort_unless($row && $provider->status === 'active', 404);
        return $row;
    }

    public function createVenue(object $provider, array $data): Venue
    {
        abort_unless($provider->status === 'active', 403);
        return DB::transaction(function () use ($provider, $data): Venue {
            $venue = Venue::query()->create([
                'organizer_id' => null,
                'name' => $data['name'],
                'address_line1' => $data['address_line1'] ?? null,
                'city' => $data['city'] ?? null,
                'timezone' => $data['timezone'] ?? 'Europe/Brussels',
            ]);
            DB::table('booketik_provider_venues')->insert([
                'id' => (string) Str::uuid(), 'provider_id' => $provider->id,
                'venue_id' => $venue->id, 'created_at' => now(), 'updated_at' => now(),
            ]);
            return $venue;
        });
    }

    public function updateVenue(object $provider, string $venueId, array $data): void
    {
        $this->ownsVenue($provider, $venueId);
        Venue::query()->whereKey($venueId)->update([
            'name' => trim($data['name']),
            'address_line1' => $data['address_line1'] ?? null,
        ]);
    }

    public function latestLayout(string $venueId): ?object
    {
        return DB::table('booketik_venue_layout_revisions')->where('venue_id', $venueId)
            ->orderByDesc('revision')->first();
    }

    public function saveLayout(object $provider, string $venueId, int $userId, array $raw, int $expected): object
    {
        if (strlen((string) json_encode($raw)) > 2000000) {
            $this->fail('plan', 'Le plan dépasse 2 Mo.');
        }
        try {
            $plan = SeatingPlanContract::normalize($raw);
        } catch (InvalidArgumentException $e) {
            $this->fail('plan', $e->getMessage());
        }
        return DB::transaction(function () use ($provider, $venueId, $userId, $plan, $expected): object {
            $this->ownsVenue($provider, $venueId, true);
            $last = $this->latestLayout($venueId);
            $current = (int) ($last?->revision ?? 0);
            if ($current !== $expected) {
                $this->fail('expected_revision', 'Le plan a changé. Actualisez la page.');
            }
            $id = (string) Str::uuid();
            DB::table('booketik_venue_layout_revisions')->insert([
                'id' => $id, 'venue_id' => $venueId, 'revision' => $current + 1,
                'plan' => json_encode($plan, JSON_THROW_ON_ERROR),
                'created_by_user_id' => $userId, 'created_at' => now(), 'updated_at' => now(),
            ]);
            return DB::table('booketik_venue_layout_revisions')->where('id', $id)->first();
        });
    }

    public function grant(object $provider, string $venueId, string $organizerId, int $userId, bool $enabled): void
    {
        DB::transaction(function () use ($provider, $venueId, $organizerId, $userId, $enabled): void {
            $this->ownsVenue($provider, $venueId, true);
            abort_unless(DB::table('organizers')->where('id', $organizerId)->whereNull('deleted_at')->exists(), 404);
            $key = ['venue_id' => $venueId, 'organizer_id' => $organizerId];
            $existing = DB::table('booketik_venue_grants')->where($key)->first();
            if ($existing) {
                DB::table('booketik_venue_grants')->where($key)->update([
                    'status' => $enabled ? 'granted' : 'revoked',
                    'created_by_user_id' => $userId, 'updated_at' => now(),
                ]);
            } else {
                DB::table('booketik_venue_grants')->insert($key + [
                    'id' => (string) Str::uuid(), 'status' => $enabled ? 'granted' : 'revoked',
                    'created_by_user_id' => $userId, 'created_at' => now(), 'updated_at' => now(),
                ]);
            }
        });
    }

    public function grants(string $venueId): array
    {
        return DB::table('booketik_venue_grants as g')
            ->join('organizers as o', 'o.id', '=', 'g.organizer_id')
            ->where('g.venue_id', $venueId)->orderBy('o.name')
            ->get(['g.organizer_id', 'o.name as organizer_name', 'g.status'])
            ->map(fn ($g) => (array) $g)->all();
    }

    public function canUse(string $venueId, string $organizerId): bool
    {
        return DB::table('booketik_provider_venues as pv')
            ->join('booketik_venue_providers as p', 'p.id', '=', 'pv.provider_id')
            ->join('booketik_venue_grants as g', 'g.venue_id', '=', 'pv.venue_id')
            ->where('pv.venue_id', $venueId)->where('p.status', 'active')
            ->where('g.organizer_id', $organizerId)->where('g.status', 'granted')->exists();
    }

    public function latestDesign(string $eventId): ?object
    {
        return DB::table('booketik_ticket_design_revisions')->where('event_id', $eventId)
            ->orderByDesc('revision')->first();
    }

    public function saveDesign(Event $event, int $userId, array $raw, int $expected): object
    {
        try {
            $design = TicketVisualContract::normalize($raw);
        } catch (InvalidArgumentException $e) {
            $this->fail('design', $e->getMessage());
        }
        return DB::transaction(function () use ($event, $userId, $design, $expected): object {
            DB::table('events')->where('id', $event->id)->lockForUpdate()->first();
            $current = (int) ($this->latestDesign($event->id)?->revision ?? 0);
            if ($current !== $expected) {
                $this->fail('expected_revision', 'Ce modèle a changé. Actualisez la page.');
            }
            $id = (string) Str::uuid();
            DB::table('booketik_ticket_design_revisions')->insert([
                'id' => $id, 'event_id' => $event->id, 'organizer_id' => $event->organizer_id,
                'revision' => $current + 1, 'design' => json_encode($design, JSON_THROW_ON_ERROR),
                'changed_by_user_id' => $userId, 'created_at' => now(), 'updated_at' => now(),
            ]);
            return DB::table('booketik_ticket_design_revisions')->where('id', $id)->first();
        });
    }

    public function seatingDraft(string $eventId): ?object
    {
        return DB::table('booketik_event_seating_drafts')->where('event_id', $eventId)->first();
    }

    public function saveMapping(Event $event, int $userId, string $layoutId, array $map): void
    {
        DB::transaction(function () use ($event, $userId, $layoutId, $map): void {
            DB::table('events')->where('id', $event->id)->lockForUpdate()->first();
            abort_unless($event->venue_id !== null && $this->canUse($event->venue_id, $event->organizer_id), 403);
            $layout = DB::table('booketik_venue_layout_revisions')
                ->where('id', $layoutId)->where('venue_id', $event->venue_id)->first();
            abort_unless($layout, 404);
            $plan = json_decode($layout->plan, true, 512, JSON_THROW_ON_ERROR);
            $zones = array_column($plan['zones'], 'id');
            if (array_keys($map) !== $zones && (count($map) !== count($zones) || array_diff($zones, array_keys($map)))) {
                $this->fail('zone_ticket_types', 'Toutes les zones doivent être associées à un tarif.');
            }
            $tierIds = DB::table('ticket_types')->where('event_id', $event->id)->pluck('id')->all();
            foreach ($map as $zone => $ticketTypeId) {
                if (!in_array($zone, $zones, true) || !is_string($ticketTypeId) || !in_array($ticketTypeId, $tierIds, true)) {
                    $this->fail('zone_ticket_types', 'Correspondance zone / tarif invalide.');
                }
            }
            $existing = $this->seatingDraft($event->id);
            $now = now();
            if ($existing) {
                DB::table('booketik_event_seating_drafts')->where('event_id', $event->id)->update([
                    'layout_revision_id' => $layoutId, 'zone_ticket_types' => json_encode($map, JSON_THROW_ON_ERROR),
                    'changed_by_user_id' => $userId, 'updated_at' => $now,
                ]);
            } else {
                DB::table('booketik_event_seating_drafts')->insert([
                    'id' => (string) Str::uuid(), 'event_id' => $event->id,
                    'layout_revision_id' => $layoutId, 'zone_ticket_types' => json_encode($map, JSON_THROW_ON_ERROR),
                    'changed_by_user_id' => $userId, 'created_at' => $now, 'updated_at' => $now,
                ]);
            }
        });
    }
}
