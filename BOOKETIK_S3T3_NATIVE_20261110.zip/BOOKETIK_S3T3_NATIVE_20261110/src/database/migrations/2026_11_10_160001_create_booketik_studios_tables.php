<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('booketik_venue_providers', function (Blueprint $t): void {
            $t->uuid('id')->primary();
            $t->foreignId('owner_user_id')->unique()->constrained('users')->restrictOnDelete();
            $t->string('name', 160);
            $t->string('status', 20)->default('active');
            $t->timestamps();
        });
        Schema::create('booketik_provider_venues', function (Blueprint $t): void {
            $t->uuid('id')->primary();
            $t->foreignUuid('provider_id')->constrained('booketik_venue_providers')->restrictOnDelete();
            $t->foreignUuid('venue_id')->unique()->constrained('venues')->restrictOnDelete();
            $t->timestamps();
        });
        Schema::create('booketik_venue_layout_revisions', function (Blueprint $t): void {
            $t->uuid('id')->primary();
            $t->foreignUuid('venue_id')->constrained('venues')->restrictOnDelete();
            $t->unsignedInteger('revision');
            $t->json('plan');
            $t->foreignId('created_by_user_id')->constrained('users')->restrictOnDelete();
            $t->timestamps();
            $t->unique(['venue_id', 'revision'], 'bkt_layout_revision_unique');
        });
        Schema::create('booketik_venue_grants', function (Blueprint $t): void {
            $t->uuid('id')->primary();
            $t->foreignUuid('venue_id')->constrained('venues')->restrictOnDelete();
            $t->foreignUuid('organizer_id')->constrained('organizers')->restrictOnDelete();
            $t->string('status', 20)->default('granted');
            $t->foreignId('created_by_user_id')->constrained('users')->restrictOnDelete();
            $t->timestamps();
            $t->unique(['venue_id', 'organizer_id'], 'bkt_venue_grant_unique');
        });
        Schema::create('booketik_event_seating_drafts', function (Blueprint $t): void {
            $t->uuid('id')->primary();
            $t->foreignUuid('event_id')->unique()->constrained('events')->cascadeOnDelete();
            $t->foreignUuid('layout_revision_id')->constrained('booketik_venue_layout_revisions')->restrictOnDelete();
            $t->json('zone_ticket_types');
            $t->foreignId('changed_by_user_id')->constrained('users')->restrictOnDelete();
            $t->timestamps();
        });
        Schema::create('booketik_ticket_design_revisions', function (Blueprint $t): void {
            $t->uuid('id')->primary();
            $t->foreignUuid('event_id')->constrained('events')->cascadeOnDelete();
            $t->foreignUuid('organizer_id')->constrained('organizers')->restrictOnDelete();
            $t->unsignedInteger('revision');
            $t->json('design');
            $t->foreignId('changed_by_user_id')->constrained('users')->restrictOnDelete();
            $t->timestamps();
            $t->unique(['event_id', 'revision'], 'bkt_design_revision_unique');
        });
    }

    public function down(): void
    {
        foreach (['booketik_ticket_design_revisions', 'booketik_event_seating_drafts', 'booketik_venue_grants', 'booketik_venue_layout_revisions', 'booketik_provider_venues', 'booketik_venue_providers'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
