<?php

declare(strict_types=1);

require __DIR__.'/../src/app/Services/Seating/SeatingPlanContract.php';
require __DIR__.'/../src/app/Services/TicketDesign/TicketVisualContract.php';

use App\Services\Seating\SeatingPlanContract;
use App\Services\TicketDesign\TicketVisualContract;

$plan = json_decode(file_get_contents(__DIR__.'/fixtures/seating_plan_demo.json'), true, 512, JSON_THROW_ON_ERROR);
$design = json_decode(file_get_contents(__DIR__.'/fixtures/ticket_visual_demo.json'), true, 512, JSON_THROW_ON_ERROR);
$clean = SeatingPlanContract::normalize($plan);
if (count($clean['seats']) !== 70) throw new RuntimeException('seat_count');
$copy = $plan;
$copy['seats'][] = $copy['seats'][0];
try { SeatingPlanContract::normalize($copy); throw new RuntimeException('duplicate_accepted'); }
catch (InvalidArgumentException $e) {}
$copy = $plan;
$copy['seats'][0]['zone_id'] = 'absent';
try { SeatingPlanContract::normalize($copy); throw new RuntimeException('unknown_zone_accepted'); }
catch (InvalidArgumentException $e) {}
$theme = TicketVisualContract::normalize($design + ['qr_secret' => 'must_not_be_persisted']);
if (isset($theme['qr_secret']) || isset($theme['ticket_status'])) throw new RuntimeException('qr_leak');
$copy = $design;
$copy['foreground'] = '#FFFFFF';
try { TicketVisualContract::normalize($copy); throw new RuntimeException('contrast_accepted'); }
catch (InvalidArgumentException $e) {}
echo "PASS 70 seats, duplicates, zones, contrast, QR isolation\n";
