# Étapes S3/T3

1. `--check` sur Hostinger (zéro écriture).
2. GitHub Actions S3/T3 (client + SSR), vérifier les SHA.
3. Certification de la cohérence build/assets et du préflight.
4. `--stage` backend additif, aucune route activée.
5. Migration ciblée et tests d'autorisations sur instance de recette.
6. Déploiement client/SSR et activation contrôlée des routes.
7. S4 : association de salle autorisée à l'événement, inventaire de sièges, holds atomiques, vente et ticket réel.

Pas de changement de pricing ni d'activation de modules commerciaux.
