# BOOKETIK S3/T3 — Fondations natives (10/11/2026)

**Fonctionnalités natives ; aucun abonnement ni achat de module requis.**

## Livré

- Fournisseur de salles : compte propriétaire, création de salle, modification d'identité et plan versionné.
- Gestion explicite des autorisations entre une salle et un organisateur, avec révocation.
- Organisateur : association des zones à ses types de billets, stockée en brouillon.
- Ticket Studio : modèle graphique validé et historisé par événement, uniquement en brouillon.
- Superadmin : inventaire de gouvernance en lecture seule.
- React : écrans Inertia fournisseur, organisateur et gouvernance, compilables avec Vite + SSR.

## À ne pas confondre avec l'étape suivante

Ce lot **ne vend aucun siège**, ne verrouille aucun siège, n'assigne pas automatiquement une salle à un événement, n'active pas les modèles sur les vrais billets, n'altère pas les QR, ne modifie pas les frais, les quotas ni les paiements. Les billets et checkout existants restent exclusivement gérés par Eventgoo.

## 1. Hostinger : préflight puis staging sans activation

Déposer le ZIP dans `booketik.com/_private/`, le décompresser puis :

```bash
unzip -q _private/BOOKETIK_S3T3_NATIVE_20261110.zip -d _private/
bash _private/BOOKETIK_S3T3_NATIVE_20261110/scripts/guarded_stage.sh --check
```

Cette opération ne modifie rien. Après validation des empreintes, une commande séparée `--stage` ajoute les fichiers PHP et la migration, **sans** exécuter SQL et **sans** rendre les routes accessibles. `--unstage` retire les sources non modifiées mais conserve le fichier de migration et les données.

## 2. GitHub React

Dans le dépôt privé, placer :

- `BOOKETIK_S3T3_NATIVE_20261110.zip` à la racine ;
- `BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz` (source frontend actuelle exportée depuis Hostinger) à la racine ;
- le contenu de `github/booketik-studios-s3t3.yml` dans `.github/workflows/booketik-studios-s3t3.yml`.

Dans **Actions**, démarrer `BOOKETIK Studios S3 T3 React`. La compilation vérifiera que toute ancienne version des composants correspond exactement au S2/T2 certifié, ou que ces fichiers étaient absents. Tout autre conflit est bloquant. Les dépendances NPM existantes ne sont pas modifiées.

Résultat : `BOOKETIK_STUDIOS_S3T3_COMPILED_20261110.tar.gz` + `.sha256`.

## 3. Activation (NON AUTORISÉE à cette étape)

La mise en service demandera, dans cet ordre : vérification du préflight serveur ; staging PHP ; vérification du build actuel ; migration **ciblée** (ne pas lancer `php artisan migrate` global) ; vérification des routes et des autorisations ; déploiement des assets client+SSR ; activation gardée du `require` route ; smoke tests. Les éléments de migration et d'activation ne doivent pas être exécutés depuis ce ZIP sans validation du build et de la recette.

Le fichier `routes/booketik_studios.php` est volontairement **non inclus** dans `routes/web.php` par le staging. Aucun fichier existant n'est modifié. Aucune écriture `.env`, aucune connexion fournisseur externe et aucune écriture dans la base n'est effectuée par les scripts livrés.

## Notes

- La propriété d'une salle appartient au fournisseur, indépendamment des rôles organisateurs ; l'accès à ses plans exige une autorisation explicite.
- Les permissions organisateurs reprennent `organizer.page:editor` ; le panneau gouvernance exige `admin`.
- La gestion des prix réutilise strictement les `TicketType` natifs de l'événement.
- Le modèle graphique des billets n'accepte aucun champ de code QR, signature, holder ou statut.
- Les versions de plans et de designs sont immuables. Les mises à jour de même version sont refusées pour éviter d'écraser le travail concurrent.
- Les tables commencent toutes par `booketik_` ; l'installation est additive.
- La migration nécessite le runtime Laravel complet et une sauvegarde de base lors d'une phase ultérieure.
