#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
REPO="$(cd -- "${1:-$PWD}" && pwd -P)"
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'FAIL PACKAGE_SHA'; exit 3; }
ARCHIVE="$REPO/BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz"
[[ -s "$ARCHIVE" ]] || { echo 'FAIL CURRENT_FRONTEND_SOURCE_REQUIRED'; exit 4; }
SRC="$REPO/_s3t3_source"
[[ ! -e "$SRC" ]] || { echo 'FAIL TEMP_SOURCE_ALREADY_EXISTS'; exit 5; }
mkdir -p -- "$SRC"
tar -xzf "$ARCHIVE" -C "$SRC" --strip-components=1
[[ -f "$SRC/package-lock.json" && -f "$SRC/resources/js/pages.jsx" && -f "$SRC/vite.config.js" ]] || { echo 'FAIL SOURCE_LAYOUT'; exit 6; }
while IFS= read -r -d '' item; do
  rel="${item#"$KIT/react/"}"
  target="$SRC/$rel"
  if [[ -e "$target" ]]; then
    [[ -f "$target" ]] || { echo "FAIL REACT_TARGET_NOT_FILE $rel"; exit 7; }
    if ! cmp -s "$item" "$target"; then
      baseline="$(awk -F '\t' -v key="$rel" '$1==key {print $2}' "$KIT/scripts/s2_react_baseline.tsv")"
      [[ -n "$baseline" && "$(sha256sum "$target" | awk '{print $1}')" == "$baseline" ]] || { echo "FAIL REACT_TARGET_DRIFT $rel"; exit 8; }
    fi
  fi
done < <(find "$KIT/react" -type f -print0 | sort -z)
while IFS= read -r -d '' item; do
  rel="${item#"$KIT/react/"}"
  mkdir -p -- "$(dirname "$SRC/$rel")"
  cp -- "$item" "$SRC/$rel"
done < <(find "$KIT/react" -type f -print0 | sort -z)
cd "$SRC"
npm ci --no-audit --no-fund
npm run build
[[ -s public/build/manifest.json ]] || { echo 'FAIL CLIENT_MANIFEST'; exit 9; }
node - <<'JS'
const fs=require('fs');
const m=JSON.parse(fs.readFileSync('public/build/manifest.json','utf8'));
for(const page of ['BooketikStudios.jsx','BooketikStudiosStandalone.jsx']) {
 if(!Object.keys(m).some(k=>k.endsWith('/'+page))) throw new Error('Missing page: '+page);
}
JS
[[ -d bootstrap/ssr ]] || { echo 'FAIL SSR_BUILD'; exit 10; }
OUT="$REPO/BOOKETIK_STUDIOS_S3T3_COMPILED_20261110.tar.gz"
tar -czf "$OUT" public/build bootstrap/ssr
(cd "$REPO" && sha256sum "$(basename "$OUT")" > "$(basename "$OUT").sha256")
echo "PASS REACT_S3T3 $(basename "$OUT")"
