#!/usr/bin/env bash
set -euo pipefail
MODE="${1:---check}"
KIT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
PARENT="$(dirname -- "$KIT")"
if [[ "$(basename "$PARENT")" == '_private' ]]; then
  DEFAULT_ROOT="$(dirname "$PARENT")/eventgoo"
else
  DEFAULT_ROOT="$PARENT/eventgoo"
fi
ROOT="$(realpath -m -- "${2:-$DEFAULT_ROOT}")"
[[ "$MODE" == '--check' || "$MODE" == '--stage' || "$MODE" == '--unstage' ]] || { echo 'USAGE --check|--stage|--unstage [laravel_root]' >&2; exit 2; }
[[ "$KIT" != */public_html* && "$ROOT" != */public_html* ]] || { echo 'FAIL PUBLIC_PATH'; exit 3; }
[[ -f "$ROOT/artisan" && -f "$ROOT/composer.json" && -f "$ROOT/routes/web.php" ]] || { echo 'FAIL LARAVEL_ROOT'; exit 4; }
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'FAIL PACKAGE_SHA'; exit 5; }
while IFS=$'\t' read -r rel expected; do
  [[ -n "$rel" && -n "$expected" ]] || continue
  [[ -f "$ROOT/$rel" ]] || { echo "FAIL BASELINE_MISSING $rel"; exit 6; }
  actual="$(sha256sum "$ROOT/$rel" | awk '{print $1}')"
  [[ "$actual" == "$expected" ]] || { echo "FAIL SOURCE_DRIFT $rel"; exit 7; }
done < "$KIT/scripts/source_baseline.tsv"
COUNT=0
while IFS= read -r -d '' source; do
  rel="${source#"$KIT/src/"}"
  target="$ROOT/$rel"
  if [[ -e "$target" || -L "$target" ]]; then
    [[ -f "$target" && ! -L "$target" && "$(sha256sum "$target" | awk '{print $1}')" == "$(sha256sum "$source" | awk '{print $1}')" ]] || { echo "FAIL TARGET_CONFLICT $rel"; exit 8; }
  fi
  COUNT=$((COUNT+1))
done < <(find "$KIT/src" -type f -print0 | sort -z)
if [[ "$MODE" == '--unstage' ]]; then
  while IFS= read -r -d '' source; do
    rel="${source#"$KIT/src/"}"
    [[ "$rel" == database/migrations/* ]] && continue
    [[ ! -f "$ROOT/$rel" ]] || rm -- "$ROOT/$rel"
  done < <(find "$KIT/src" -type f -print0 | sort -z)
  echo 'PASS UNSTAGED — code removed; migration file retained; database untouched'
elif [[ "$MODE" == '--stage' ]]; then
  while IFS= read -r -d '' source; do
    rel="${source#"$KIT/src/"}"
    target="$ROOT/$rel"
    if [[ ! -e "$target" ]]; then
      mkdir -p -- "$(dirname "$target")"
      cp -- "$source" "$target"
    fi
  done < <(find "$KIT/src" -type f -print0 | sort -z)
  echo "PASS STAGED $COUNT files — no route hook; no SQL; no build; checkout untouched"
else
  echo "PASS PREFLIGHT $COUNT additive targets — no changes"
fi
