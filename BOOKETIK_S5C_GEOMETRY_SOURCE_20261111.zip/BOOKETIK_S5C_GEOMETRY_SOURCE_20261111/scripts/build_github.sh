#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
REPO="$(cd "${1:-$PWD}" && pwd -P)"
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'S5C_PACKAGE_SHA=FAIL'; exit 3; }
BASE="$REPO/BOOKETIK_S4C_CRUD_20261111"
SOURCE="$REPO/BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz"
[[ -f "$BASE/scripts/build_github.sh" && -s "$SOURCE" ]] || { echo 'S5C_DEPENDENCIES=MISSING'; exit 4; }
# The S4C overlay is the certified React baseline; only Studio.jsx is replaced.
python3 - "$KIT" "$BASE" <<'PY'
import pathlib,hashlib,sys
kit,base=[pathlib.Path(p) for p in sys.argv[1:]]
record=(kit/'scripts/s4c_frontend_baseline.sha256').read_text().strip().split()
p=base/'frontend/resources/js/Themes/civic/components/dashboard/VenueManager/Studio.jsx'
if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=record[0]:
    raise SystemExit('S5C_S4C_STUDIO_BASELINE=FAIL')
print('S5C_S4C_STUDIO_BASELINE=PASS')
PY
DEST="$REPO/_booketik_s5c_build"
[[ ! -e "$DEST" ]] || { echo 'S5C_BUILD_DIR=EXISTS'; exit 5; }
mkdir -p "$DEST"
python3 - "$SOURCE" "$DEST" <<'PY'
import pathlib,sys,tarfile
src,dest=sys.argv[1:]
with tarfile.open(src,'r:gz') as ar:
    seen=set()
    for e in ar:
        parts=pathlib.PurePosixPath(e.name).parts
        if not e.name or e.name.startswith('/') or '..' in parts or e.issym() or e.islnk() or e.isdev() or not (e.isfile() or e.isdir()) or e.name in seen or any(p in ('.env','vendor','node_modules','.git') for p in parts):
            raise SystemExit('S5C_SOURCE_ARCHIVE=UNSAFE')
        seen.add(e.name)
    ar.extractall(dest,filter='data')
PY
if [[ ! -f "$DEST/package.json" && -f "$DEST/source/package.json" ]]; then
    shopt -s dotglob nullglob
    mv "$DEST"/source/* "$DEST"/
    rmdir "$DEST/source"
    shopt -u dotglob nullglob
fi
[[ -f "$DEST/package-lock.json" && -f "$DEST/vite.config.js" && -f "$DEST/resources/js/pages.jsx" ]] || { echo 'S5C_SOURCE_LAYOUT=FAIL'; exit 6; }
python3 - "$KIT" "$BASE" "$DEST" <<'PY'
import pathlib,sys,shutil
kit,base,dest=[pathlib.Path(p) for p in sys.argv[1:]]
for root in (base/'dependencies/s3t3-react',base/'frontend'):
    for src in sorted(root.rglob('*')):
        if not src.is_file():continue
        rel=src.relative_to(root); dst=dest/rel
        if dst.exists() and dst.read_bytes()!=src.read_bytes(): raise SystemExit('S5C_BASE_SOURCE_CONFLICT='+str(rel))
        dst.parent.mkdir(parents=True,exist_ok=True)
        if not dst.exists():shutil.copy2(src,dst)
for src in sorted((kit/'frontend').rglob('*')):
    if not src.is_file():continue
    rel=src.relative_to(kit/'frontend');dst=dest/rel
    baseline=base/'frontend'/rel
    if dst.exists() and (not baseline.exists() or dst.read_bytes()!=baseline.read_bytes()):
        raise SystemExit('S5C_SOURCE_DRIFT='+str(rel))
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
print('S5C_REACT_OVERLAY=PASS')
PY
cd "$DEST"
npm ci --no-audit --no-fund
npm run build
node - <<'JS'
const fs = require('fs');
const client = JSON.parse(fs.readFileSync('public/build/manifest.json','utf8'));
const ssr = JSON.parse(fs.readFileSync('bootstrap/ssr/ssr-manifest.json','utf8'));
for (const [name,obj] of [['CLIENT',client],['SSR',ssr]]){
  for (const page of ['BooketikVenueManager.jsx','BooketikStudiosStandalone.jsx'])
    if (!Object.keys(obj).some(key => key.endsWith('/'+page)))throw Error('S5C_'+name+'_MISSING_'+page);
  console.log('S5C_'+name+'_ENTRIES='+Object.keys(obj).length);
}
JS
OUT="$REPO/BOOKETIK_S5C_GEOMETRY_COMPILED_20261111.tar.gz"
tar -czf "$OUT" public/build bootstrap/ssr
(cd "$REPO" && sha256sum "$(basename "$OUT")" > "$(basename "$OUT").sha256")
echo 'S5C_REACT_BUILD=PASS'
