#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
DOMAIN="$(cd "$KIT/../.." && pwd -P)"
APP="$DOMAIN/eventgoo"
[[ -f "$APP/artisan" && -f "$APP/app/Services/Seating/SeatingPlanContract.php" ]] || { echo 'S5C_APP_ROOT=FAIL'; exit 4; }
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'S5C_PACKAGE_SHA=FAIL'; exit 3; }
while read -r expected rel; do
  path="$APP/$rel"
  [[ -f "$path" ]] || { echo "S5C_MISSING_SOURCE=$rel"; exit 5; }
  actual="$(sha256sum "$path" | cut -d ' ' -f 1)"
  [[ "$actual" == "$expected" ]] || { echo "S5C_SOURCE_DRIFT=$rel"; exit 6; }
done < "$KIT/scripts/host_baseline.tsv"
PHP84=/opt/alt/php84/usr/bin/php
[[ -x "$PHP84" ]] || PHP84="$(command -v php)"
"$PHP84" -l "$KIT/backend/app/Services/Seating/SeatingPlanContract.php" | grep -q '^No syntax errors'
"$PHP84" "$KIT/tests/contract.php" | grep -q 'S5C_GEOMETRY=PASS'
echo 'S5C_S4C_BASELINE=PASS'
echo 'S5C_PHP_CONTRACT=PASS'
echo 'S5C_PREFLIGHT=PASS'
echo 'APPLICATION_WRITES=0'
echo 'DATABASE_WRITES=0'
