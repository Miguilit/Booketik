# BOOKETIK — S5C Geometry Studio (code source, non déployable directement)

**Statut :** PHP (syntaxe, contrats rétrocompatibles) PASS ; algorithmes géométriques JS PASS ; analyse syntaxique JSX PASS ; build Vite/SSR sur GitHub **à effectuer** ; activation production **interdite à ce stade**.

## Périmètre

- Éditeur graphique React natif avec SVG, sans Vue ni nouvelle dépendance.
- Rectangle, ovale/cercle, polygone à sommets, contour main levée simplifié, sections, passages/allées, escaliers.
- Placement/déplacement des sièges et de la scène existante, création de rangées droites/courbes, pinceau de zone, bascule PMR.
- Sélection, déplacement, suppression locale, annuler/rétablir (40 historiques), zoom, grille, export JSON et sauvegarde par révision.
- Conservation des sièges et identifiants déjà enregistrés ; plan JSON `booketik.seating.v1` conservé ; extension optionnelle `geometry: { version:1, objects: [] }`.
- **Backend :** modification unique de `app/Services/Seating/SeatingPlanContract.php` pour autoriser et conserver les nouveaux objets après validations strictes ; pas de migration SQL, aucune route nouvelle, checkout inchangé.
- Le fournisseur dessine le plan physique ; l'organisateur conserve le mapping des zones vers les `TicketType` par événement.

## Limites de S5C

- La simplification des tracés libres est géométrique, **pas** une reconnaissance intelligente de plans photographiés. Import PDF/photo et redressement avancé sont ultérieurs.
- Les objets de décor de la salle ne sont **pas encore rendus** dans le front acheteur/Flutter ni dans l'ancien composant `SeatCanvas` d'organisateur. Celui-ci continue d'afficher sièges/zones/scène, comme avant.
- Pas de calculs de réglementation PMR, évacuation, contrôle de visibilité, collisions ni gestion de stock par siège.
- Ne pas publier de vente avec un plan S5C non validé de bout en bout. Le backend d'inventaire et de réservation n'est pas modifié.

## GitHub — Compiler sans altérer la production

Ajouter à la racine du dépôt privé les **trois** fichiers :

1. `BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz` (référence S3/S4 précédente, inchangée) ;
2. `BOOKETIK_S4C_CRUD_20261111.zip` (source S4C, inchangée) ;
3. `BOOKETIK_S5C_GEOMETRY_SOURCE_20261111.zip` (ce package).

Créer `.github/workflows/booketik-geometry-s5c.yml` depuis `github/booketik-geometry-s5c.yml` et lancer **BOOKETIK S5C Geometry Studio React** via Actions / Run workflow.

Résultat : `booketik-geometry-s5c-compiled.zip`, contenant `BOOKETIK_S5C_GEOMETRY_COMPILED_20261111.tar.gz` et son `.sha256`.

Le workflow vérifie les sources immuables, superpose S4C, ajoute S5C, compile Vite client/SSR et crée un artefact. Il ne déploie rien.

## Hostinger — Préflight lecture seule

Depuis `booketik.com`, placer ce ZIP dans `_private/`, puis :

```bash
unzip -q _private/BOOKETIK_S5C_GEOMETRY_SOURCE_20261111.zip -d _private/
bash _private/BOOKETIK_S5C_GEOMETRY_SOURCE_20261111/scripts/check_hostinger.sh
```

Attendu : `S5C_PREFLIGHT=PASS`, `S5C_S4C_BASELINE=PASS`, `APPLICATION_WRITES=0`, `DATABASE_WRITES=0`.

Ne **pas** copier les fichiers PHP/JS ou les builds directement dans `eventgoo` : la version compilée nécessite un package d'activation atomique avec SHA de la baseline S4C, fusion additive des assets, backup et rollback. Ce package sera préparé après vérification de l'artefact GitHub et du préflight.

## Tests exécutés localement

```bash
php -l backend/app/Services/Seating/SeatingPlanContract.php
php tests/contract.php
node tests/geometry.mjs
```

Vérification de syntaxe JSX avec le parseur TypeScript installé, sans compilation Vite dans l'environnement de préparation.

## Intégrité

Chaque fichier contenu dans le kit (hors manifeste) est vérifié par `scripts/package_files.sha256` avant compilation ou préflight. Le ZIP est accompagné d'une empreinte SHA-256 indépendante.
