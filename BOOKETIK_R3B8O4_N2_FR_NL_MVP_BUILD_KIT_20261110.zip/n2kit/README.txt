BOOKETIK R3-B8-O4-N2 — French/Dutch MVP localisation, batch 1.

Build inputs in private GitHub repository root:
 - BOOKETIK_R3B8O2_FRONTEND_BUILD_SOURCE_20261109T133219Z.tar.gz (unchanged, SHA pinned)
 - BOOKETIK_R3B8O4_N2_FR_NL_MVP_BUILD_KIT_20261110.zip (this kit)

Copy the workflow under .github/workflows/booketik-n2.yml, then Actions -> Run workflow.

The build reconstitutes O4's Event.jsx claim components and improves the 3 site Layout.jsx footer localization,
merges reviewed Dutch translations without overwriting previous valid entries, and checks placeholders.
French is included (no missing keys vs en reference) plus CMS footer links.

No Laravel DB migration; this is NOT a production deployment package. The GitHub artifact must be
validated against existing Hostinger O4+N1 before any client/SSR or nl.json release is deployed.
The remaining NL English fallbacks are tracked, not silently filled with fabricated translations.
