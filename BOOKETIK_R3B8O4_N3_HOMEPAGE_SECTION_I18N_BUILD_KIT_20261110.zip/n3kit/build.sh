#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
INPUT="${1:?Original R3B8O2 source TAR.GZ required}"
OUT="${2:-$PWD}"
INPUT="$(cd "$(dirname "$INPUT")" && pwd -P)/$(basename "$INPUT")"
mkdir -p "$OUT"; OUT="$(cd "$OUT" && pwd -P)"
[[ "$(sha256sum "$INPUT" | cut -d' ' -f1)" == '181cbe78ccfa1668c0fb8efec4377ad0faf9980cb42bb9bc38fedb5ed361a92f' ]] || { echo 'SOURCE_ARCHIVE_SHA=FAIL'; exit 2; }
( cd "$KIT" && sha256sum -c dictionary_hashes.txt >/dev/null && sha256sum -c base_theme_hashes.txt >/dev/null && sha256sum -c layout_hashes.txt >/dev/null ) || { echo 'KIT_HASHES=FAIL'; exit 2; }
( cd "$KIT/patch/files" && sha256sum -c "$KIT/patch/package_hashes.txt" >/dev/null ) || { echo 'O4_BASE_PATCH_HASHES=FAIL'; exit 2; }
command -v node >/dev/null && command -v npm >/dev/null || { echo 'NODE_NPM_MISSING'; exit 2; }
node -e 'const v=process.versions.node.split(".").map(Number);if(v[0]<22||(v[0]===22&&v[1]<12))process.exit(1)' || { echo 'NODE_22_12_REQUIRED'; exit 2; }
if tar -tzf "$INPUT" | grep -Eq '(^/|(^|/)\.\.(/|$))'; then echo 'SOURCE_ARCHIVE_UNSAFE'; exit 2; fi
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
tar -xzf "$INPUT" -C "$WORK"
SRC="$WORK/source"
( cd "$SRC" && sha256sum -c "$WORK/source_sha256.txt" >/dev/null ) || { echo 'ORIGINAL_SOURCE_SHA=FAIL'; exit 2; }
( cd "$SRC" && sha256sum -c "$KIT/frontend_base_hashes.txt" >/dev/null && sha256sum -c "$KIT/layout_source_hashes.txt" >/dev/null ) || { echo 'ORIGINAL_FRONTEND_SHA=FAIL'; exit 2; }
( cd "$SRC" && sha256sum -c "$KIT/home_before.sha256" >/dev/null ) || { echo 'ORIGINAL_HOMEPAGE_SHA=FAIL'; exit 2; }
( cd "$KIT/home_source" && sha256sum -c "$KIT/home_after.sha256" >/dev/null ) || { echo 'PATCH_HOMEPAGE_SHA=FAIL'; exit 2; }
for THEME in civic almanac marquee; do
 PATHREL="resources/js/Themes/$THEME/Pages/Site/Event.jsx"
 cp "$KIT/theme_source/$PATHREL" "$SRC/$PATHREL"
 LAYOUT="resources/js/Themes/$THEME/Layout.jsx"
 cp "$KIT/layout_source/$LAYOUT" "$SRC/$LAYOUT"
  HOME="resources/js/Themes/$THEME/Pages/Site/Home.jsx"
  cp "$KIT/home_source/$HOME" "$SRC/$HOME"
done
mkdir -p "$SRC/resources/js/Core/components" "$SRC/resources/lang"
cp "$KIT/patch/files/resources/js/Core/components/ExternalClaimInline.jsx" "$SRC/resources/js/Core/components/ExternalClaimInline.jsx"
cp "$KIT"/dictionaries/*.json "$SRC/resources/lang/"
node "$KIT/validate_locales.mjs" "$SRC/resources/lang" "$SRC/resources/js"
node - "$SRC" <<'JS'
const fs = require('fs');
const base = process.argv[2];
const nl = JSON.parse(fs.readFileSync(`${base}/resources/lang/nl.json`, 'utf8'));
if (nl['Browse by category'] !== 'Ontdek per categorie') throw Error('NL_BROWSE_BY_CATEGORY_MISSING');
for (const theme of ['civic','almanac','marquee']) {
  const code=fs.readFileSync(`${base}/resources/js/Themes/${theme}/Pages/Site/Home.jsx`, 'utf8');
  if (!code.includes('t(section.title)') || /(?<!t\()section\.title/.test(code)) throw Error('UNTRANSLATED_HOMEPAGE_HEADING_'+theme);
}
console.log('N3_HOMEPAGE_HEADINGS=PASS NL_SECTION_KEY=PASS');
JS
echo '===== NPM CI ====='
( cd "$SRC" && npm ci --no-audit --no-fund )
echo '===== VITE CLIENT + SSR ====='
( cd "$SRC" && npm run build )
node "$KIT/verify_manifest.mjs" "$SRC"
[[ -f "$SRC/bootstrap/ssr/ssr.js" ]] || { echo 'SSR_OUTPUT_MISSING'; exit 2; }
node - "$SRC/public/build/manifest.json" <<'NODE'
const fs=require('fs'); const m=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
for (const lang of ['fr','nl','en']) {
 if (!Object.keys(m).some(k=>k.includes(`lang/${lang}.json`))) throw Error('LOCALE_CHUNK_MISSING_'+lang);
}
console.log('LOCALE_MANIFEST=PASS');
NODE
REL="$WORK/release"
mkdir -p "$REL/assets/public" "$REL/assets/bootstrap" "$REL/locales"
cp -a "$SRC/public/build" "$REL/assets/public/build"
cp -a "$SRC/bootstrap/ssr" "$REL/assets/bootstrap/ssr"
cp "$KIT/dictionaries/fr.json" "$REL/locales/fr.json"
cp "$KIT/dictionaries/nl.json" "$REL/locales/nl.json"
( cd "$REL" && find assets locales -type f -print0 | sort -z | xargs -0 sha256sum > release_sha256.txt && sha256sum -c release_sha256.txt >/dev/null )
node "$KIT/validate_locales.mjs" "$REL/locales" "$SRC/resources/js" --short
printf 'BUILD=BOOKETIK_R3B8O4_N3_SECTION_I18N\nNODE=%s\nNPM=%s\n' "$(node -v)" "$(npm -v)" > "$REL/BUILD_INFO.txt"
( cd "$WORK" && tar -czf "$OUT/BOOKETIK_R3B8O4_N3_SECTION_I18N_COMPILED_20261110.tar.gz" release )
( cd "$OUT" && sha256sum 'BOOKETIK_R3B8O4_N3_SECTION_I18N_COMPILED_20261110.tar.gz' > 'BOOKETIK_R3B8O4_N3_SECTION_I18N_COMPILED_20261110.tar.gz.sha256' )
echo 'BUILD=PASS HOMEPAGE_I18N=PASS NL_SECTION_KEY=PASS FR=PASS NL_MVP=PARTIAL SSR_FILES=PASS'
echo "ARTIFACT=$OUT/BOOKETIK_R3B8O4_N3_SECTION_I18N_COMPILED_20261110.tar.gz"
