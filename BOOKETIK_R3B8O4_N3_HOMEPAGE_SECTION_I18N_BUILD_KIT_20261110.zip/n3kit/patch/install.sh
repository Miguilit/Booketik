#!/usr/bin/env bash
set -euo pipefail
APP="$(cd "${1:?Laravel application directory needed}" && pwd -P)"
[[ "${2:-}" == '--apply' ]] || { echo 'APPLY_CONFIRMATION_REQUIRED'; exit 2; }
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
bash "$PKG/preflight.sh" "$APP"
ROOT="$(dirname "$APP")"
BACKUP="$(mktemp -d "$ROOT/booketik_r3b8o4_code_backup_$(date -u +%Y%m%dT%H%M%SZ)_XXXX")"
while read -r digest path; do
  mkdir -p "$BACKUP/$(dirname "$path")"
  cp -p "$APP/$path" "$BACKUP/$path"
done < "$PKG/source_hashes.txt"
echo "CODE_BACKUP_PATH=$BACKUP"
rollback_on_error() {
  ret=$?
  if ((ret != 0)); then
    echo "CODE_INSTALL_FAILED=$ret ATTEMPT_ROLLBACK=YES"
    bash "$PKG/rollback.sh" "$APP" "$BACKUP" --force-partial || echo 'MANUAL_CODE_ROLLBACK_REQUIRED'
  fi
}
trap rollback_on_error EXIT
while read -r digest path; do
  mkdir -p "$APP/$(dirname "$path")"
  cp -p "$PKG/files/$path" "$APP/$path"
done < "$PKG/package_hashes.txt"
bash "$PKG/verify.sh" "$APP"
trap - EXIT
echo 'INSTALL=PASS MIGRATIONS=0 DB_WRITES=0 EVENT_WRITES=0 NO_PRICING_CHANGE=YES'
