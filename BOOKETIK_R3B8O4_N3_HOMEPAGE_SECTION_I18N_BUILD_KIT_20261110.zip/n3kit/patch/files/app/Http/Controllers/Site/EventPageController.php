<?php

declare(strict_types=1);

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Api\V1\Events\CallForSpeakersController;
use App\Http\Controllers\Api\V1\Events\EventController as ApiEventController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Site\Concerns\ReadsApi;
use App\Models\Event;
use App\Models\Organizer;
use App\Models\ExternalEventClaim;
use App\Enums\OrganizerRole;
use App\Services\Events\External\ExternalEventClaimIntake;
use App\Services\Events\External\ExternalEventVisibility;
use App\Models\Sponsor;
use App\Support\AccentContrast;
use App\Support\EventJsonLd;
use App\Support\Image;
use App\Support\ImagePreload;
use App\Support\PageMeta;
use App\Support\Themes\ThemeResolver;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

/**
 * The event page (`/e/{slug}`) and the conference agenda (`/e/{slug}/agenda`).
 *
 * Props are the API's EventDetail, TicketType, Session and Speaker shapes
 * (tests/Fixtures/api), plus what only the web needs: the contrast-guarded
 * accent as CSS variables (AccentContrast), the schema.org JSON-LD the root
 * view prints, and the page meta.
 */
class EventPageController extends Controller
{
    use ReadsApi;

    public function show(Request $request): Response
    {
        return Inertia::render('Site/Event', $this->props($request, full: false));
    }

    public function agenda(Request $request): Response
    {
        $props = $this->props($request, full: true);
        abort_unless(($props['event']['modules']['agenda'] ?? false) === true, 404);

        return Inertia::render('Site/Agenda', $props);
    }

    /** @return array<string, mixed> */
    private function props(Request $request, bool $full): array
    {
        $slug = (string) $request->route('slug');
        $event = $this->apiData([ApiEventController::class, 'show'], ['slug' => $slug], ['source' => 'web']);
        $modules = $event['modules'] ?? [];
        $code = $request->query('code');

        $tiers = ($modules['tickets'] ?? true)
            ? $this->apiData([ApiEventController::class, 'tickets'], ['slug' => $slug], is_string($code) ? ['code' => $code] : [])
            : [];
        $sessions = ($modules['agenda'] ?? false) ? $this->apiData([ApiEventController::class, 'agenda'], ['slug' => $slug]) : [];
        $speakers = (($modules['speakers'] ?? false) || ($modules['agenda'] ?? false)) ? $this->apiData([ApiEventController::class, 'speakers'], ['slug' => $slug]) : [];

        $model = Event::query()->with(['organizer', 'cover', 'externalListing.source'])->findOrFail($event['id']);

        $sponsors = ($modules['sponsors'] ?? false)
            ? Sponsor::query()->with('logo')->where('event_id', $model->id)->orderBy('sort_order')->get()
                ->map(fn (Sponsor $s) => ['name' => $s->name, 'tier' => $s->tier, 'url' => $s->url, 'logo' => Image::from($s->logo, 400, 200)])
                ->values()->all()
            : [];

        // R3-B8-O2: a claim invitation is a link to manual organizer verification,
        // NEVER permission to sell tickets or take ownership of an imported event.
        // The same visibility authority as the public API protects guessed URLs.
        $externalClaim = null;
        if (isset($event['external'])
            && $model->externalListing !== null
            && app(ExternalEventVisibility::class)->mayShow($model)) {
            $locale = strtolower((string) app()->getLocale());
            $copy = match ($locale) {
                'fr' => [
                    'title' => 'Vous organisez cet événement ?',
                    'pitch' => 'Besoin d’une billetterie éthique, simple et accessible ?',
                    'description' => 'Confiez votre billetterie à BOOKETIK et concentrez-vous sur votre événement. Revendiquez gratuitement cette fiche pour développer votre visibilité et découvrir BOOKETIK Pro, sans engagement.',
                    'action' => 'Revendiquer mon événement',
                ],
                'nl' => [
                    'title' => 'Organiseert u dit evenement?',
                    'pitch' => 'Op zoek naar een eerlijke, eenvoudige en toegankelijke ticketservice?',
                    'description' => 'Laat uw ticketverkoop aan BOOKETIK over en concentreer u op uw evenement. Claim deze vermelding gratis en ontdek BOOKETIK Pro, zonder verplichting.',
                    'action' => 'Mijn evenement claimen',
                ],
                default => [
                    'title' => 'Are you organizing this event?',
                    'pitch' => 'Need fair, simple and accessible ticketing?',
                    'description' => 'Let BOOKETIK handle ticket sales while you focus on your event. Claim this listing for free and discover BOOKETIK Pro, with no obligation.',
                    'action' => 'Claim my event',
                ],
            };
            $routeArgs = ['locale' => $request->route('locale') ?: app()->getLocale(), 'slug' => $model->slug];
            $user = $request->user();
            $mine = $user ? ExternalEventClaim::query()->where('listing_id', $model->externalListing->id)
                ->where('requested_by', $user->id)->first() : null;
            $organizers = $user ? Organizer::query()->active()->whereHas('members', fn ($q) => $q
                ->where('user_id', $user->id)
                ->whereIn('role', [OrganizerRole::Owner->value, OrganizerRole::Admin->value]))
                ->orderBy('name')->get(['id', 'name'])->toArray() : [];
            $externalClaim = $copy + [
                'url' => route('site.event', $routeArgs).'#claim',
                'beginUrl' => route('site.external-claims.begin', $routeArgs),
                'finishUrl' => route('site.external-claims.finish', $routeArgs),
                'evidenceUrl' => route('site.external-claims.evidence', $routeArgs),
                'intent' => app(ExternalEventClaimIntake::class)->pending($request, $model->slug, (string) $model->externalListing->id),
                'mine' => $mine ? ['status' => $mine->status, 'hasEvidence' => filled($mine->verification_url)] : null,
                'organizers' => $organizers,
            ];
        }

        $event['postponed'] = $model->postponed_at !== null;
        $call = CallForSpeakersController::find($request, $slug);

        return [
            'event' => $event,
            'externalClaim' => $externalClaim,
            'tiers' => $tiers,
            'sessions' => $full ? $sessions : array_slice($sessions, 0, 6),
            'sessionCount' => count($sessions),
            'speakers' => $speakers,
            'sponsors' => $sponsors,
            // The call for speakers, while it is open or for someone who submitted.
            'callForSpeakers' => $call !== null ? CallForSpeakersController::shape($call[0], $call[1], $request->user()) : null,
            'accent' => AccentContrast::cssVariables($event['theme_accent'] ?? null),
            'referral' => is_string($request->query('ref')) ? mb_substr($request->query('ref'), 0, 64) : null,
            'unlockCode' => is_string($code) ? mb_substr($code, 0, 64) : null,
            'jsonLd' => isset($event['external']) ? null : EventJsonLd::encode(EventJsonLd::build($event, $tiers, $speakers)),
            'meta' => PageMeta::forEvent($model)->toArray(),
            // The cover is the LCP element; start fetching it before the app renders.
            'preloadImage' => ImagePreload::for($event['cover'] ?? null, ...(ThemeResolver::for($request) === 'marquee'
                ? ['(min-width: 1024px) 380px, 100vw', 1.25]
                : ['(min-width: 1024px) 760px, 100vw', 2 / 3])),
        ];
    }
}
