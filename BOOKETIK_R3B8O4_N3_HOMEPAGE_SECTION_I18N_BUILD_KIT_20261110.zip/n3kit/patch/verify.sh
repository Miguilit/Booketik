#!/usr/bin/env bash
set -euo pipefail
APP="$(cd "${1:?Laravel application directory needed}" && pwd -P)"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
( cd "$APP" && sha256sum -c "$PKG/package_hashes.txt" >/dev/null ) || { echo 'VERIFY_SHA=FAIL'; exit 2; }
PHP="${BOOKETIK_PHP_BIN:-/opt/alt/php84/usr/bin/php}"
while IFS= read -r _ path; do
  case "$path" in *.php) "$PHP" -l "$APP/$path" >/dev/null ;; esac
done < "$PKG/package_hashes.txt"
echo 'VERIFY_SHA=PASS PHP_LINT=PASS FR_NL_ASSETS=IN_RELEASE'
