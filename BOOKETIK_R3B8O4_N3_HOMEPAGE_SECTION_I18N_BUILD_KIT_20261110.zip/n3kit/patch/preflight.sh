#!/usr/bin/env bash
set -euo pipefail
APP="$(cd "${1:?Laravel application directory needed}" && pwd -P)"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
[[ -f "$APP/artisan" && -f "$APP/routes/web.php" ]] || { echo 'APP_ROOT_INVALID'; exit 2; }
( cd "$PKG/files" && sha256sum -c "$PKG/package_hashes.txt" >/dev/null ) || { echo 'PACKAGE_SHA_GUARDS=FAIL'; exit 2; }
( cd "$APP" && sha256sum -c "$PKG/source_hashes.txt" >/dev/null ) || { echo 'SOURCE_SHA_GUARDS=FAIL'; exit 2; }
while IFS= read -r path; do
  [[ -n "$path" ]] || continue
  [[ ! -e "$APP/$path" ]] || { echo "NEW_PATH_DRIFT_REFUSAL=$path"; exit 2; }
done < "$PKG/new_paths.txt"
[[ -d "$APP/lang/nl" ]] || { echo 'NL_LARAVEL_DIRECTORY_MISSING'; exit 2; }
PHP="${BOOKETIK_PHP_BIN:-/opt/alt/php84/usr/bin/php}"
[[ -x "$PHP" ]] || { echo 'PHP84_MISSING'; exit 2; }
while IFS= read -r _ path; do
  case "$path" in *.php) "$PHP" -l "$PKG/files/$path" >/dev/null ;; esac
done < "$PKG/package_hashes.txt"
"$PHP" -r 'foreach(["fr","nl","en"] as $c){}; $n=json_decode(file_get_contents($argv[1]),true); if(!is_array($n)||count($n)<150)exit(1);' "$PKG/files/resources/lang/nl.json" || { echo 'NL_DICTIONARY_INVALID'; exit 2; }
echo 'PREFLIGHT=PASS SOURCE_SHA_GUARDS=PASS PACKAGE_SHA_GUARDS=PASS EXISTING_EVENT_WRITES=0 MIGRATIONS=0 PRICING_CHANGES=0'
