BOOKETIK R3-B8-O4-N3 — Localize CMS-driven homepage section headings (FR/NL)

This minimal N3 build is based on the certified N2 kit and original O2 source archive.
It preserves the O3 inline claim and N2 locale fixes.
Change set:
  - 3 homepage theme components: wrap section.title in t(...)
  - nl.json: Browse by category => Ontdek per categorie
  - fr.json: Browse by category => Explorer par catégorie

Build: bash n3kit/build.sh BOOKETIK_R3B8O2_FRONTEND_BUILD_SOURCE_20261109T133219Z.tar.gz .
Builds Vite client and SSR in GitHub Actions. This is NOT a Hostinger deployment.
No Laravel/database mutations, no change in event pricing or ticketing.
After GitHub artifact inspection, deploy via a separately guarded Hostinger release.
