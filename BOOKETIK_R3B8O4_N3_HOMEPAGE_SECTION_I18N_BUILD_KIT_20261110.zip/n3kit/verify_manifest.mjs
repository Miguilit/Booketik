import fs from 'node:fs';
import path from 'node:path';
const src = process.argv[2];
if (!src) process.exit(1);
const build = path.join(src, 'public/build');
const manifest = JSON.parse(fs.readFileSync(path.join(build, 'manifest.json'), 'utf8'));
for (const key of ['resources/js/app.jsx', 'resources/js/Themes/civic/Pages/Site/Event.jsx', 'resources/js/Themes/almanac/Pages/Site/Event.jsx', 'resources/js/Themes/marquee/Pages/Site/Event.jsx']) {
  const name = manifest[key]?.file;
  if (typeof name !== 'string' || !name.startsWith('assets/') || !fs.existsSync(path.join(build, name))) {
    throw new Error(`Missing compiled entry ${key}`);
  }
}
console.log('VITE_MANIFEST=PASS');
