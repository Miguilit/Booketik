import fs from 'node:fs';
import path from 'node:path';
const dir = process.argv[2];
const jsRoot=process.argv[3];
const short = process.argv.includes('--short');
const refDir=path.resolve(path.dirname(new URL(import.meta.url).pathname),'dictionaries');
const read=(language)=>JSON.parse(fs.readFileSync(path.join(dir,language+'.json'),'utf8'));
const en=JSON.parse(fs.readFileSync(path.join(refDir,'en.json'),'utf8'));
const fr=read('fr'), nl=read('nl');
const keys=Object.keys(en);
if(keys.some(k=>!fr[k]))throw Error('FR_REFERENCE_GAP');
if(keys.filter(k=>nl[k]).length<1250)throw Error('NL_COVERAGE_BELOW_N2_FLOOR');
const re=/(?<!\w):[A-Za-z_][A-Za-z_0-9]*|\{[A-Za-z_][A-Za-z_0-9]*\}/g;
for(const [lang,m] of [['fr',fr],['nl',nl]]) {
 for(const [k,v] of Object.entries(m)) {
  if(typeof v !=='string'||!v)throw Error('EMPTY_TRANSLATION_'+lang+'_'+k);
  if(k in en){
   const a=[...new Set(k.match(re)||[])].sort().join('|');
   const b=[...new Set(v.match(re)||[])].sort().join('|');
   if(a!==b)throw Error('PLACEHOLDERS_CHANGED_'+lang+'_'+k);
  }
 }
}
for(const k of ['Browse by category','Explore','You','About','Near you this week','On the map','Your email','Subscribe','Tickets','Sign in','Create your account','How It Works','FAQs','Terms of Service']){
 if(!fr[k]||!nl[k])throw Error('MVP_CORE_TRANSLATION_MISSING_'+k);
}
for(const theme of ['civic','almanac','marquee']){
 const f=path.join(jsRoot,'Themes',theme,'Layout.jsx');
 if(!fs.readFileSync(f,'utf8').includes('name: t(p.title)'))throw Error('FOOTER_LOCALE_GATE_'+theme);
 const site=path.join(jsRoot,'Themes',theme,'Pages','Site');
 if(fs.existsSync(site))for(const page of fs.readdirSync(site).filter(f=>f.endsWith('.jsx'))){
  const code=fs.readFileSync(path.join(site,page),'utf8');
  const labels=[...code.matchAll(/\bt\(\s*(['\"])(.*?)\1/g)].map(m=>m[2]).filter(k=>k in en);
  for(const key of labels)if(!nl[key])throw Error('MVP_SITE_NL_GAP_'+theme+'_'+page+'_'+key);
 }
}
console.log('FR_REF_KEYS='+keys.length+' NL_TRANSLATED_REF_KEYS='+keys.filter(k=>nl[k]).length+' NL_COVERAGE_PCT='+ (keys.filter(k=>nl[k]).length/keys.length*100).toFixed(1)+' MVP_PUBLIC_SMOKE=PASS LOCALE_PLACEHOLDERS=PASS');
