import { LayoutGrid } from 'lucide-react';
import { Empty, Panel, RoomRow } from './ui';
import { venueLink } from './Shell';

export default function Layouts({ rooms, current }) {
    return <div className="space-y-6"><div><span className="font-mono text-xs uppercase tracking-widest text-muted">Configurations des lieux</span><h1 className="mt-2 font-display text-3xl font-bold text-ink">Configurations</h1><p className="mt-2 text-sm text-muted">Les plans enregistrés sont versionnés. Plusieurs dispositions par salle seront ajoutées avec le moteur géométrique.</p></div><Panel title="Dernières configurations"><div className="space-y-3">{rooms.filter(r => r.layout_revision).length ? rooms.filter(r => r.layout_revision).map(room => <RoomRow key={room.id} room={room} href={venueLink(current, 'studio', room.id)}/>) : <Empty icon={LayoutGrid} title="Aucun plan sauvegardé" text="Ouvrez le Seating Studio pour enregistrer la première configuration d'une salle."/>}</div></Panel></div>;
}
