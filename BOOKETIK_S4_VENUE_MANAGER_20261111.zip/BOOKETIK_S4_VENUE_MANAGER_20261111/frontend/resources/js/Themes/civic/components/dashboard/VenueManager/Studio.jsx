import { useMemo, useState } from 'react';
import { router } from '@inertiajs/react';
import { ArrowLeft, Check, Download, MousePointer2, RotateCcw, Save, WandSparkles } from 'lucide-react';
import SeatCanvas from '@/Themes/civic/components/dashboard/BooketikStudios/components/SeatCanvas';
import { downloadDraft, generateRows, planErrors, starterPlan } from '@/Themes/civic/components/dashboard/BooketikStudios/core/model';
import { venueLink } from './Shell';
import { Empty, Panel, Status, inputClass, primaryClass, secondaryClass } from './ui';

const fresh = v => JSON.parse(JSON.stringify(v));

export default function Studio({ venue, plan: initialPlan, revision = 0, urls, current }) {
    const base = initialPlan || starterPlan;
    const [plan, setPlan] = useState(() => fresh(base));
    const [activeZone, setActiveZone] = useState(base.zones?.[0]?.id || '');
    const [selected, setSelected] = useState(null);
    const [dirty, setDirty] = useState(false);
    const [rows, setRows] = useState(7);
    const [perRow, setPerRow] = useState(10);
    const [saving, setSaving] = useState(false);
    const [detail, setDetail] = useState({ name: venue?.name || '', address_line1: venue?.address || '' });
    const [detailSaving, setDetailSaving] = useState(false);
    const errors = useMemo(() => planErrors(plan), [plan]);
    const patch = fn => { setPlan(fn); setDirty(true); };
    const paint = seat => { setSelected(seat); patch(p => ({ ...p, seats: p.seats.map(s => s.id === seat.id ? { ...s, zone_id: activeZone } : s) })); };
    const updateColor = (id, color) => patch(p => ({ ...p, zones: p.zones.map(z => z.id === id ? { ...z, color } : z) }));
    const updateLabel = (id, label) => patch(p => ({ ...p, zones: p.zones.map(z => z.id === id ? { ...z, label } : z) }));
    const generate = () => {
        if (dirty && typeof window !== 'undefined' && !window.confirm('Remplacer le plan non enregistré ?')) return;
        patch(p => generateRows(rows, perRow, p.zones));
        setSelected(null);
    };
    const save = () => {
        if (saving || errors.length || !urls.saveLayout) return;
        router.post(urls.saveLayout, { plan, expected_revision: revision }, { preserveScroll: true, onStart: () => setSaving(true), onFinish: () => setSaving(false) });
    };
    if (!venue) return <Empty icon={MousePointer2} title="Choisissez une salle" text="Créez ou sélectionnez une salle avant d'éditer son plan." action={<a href={venueLink(current, 'rooms')} className={primaryClass}>Voir mes salles</a>}/>;
    return <div className="space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-3"><div><a href={venueLink(current, 'rooms')} className="inline-flex items-center gap-1 text-sm text-link"><ArrowLeft className="h-4 w-4"/>Mes salles</a><h1 className="mt-2 font-display text-3xl font-bold text-ink">{venue.name}</h1><p className="mt-2 text-sm text-muted">Seating Studio · Configuration physique, sans prix ni vente.</p></div><div className="flex flex-wrap items-center gap-2"><Status tone={revision ? 'success' : 'attention'}>{revision ? `Brouillon v${revision}` : 'Plan non enregistré'}</Status>{dirty && <Status tone="attention">Modifications non enregistrées</Status>}</div></div>
        <div className="grid items-start gap-5 xl:grid-cols-[330px_minmax(0,1fr)]">
            <div className="space-y-5">
                <Panel title="Disposition" description="Générez une première trame de sièges."><div className="grid grid-cols-2 gap-3"><label className="text-sm font-semibold text-ink">Rangées<input type="number" min="1" max="30" value={rows} onChange={e => setRows(e.target.value)} className={`mt-2 ${inputClass}`}/></label><label className="text-sm font-semibold text-ink">Sièges / rangée<input type="number" min="1" max="35" value={perRow} onChange={e => setPerRow(e.target.value)} className={`mt-2 ${inputClass}`}/></label></div><button type="button" onClick={generate} className={`mt-4 w-full ${secondaryClass}`}><WandSparkles className="h-4 w-4"/>Générer les sièges</button><p className="mt-3 text-xs leading-relaxed text-muted">Les rangées courbes et la reconnaissance de formes arriveront avec le moteur géométrique S5.</p></Panel>
                <Panel title="Zones physiques" description="Sélectionnez une zone, puis touchez les sièges à lui attribuer."><label className="text-sm font-semibold text-ink">Pinceau actif<select value={activeZone} onChange={e => setActiveZone(e.target.value)} className={`mt-2 ${inputClass}`}>{plan.zones.map(z => <option key={z.id} value={z.id}>{z.label}</option>)}</select></label><div className="mt-4 space-y-3">{plan.zones.map(z => <div key={z.id} className="flex items-center gap-3"><input type="color" aria-label={`Couleur ${z.label}`} value={z.color} onChange={e => updateColor(z.id, e.target.value)} className="h-10 w-10 shrink-0 cursor-pointer rounded-lg border border-line bg-surface p-1"/><label className="flex-1"><span className="sr-only">Libellé de zone</span><input className={`${inputClass} !py-2`} maxLength={80} value={z.label} onChange={e => updateLabel(z.id, e.target.value)}/></label></div>)}</div>{selected && <p className="mt-3 text-xs text-muted">Sélection : rangée {selected.row}, siège {selected.number}</p>}</Panel>
            </div>
            <div className="min-w-0 space-y-5"><Panel title="Plan de salle" description={`${plan.seats.length} places disposées · Cliquez sur un siège pour lui attribuer la zone active.`}><SeatCanvas plan={plan} onPick={paint}/>{errors.length > 0 && <div role="alert" className="mt-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800">{errors.join(' · ')}</div>}<div className="mt-5 flex flex-wrap gap-2"><button type="button" onClick={save} disabled={!dirty || errors.length > 0 || saving || !urls.saveLayout} className={primaryClass}><Save className="h-4 w-4"/>{saving ? 'Enregistrement…' : 'Enregistrer le brouillon'}</button><button type="button" onClick={() => downloadDraft('booketik-plan.json', {venue, plan})} className={secondaryClass}><Download className="h-4 w-4"/>Exporter JSON</button><button type="button" onClick={() => { setPlan(fresh(base)); setSelected(null); setDirty(false); }} className={secondaryClass}><RotateCcw className="h-4 w-4"/>Annuler les modifications</button></div></Panel>
                <Panel title="Informations du lieu" description="Ces modifications n'affectent ni les billets ni le plan."><form className="grid gap-3 sm:grid-cols-2" onSubmit={e => {e.preventDefault(); if (!urls.saveVenue || detailSaving) return; router.post(urls.saveVenue, detail, { preserveScroll: true, onStart: () => setDetailSaving(true), onFinish: () => setDetailSaving(false) });}}><label className="text-sm font-semibold text-ink">Nom<input required maxLength={160} className={`mt-2 ${inputClass}`} value={detail.name} onChange={e => setDetail(v => ({...v, name:e.target.value}))}/></label><label className="text-sm font-semibold text-ink">Adresse<input maxLength={255} className={`mt-2 ${inputClass}`} value={detail.address_line1} onChange={e => setDetail(v => ({...v,address_line1:e.target.value}))}/></label><div className="sm:col-span-2"><button type="submit" disabled={detailSaving || !detail.name.trim()} className={secondaryClass}><Check className="h-4 w-4"/>Enregistrer les informations</button></div></form></Panel>
            </div>
        </div>
    </div>;
}
