import { useState } from 'react';
import { router } from '@inertiajs/react';
import { ShieldCheck, UsersRound } from 'lucide-react';
import { Empty, Panel, Status, inputClass, primaryClass, secondaryClass } from './ui';
import { venueLink } from './Shell';

export default function Partners({ rooms, venue, urls, current }) {
    const [organizerId, setOrganizerId] = useState('');
    const [busy, setBusy] = useState(false);
    const grants = venue?.access || [];
    const doGrant = (id, enabled) => {
        if (!urls.grant || busy) return;
        router.post(urls.grant, { organizer_id:id, enabled }, { preserveScroll: true, onStart: () => setBusy(true), onFinish: () => setBusy(false) });
    };
    return <div className="space-y-6"><div><span className="font-mono text-xs uppercase tracking-widest text-muted">Partage sécurisé</span><h1 className="mt-2 font-display text-3xl font-bold text-ink">Organisateurs autorisés</h1><p className="mt-2 max-w-2xl text-sm text-muted">Autoriser l'utilisation d'une configuration n'accorde ni la propriété de la salle, ni l'accès aux revenus de l'organisateur.</p></div>
        {rooms.length > 0 && <Panel title="Salle concernée" description="Choisissez le lieu dont vous souhaitez gérer les accès."><div className="flex flex-wrap gap-2">{rooms.map(room => <a key={room.id} href={venueLink(current, 'partners', room.id)} aria-current={room.id === venue?.id ? 'page' : undefined} className={`${secondaryClass} ${room.id === venue?.id ? 'border-ink' : ''}`}>{room.name}</a>)}</div></Panel>}
        {!venue ? <Empty icon={UsersRound} title="Aucune salle sélectionnée" text="Ajoutez une salle pour définir quels organisateurs peuvent utiliser ses configurations."/> : <Panel title={`Accès · ${venue.name}`} description="Les autorisations sont enregistrées côté serveur."><div className="space-y-3">{grants.length ? grants.map(g => <div className="flex flex-wrap items-center gap-3 rounded-xl border border-line p-4" key={g.organizer_id}><span className="rounded-xl bg-raised p-3"><UsersRound className="h-5 w-5 text-ink"/></span><div className="min-w-0 flex-1"><p className="font-bold text-ink">{g.organizer_name}</p><p className="text-xs text-muted">Accès au plan, sans accès à la caisse</p></div><Status tone={g.status === 'granted' ? 'success' : 'neutral'}>{g.status === 'granted' ? 'Autorisé' : 'Révoqué'}</Status><button type="button" disabled={busy} className={secondaryClass} onClick={() => doGrant(g.organizer_id, g.status !== 'granted')}>{g.status === 'granted' ? 'Révoquer' : 'Réautoriser'}</button></div>) : <Empty icon={ShieldCheck} title="Aucune autorisation" text="Les organisateurs ne peuvent pas utiliser cette configuration tant qu'ils n'ont pas reçu une autorisation."/>}</div><form className="mt-5 flex flex-wrap gap-2 border-t border-line pt-5" onSubmit={e => { e.preventDefault(); doGrant(organizerId.trim(), true); setOrganizerId(''); }}><label className="min-w-[220px] flex-1 text-sm font-semibold text-ink">Identifiant UUID de l'organisateur<input value={organizerId} onChange={e => setOrganizerId(e.target.value)} className={`mt-2 ${inputClass}`} placeholder="Identifiant de l'organisateur"/></label><div className="flex items-end"><button className={primaryClass} type="submit" disabled={busy || !/^[0-9a-fA-F-]{36}$/.test(organizerId)}>Autoriser</button></div></form><p className="mt-3 text-xs leading-relaxed text-muted">Pour cette première version, l'autorisation utilise l'identifiant de l'organisateur. La recherche par nom et les invitations seront ajoutées lors de la refonte du parcours fournisseur.</p></Panel>}
    </div>;
}
