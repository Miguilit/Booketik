import { Activity, CalendarDays, Settings2, Users } from 'lucide-react';
import { Empty, Panel, Status } from './ui';

export function Upcoming({ type }) {
    const info = {
        events: [CalendarDays, 'Calendrier des événements', 'Les réservations de dates, les occupations et les informations événementielles seront reliées aux permissions de chaque organisateur.'],
        team: [Users, 'Équipe et autorisations', 'Le partage sécurisé du compte fournisseur nécessitera des rôles de propriétaire, administrateur de salle et technicien de placement.'],
    }[type];
    const [Icon, title, text] = info;
    return <div className="space-y-6"><div className="flex items-center gap-3"><h1 className="font-display text-3xl font-bold text-ink">{title}</h1><Status>En préparation</Status></div><Empty icon={Icon} title="Cette section arrive dans une prochaine étape" text={text}/></div>;
}

export function Insights({ metrics }) {
    const items = [
        ['Salles enregistrées', metrics?.venue_count],
        ['Salles disposant d’un plan', metrics?.configured_venue_count],
        ['Sièges configurés', metrics?.seat_count],
        ['Accès organisateurs actifs', metrics?.partner_count],
    ];
    return <div className="space-y-6"><div><span className="font-mono text-xs uppercase tracking-widest text-muted">Données vérifiées</span><h1 className="mt-2 font-display text-3xl font-bold text-ink">Statistiques</h1><p className="mt-2 text-sm text-muted">Premières mesures calculées à partir des salles, plans enregistrés et autorisations réelles.</p></div><Panel title="Activité des salles"><div className="grid gap-4 sm:grid-cols-2">{items.map(([label, value]) => <div key={label} className="rounded-xl border border-line p-5"><p className="text-sm text-muted">{label}</p><p className="mt-2 font-display text-3xl font-bold tabular-nums text-ink">{value ?? '—'}</p></div>)}</div><p className="mt-5 text-xs leading-relaxed text-muted">Les taux de remplissage et de fréquentation seront activés après raccordement des séances et des autorisations de consultation. Aucune donnée de recettes organisateur n'est exposée.</p></Panel></div>;
}

export function Settings({ provider }) {
    return <div className="space-y-6"><h1 className="font-display text-3xl font-bold text-ink">Paramètres fournisseur</h1><Panel title="Identité de l'espace" description="Informations actuellement enregistrées pour le propriétaire."><dl className="space-y-4 text-sm"><div className="flex justify-between gap-3 border-b border-line pb-3"><dt className="text-muted">Nom du fournisseur</dt><dd className="font-semibold text-ink">{provider?.name || '—'}</dd></div><div className="flex justify-between gap-3 border-b border-line pb-3"><dt className="text-muted">État</dt><dd className="font-semibold text-ink">{provider?.status === 'active' ? 'Actif' : provider?.status || '—'}</dd></div><div className="flex justify-between gap-3"><dt className="text-muted">Fonctionnalités de salle</dt><dd className="font-semibold text-ink">Natives · Sans abonnement</dd></div></dl></Panel><Empty icon={Settings2} title="Profil professionnel à compléter" text="L'identité légale, les coordonnées, les membres de l'équipe et les informations publiques du fournisseur seront regroupés ici dans le prochain lot."/></div>;
}
