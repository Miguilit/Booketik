import { useState } from 'react';
import { router } from '@inertiajs/react';
import { Building2, MapPin, Plus } from 'lucide-react';
import { Empty, Panel, RoomRow, inputClass, primaryClass, secondaryClass } from './ui';
import { venueLink } from './Shell';

export default function Rooms({ rooms, urls, current, selectedRoom }) {
    const [open, setOpen] = useState(rooms.length === 0);
    const [form, setForm] = useState({ name: '', address_line1: '', city: '', timezone: 'Europe/Brussels' });
    const [busy, setBusy] = useState(false);
    const [query, setQuery] = useState('');
    const filtered = rooms.filter(r => `${r.name} ${r.city || ''} ${r.address || ''}`.toLocaleLowerCase().includes(query.toLocaleLowerCase()));
    const update = (field, value) => setForm(s => ({ ...s, [field]: value }));
    const submit = e => {
        e.preventDefault();
        if (!urls.createVenue || busy) return;
        router.post(urls.createVenue, form, { preserveScroll: true, onStart: () => setBusy(true), onFinish: () => setBusy(false) });
    };
    return <div className="space-y-6">
        <div className="flex flex-wrap items-end justify-between gap-4"><div><span className="font-mono text-xs uppercase tracking-widest text-muted">Patrimoine des lieux</span><h1 className="mt-2 font-display text-3xl font-bold text-ink">Mes salles</h1><p className="mt-2 text-sm text-muted">Une fiche par salle, plusieurs configurations à venir.</p></div><button type="button" onClick={() => setOpen(!open)} className={primaryClass}><Plus className="h-4 w-4"/>{open ? 'Fermer le formulaire' : 'Ajouter une salle'}</button></div>
        {open && <Panel title="Nouvelle salle" description="Créez d'abord l'identité du lieu. Son plan de placement sera configuré ensuite."><form onSubmit={submit} className="grid gap-4 md:grid-cols-2 xl:grid-cols-3"><label className="block text-sm font-semibold text-ink">Nom de la salle<input required maxLength={160} className={`mt-2 ${inputClass}`} value={form.name} onChange={e => update('name', e.target.value)} placeholder="Ex. Théâtre communal"/></label><label className="block text-sm font-semibold text-ink">Adresse<input maxLength={255} className={`mt-2 ${inputClass}`} value={form.address_line1} onChange={e => update('address_line1', e.target.value)} placeholder="Rue et numéro"/></label><label className="block text-sm font-semibold text-ink">Ville<input maxLength={160} className={`mt-2 ${inputClass}`} value={form.city} onChange={e => update('city', e.target.value)} placeholder="Ex. Bruxelles"/></label><div className="md:col-span-2 xl:col-span-3 flex flex-wrap items-center gap-3"><button type="submit" disabled={busy || !form.name.trim()} className={primaryClass}>{busy ? 'Création…' : 'Enregistrer la salle'}</button><button type="button" onClick={() => setOpen(false)} className={secondaryClass}>Annuler</button></div></form></Panel>}
        <Panel title={`${rooms.length} salle${rooms.length > 1 ? 's' : ''}`} description="Les capacités correspondent aux plans enregistrés, pas à une déclaration théorique." action={<label className="w-full max-w-xs"><span className="sr-only">Rechercher une salle</span><input className={inputClass} value={query} onChange={e => setQuery(e.target.value)} placeholder="Rechercher un lieu"/></label>}>
            {filtered.length ? <div className="grid gap-3 xl:grid-cols-2">{filtered.map(room => <RoomRow key={room.id} room={room} href={venueLink(current, 'studio', room.id)} selected={room.id === selectedRoom}/>)}</div> : <Empty icon={rooms.length ? MapPin : Building2} title={rooms.length ? 'Aucun résultat' : 'Aucune salle enregistrée'} text={rooms.length ? 'Modifiez votre recherche.' : 'Commencez par créer votre première salle.'}/>}
        </Panel>
    </div>;
}
