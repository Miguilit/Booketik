# BOOKETIK · Venue Manager S4A

Statut : sources préparées. Pas encore compilé ni installé en production.

## Livré

- Dashboard fournisseur professionnel React/Inertia avec navigation latérale responsive et mode sombre natif.
- Indicateurs réels calculés côté Laravel : salles, salles configurées, sièges du dernier plan, autorisations actives.
- Gestion multi-salles avec création persistante et recherche locale.
- Seating Studio réorganisé avec sauvegarde des brouillons, édition des zones et attribution par siège.
- Liste des configurations enregistrées et gestion des autorisations organisateurs.
- Vues séparées pour statistiques réelles et informations fournisseur.
- Emplacements explicites pour Événements et Équipe, sans feindre leur disponibilité.
- Zéro migration, zéro modification du checkout, aucune fonction conditionnée à un abonnement.

## Limites volontaires

- L'éditeur géométrique de formes et dessin assisté appartient à S5, car le contrat `booketik.seating.v1` ne conserve pas les murs ni les contours.
- Les statistiques de fréquentation et de recettes demandent un modèle d'autorisations dédié ; aucun chiffre fictif.
- Les permissions fournisseur sont limitées au propriétaire et aux grants existants ; l'équipe sera livrée séparément.
- Le Ticket Studio et la tarification `TicketType` ne sont pas modifiés.
- Ce lot n'active pas la vente par siège.

## Installation

1. Placer le ZIP à la racine du dépôt GitHub privé, avec l'archive `BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz` issue des dernières sources React.
2. Copier le workflow YAML fourni dans `.github/workflows/booketik-venue-manager-s4a.yml`.
3. Lancer GitHub Actions et récupérer la compilation. Le workflow vérifie les chemins et les nouveaux composants.
4. Exécuter le contrôle Hostinger en lecture seule avant toute intégration du backend.
5. Préparer séparément un déploiement atomique client/SSR + route en conservant les anciens assets, avec rollback, avant d'ouvrir l'interface.

Ne pas remplacer `public/build` ou le contrôleur directement avec les fichiers source.
