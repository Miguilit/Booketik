#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$PWD}"
ROOT="$(cd "$ROOT" && pwd -P)"
[[ -d "$ROOT/eventgoo" ]] || { echo 'S4_APP_ROOT=NOT_FOUND'; exit 2; }
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'S4_PACKAGE_SHA=FAIL'; exit 3; }
APP="$ROOT/eventgoo"
[[ -f "$APP/app/Http/Controllers/Studios/StudioController.php" ]] || { echo 'S4_STUDIO_CONTROLLER=MISSING'; exit 4; }
[[ -f "$APP/app/Services/Studios/StudioStore.php" ]] || { echo 'S4_STUDIO_STORE=MISSING'; exit 5; }
[[ ! -e "$APP/app/Services/Studios/VenueManagerReadModel.php" ]] || { echo 'S4_TARGET_EXISTS_RECONCILE_FIRST'; exit 6; }
PHP="/opt/alt/php84/usr/bin/php"
[[ -x "$PHP" ]] || { echo 'S4_PHP84=MISSING'; exit 7; }
"$PHP" -l "$KIT/backend/app/Services/Studios/VenueManagerReadModel.php" >/dev/null
python3 - "$APP/app/Http/Controllers/Studios/StudioController.php" "$KIT" <<'PY'
import hashlib, pathlib, sys
src = pathlib.Path(sys.argv[1]).read_bytes()
kit = pathlib.Path(sys.argv[2])
expected = (kit/'scripts/controller_s3t3.sha256').read_text().strip()
if hashlib.sha256(src).hexdigest() != expected:
    raise SystemExit('S4_CONTROLLER_SOURCE=SHA_MISMATCH')
if b"Inertia::render('Dashboard/BooketikStudiosStandalone'" not in src:
    raise SystemExit('S4_CONTROLLER_ROUTE=UNEXPECTED')
print('S4_CONTROLLER_SOURCE=PASS')
PY
[[ -f "$APP/database/migrations/2026_11_10_160001_create_booketik_studios_tables.php" ]] || { echo 'S4_STUDIOS_SCHEMA_MISSING'; exit 8; }
printf 'S4_PREFLIGHT=PASS\nS4_NEW_MIGRATIONS=0\nS4_APPLICATION_WRITES=0\nS4_ROUTES=UNCHANGED\nS4_CHECKOUT=UNTOUCHED\n'
