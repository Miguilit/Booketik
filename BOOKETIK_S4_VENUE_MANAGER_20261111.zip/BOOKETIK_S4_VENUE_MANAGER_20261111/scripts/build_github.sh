#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
REPO="$(cd "${1:-$PWD}" && pwd -P)"
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'S4_PACKAGE_SHA=FAIL'; exit 3; }
SOURCE="$REPO/BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz"
[[ -s "$SOURCE" ]] || { echo 'CURRENT_REACT_SOURCE=MISSING'; exit 4; }
DEST="$REPO/_booketik_s4_build"
[[ ! -e "$DEST" ]] || { echo 'S4_BUILD_DIRECTORY=ALREADY_EXISTS'; exit 5; }
mkdir -p "$DEST"
python3 - "$SOURCE" "$DEST" <<'PY'
import os, sys, tarfile
source, dest = sys.argv[1:]
with tarfile.open(source, 'r:gz') as archive:
    members = archive.getmembers()
    for member in members:
        name = member.name
        parts = name.split('/')
        if name.startswith('/') or '..' in parts or member.issym() or member.islnk() or member.isdev():
            raise SystemExit('SOURCE_ARCHIVE=UNSAFE_ENTRY')
        if any(p in ('.env','vendor','node_modules','.git') for p in parts):
            raise SystemExit('SOURCE_ARCHIVE=PRIVATE_ENTRY')
    archive.extractall(dest, filter='data')
PY
if [[ ! -f "$DEST/package.json" && -f "$DEST/source/package.json" ]]; then
  shopt -s dotglob nullglob
  mv "$DEST"/source/* "$DEST"/
  rmdir "$DEST/source"
  shopt -u dotglob nullglob
fi
[[ -f "$DEST/package-lock.json" && -f "$DEST/vite.config.js" && -f "$DEST/resources/js/pages.jsx" ]] || { echo 'CURRENT_SOURCE_LAYOUT=FAIL'; exit 6; }
python3 - "$KIT" "$DEST" <<'PY'
import hashlib, pathlib, shutil, sys
kit, dest = [pathlib.Path(s) for s in sys.argv[1:]]
for root in [kit/'dependencies/s3t3-react', kit/'frontend']:
    for src in sorted(root.rglob('*')):
        if not src.is_file():
            continue
        rel = src.relative_to(root)
        target = dest/rel
        if target.exists() and target.read_bytes() != src.read_bytes():
            raise SystemExit('REACT_SOURCE_CONFLICT=' + str(rel))
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            shutil.copy2(src, target)
print('REACT_OVERLAY=PASS')
PY
cd "$DEST"
npm ci --no-audit --no-fund
npm run build
node - <<'JS'
const fs = require('fs');
const client = JSON.parse(fs.readFileSync('public/build/manifest.json', 'utf8'));
const ssrPath = ['bootstrap/ssr/ssr-manifest.json', 'bootstrap/ssr/manifest.json'].find(p => fs.existsSync(p));
if (!ssrPath) throw Error('SSR_MANIFEST_MISSING');
const ssr = JSON.parse(fs.readFileSync(ssrPath, 'utf8'));
for (const [name, manifest] of [['client', client],['ssr',ssr]]) {
  if (!Object.keys(manifest).some(x => x.endsWith('/BooketikVenueManager.jsx'))) throw Error(`S4_PAGE_MISSING_${name}`);
  if (!Object.keys(manifest).some(x => x.endsWith('/BooketikStudiosStandalone.jsx'))) throw Error(`S3_COMPAT_MISSING_${name}`);
}
console.log(`REACT_CLIENT_MANIFEST=${Object.keys(client).length}`);
console.log(`REACT_SSR_MANIFEST=${Object.keys(ssr).length}`);
JS
OUT="$REPO/BOOKETIK_S4_VENUE_MANAGER_COMPILED_20261111.tar.gz"
tar -czf "$OUT" public/build bootstrap/ssr
(cd "$REPO" && sha256sum "$(basename "$OUT")" > "$(basename "$OUT").sha256")
printf 'S4_REACT_BUILD=PASS\nOUTPUT=%s\n' "$(basename "$OUT")"
