# BOOKETIK Venue Manager — S4A

**Statut : kit source, sans activation en production.**

## Fonctionnalités

Dashboard fournisseur, navigation responsive, création et recherche de salles, accès au Seating Studio, sauvegarde de plans et de zones, accès organisateurs, révisions, statistiques réelles limitées aux capacités déjà installées.

Aucune nouvelle table, aucun module payant, aucune modification des paiements, du checkout ni des QR.

Les fonctionnalités non branchées (calendrier, équipe, dessin libre, configurations multiples) sont explicitement indiquées comme à venir.

## GitHub

Déposer à la racine du dépôt :

- `BOOKETIK_S4_VENUE_MANAGER_20261111.zip`
- `BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz` (archive récente du frontend actuel)

Créer `.github/workflows/booketik-venue-manager-s4a.yml` avec le fichier du package, puis lancer *BOOKETIK Venue Manager S4A React*.

Le workflow compile React client + SSR et produit `BOOKETIK_S4_VENUE_MANAGER_COMPILED_20261111.tar.gz` avec SHA-256.

Le build refuse les conflits avec les fichiers de la base S3/T3 ; il ne remplace pas automatiquement les sources modifiées.

## Hostinger : contrôle préalable uniquement

Déposer le ZIP dans `booketik.com/_private/` puis :

```bash
unzip -q _private/BOOKETIK_S4_VENUE_MANAGER_20261111.zip -d _private/
bash _private/BOOKETIK_S4_VENUE_MANAGER_20261111/scripts/check_hostinger.sh
```

Résultat attendu : `S4_PREFLIGHT=PASS` et `S4_APPLICATION_WRITES=0`.

**Ne pas installer le contrôleur et ne pas remplacer les assets manuellement.** Le déploiement atomique sera préparé uniquement après validation du préflight et de l'archive compilée GitHub.

## Backend livré, non activé

- `backend/app/Services/Studios/VenueManagerReadModel.php` : lecture seule des métriques.
- `backend/patches/StudioController.s4a.diff` : changement ciblé de page fournisseur et ajout des métriques.
- `backend/patches/StudioController.s4a.php` : référence syntaxique, à ne pas copier directement en production.

Le superadmin reste sur son interface S3/T3 ; l'organisateur et le Ticket Studio restent inchangés.
