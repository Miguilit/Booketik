# BOOKETIK S6A3 — Configurations nommées par salle

**SOURCE uniquement : ne pas installer les fichiers PHP directement en production et ne lancer aucune migration à ce stade.** Socle obligatoire : S6A2 actif.

## Contrat fonctionnel

- Le plan général de Rose Blanche et sa publication v7 demeurent inchangés pendant la préparation.
- Créer une configuration nommée (Théâtre / Conférence / Cocktail) copie une ancienne révision générale dans une branche indépendante, sans modifier ni publier l'original.
- Chaque configuration possède des révisions **append-only** et se sauvegarde dans le Seating Studio existant (S5D Auto-Seating conservé), avec verrouillage optimiste sur la révision.
- Renommer, archiver et restaurer sont disponibles ; pas de suppression physique. L'archivage est bloqué si cette configuration est actuellement publiée.
- Publication explicite : un instantané canonique est inséré dans `booketik_venue_layout_revisions`, puis un événement immuable `booketik_venue_publication_events` est ajouté et relié à la configuration source. Il existe **un seul plan courant publié par salle** pour de nouvelles utilisations ; les événements déjà épinglés gardent leurs révisions. Les catégories tarifaires, stocks, checkout et paiements ne changent pas.
- L'historique S6A2 continue d'afficher la série générale, et sa ligne « Publiée » utilise désormais `published_revision` renvoyé par l'API de révisions. Les révisions indépendantes des configurations nommées ne figurent pas encore dans l'historique général : leur suivi détaillé sera ajouté lors de l'UX de branche.

## Schéma ADDITIF (en attente de migration dédiée)

Trois tables nouvelles :

- `booketik_venue_configurations` : identité/état des configurations.
- `booketik_venue_configuration_revisions` : brouillons immuables par configuration.
- `booketik_venue_configuration_publications` : référence à l'événement de publication canonique et à l'original nommé.

**Aucune modification** des tables S3/T3, des événements, des billets, du checkout, ou des 2 colonnes d'archivage S4C. Ne pas exécuter `php artisan migrate` sur la production ; un package Migration Gate séparé suivra après validation des sources et sauvegarde SQL complète.

## GitHub

Placer à la racine les fichiers :

```
BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz
BOOKETIK_S4C_CRUD_20261111.zip
BOOKETIK_S5C_GEOMETRY_SOURCE_20261111.zip
BOOKETIK_S5D_AUTO_SEATING_SOURCE_20261111.zip
BOOKETIK_S6A_PUBLICATION_SOURCE_20261111.zip
BOOKETIK_S6A2_HISTORY_SOURCE_20261111.zip
BOOKETIK_S6A3_NAMED_CONFIGS_SOURCE_20261111.zip
```

Créer `.github/workflows/booketik-s6a3-named.yml` depuis `github/booketik-s6a3-named.yml`. Exécuter Actions → BOOKETIK S6A3 Named Venue Configurations. Livrable attendu : `booketik-s6a3-named-compiled.zip`.

## Hostinger : audit en lecture seule

Déposer le ZIP source dans `_private`, depuis `booketik.com` :

```bash
unzip -q _private/BOOKETIK_S6A3_NAMED_CONFIGS_SOURCE_20261111.zip -d _private/
bash _private/BOOKETIK_S6A3_NAMED_CONFIGS_SOURCE_20261111/scripts/check_hostinger.sh
```

Attendu : `S6A3_READONLY_PREFLIGHT=PASS`, `APPLICATION_WRITES=0`, `DATABASE_WRITES=0`.

L'activation nécessitera une migration sécurisée à partir d'une **nouvelle** sauvegarde SQL et un package deploy distinct avec merge Vite additive et rollback S6A2. La suppression des 3 nouvelles tables après qu'elles contiennent des données n'est pas une procédure de rollback autorisée.
