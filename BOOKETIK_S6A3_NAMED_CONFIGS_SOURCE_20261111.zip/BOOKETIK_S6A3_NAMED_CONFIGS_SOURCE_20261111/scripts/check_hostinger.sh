#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
DOMAIN="$(cd "$KIT/../.." && pwd -P)"
APP="$DOMAIN/eventgoo"
[[ -f "$APP/artisan" && -d "$APP/public/build" && -f "$APP/bootstrap/ssr/ssr-manifest.json" ]] || { echo 'S6A3_APPLICATION_ROOT=FAIL'; exit 4; }
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'S6A3_PACKAGE_SHA=FAIL'; exit 3; }
while read -r hash rel; do
  target="$APP/$rel"
  [[ -f "$target" && "$(sha256sum "$target" | cut -d' ' -f1)" == "$hash" ]] || { echo "S6A3_S6A2_BASELINE=FAIL FILE=$rel"; exit 5; }
done < "$KIT/scripts/host_s6a2_baseline.sha256"
echo 'S6A3_S6A2_BASELINE=PASS'
for f in "$KIT"/backend/app/Services/Studios/*.php "$KIT"/backend/app/Http/Controllers/Studios/*.php "$KIT"/backend/routes/*.php "$KIT"/backend/database/migrations/*.php; do
    /opt/alt/php84/usr/bin/php -l "$f" >/dev/null || { echo "S6A3_PHP_LINT=FAIL FILE=${f##*/}"; exit 6; }
done
echo 'S6A3_PHP_LINT=PASS'
echo 'S6A3_READONLY_PREFLIGHT=PASS'
echo 'S6A3_NEW_SCHEMA=NOT_APPLIED_BY_THIS_SCRIPT'
echo 'APPLICATION_WRITES=0'
echo 'DATABASE_WRITES=0'
