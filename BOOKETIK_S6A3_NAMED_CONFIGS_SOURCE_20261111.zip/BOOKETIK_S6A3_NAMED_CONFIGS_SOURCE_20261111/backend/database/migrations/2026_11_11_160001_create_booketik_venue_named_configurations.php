<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('booketik_venue_configurations', function (Blueprint $t): void {
            $t->uuid('id')->primary();
            $t->foreignUuid('venue_id')->constrained('venues')->restrictOnDelete();
            $t->string('name', 120);
            $t->string('status', 20)->default('active');
            $t->foreignId('created_by_user_id')->constrained('users')->restrictOnDelete();
            $t->foreignId('archived_by_user_id')->nullable()->constrained('users')->restrictOnDelete();
            $t->timestamp('archived_at')->nullable();
            $t->timestamps();
            $t->unique(['venue_id', 'name'], 'bkt_venue_configuration_name_unique');
        });
        Schema::create('booketik_venue_configuration_revisions', function (Blueprint $t): void {
            $t->uuid('id')->primary();
            $t->uuid('configuration_id');
            $t->foreign('configuration_id', 'bkt_cr_configuration_fk')->references('id')->on('booketik_venue_configurations')->restrictOnDelete();
            $t->foreignUuid('venue_id')->constrained('venues')->restrictOnDelete();
            $t->unsignedInteger('revision');
            $t->json('plan');
            $t->foreignId('created_by_user_id')->constrained('users')->restrictOnDelete();
            $t->timestamps();
            $t->unique(['configuration_id', 'revision'], 'bkt_configuration_revision_unique');
        });
        Schema::create('booketik_venue_configuration_publications', function (Blueprint $t): void {
            $t->bigIncrements('id');
            $t->foreignUuid('venue_id')->constrained('venues')->restrictOnDelete();
            $t->uuid('configuration_id');
            $t->foreign('configuration_id', 'bkt_cp_configuration_fk')->references('id')->on('booketik_venue_configurations')->restrictOnDelete();
            $t->uuid('configuration_revision_id');
            $t->foreign('configuration_revision_id', 'bkt_cp_config_revision_fk')->references('id')->on('booketik_venue_configuration_revisions')->restrictOnDelete();
            $t->uuid('layout_revision_id');
            $t->foreign('layout_revision_id', 'bkt_cp_layout_revision_fk')->references('id')->on('booketik_venue_layout_revisions')->restrictOnDelete();
            $t->unsignedBigInteger('publication_event_id')->unique('bkt_named_publication_event_unique');
            $t->foreign('publication_event_id','bkt_named_publication_event_fk')
                ->references('id')->on('booketik_venue_publication_events')->restrictOnDelete();
            $t->timestamp('created_at')->useCurrent();
            $t->index(['venue_id', 'publication_event_id'], 'bkt_named_publication_venue_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('booketik_venue_configuration_publications');
        Schema::dropIfExists('booketik_venue_configuration_revisions');
        Schema::dropIfExists('booketik_venue_configurations');
    }
};
