<?php

declare(strict_types=1);

namespace App\Services\Studios;

use App\Services\Seating\SeatingPlanContract;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use InvalidArgumentException;

/** Independent immutable draft streams; publication snapshots into the legacy venue revision stream. */
final class VenueNamedConfigurations
{
    private const CONFIGS = 'booketik_venue_configurations';
    private const REVISIONS = 'booketik_venue_configuration_revisions';
    private const LINKS = 'booketik_venue_configuration_publications';

    public function __construct(private readonly StudioStore $store, private readonly VenuePublication $publication) {}

    private function fail(string $key, string $message): never
    {
        throw ValidationException::withMessages([$key => $message]);
    }

    private function venue(object $provider, string $venueId, bool $lock = false): void
    {
        $this->store->ownsVenue($provider, $venueId, $lock);
    }

    private function owned(object $provider, string $venueId, string $configId, bool $lock = false): object
    {
        $this->venue($provider, $venueId, $lock);
        $q = DB::table(self::CONFIGS)->where('venue_id', $venueId)->where('id', $configId);
        return ($lock ? $q->lockForUpdate() : $q)->firstOrFail();
    }

    private function latest(string $configId): ?object
    {
        return DB::table(self::REVISIONS)->where('configuration_id', $configId)->orderByDesc('revision')->first();
    }

    private function normalize(array $raw): array
    {
        if (strlen(json_encode($raw, JSON_THROW_ON_ERROR)) > 2000000) $this->fail('plan', 'Le plan dépasse 2 Mo.');
        try { return SeatingPlanContract::normalize($raw); }
        catch (InvalidArgumentException $e) { $this->fail('plan', $e->getMessage()); }
    }

    private function revision(string $configId, string $venueId, int $userId, int $number, array $plan): object
    {
        $id = (string) Str::uuid();
        DB::table(self::REVISIONS)->insert([
            'id' => $id, 'venue_id' => $venueId, 'configuration_id' => $configId,
            'revision' => $number, 'plan' => json_encode($plan, JSON_THROW_ON_ERROR),
            'created_by_user_id' => $userId, 'created_at' => now(), 'updated_at' => now(),
        ]);
        return DB::table(self::REVISIONS)->where('id', $id)->first();
    }

    public function forProvider(object $provider): array
    {
        $venues = DB::table('booketik_provider_venues')->where('provider_id', $provider->id)->whereNull('archived_at')->pluck('venue_id')->all();
        if (!$venues) return [];
        $all = DB::table(self::CONFIGS)->whereIn('venue_id', $venues)->orderBy('name')->limit(500)->get();
        $out = [];
        foreach ($all as $config) {
            $latest = $this->latest($config->id);
            $current = $this->publication->current($config->venue_id);
            $link = $current && $current->action === 'published'
                ? DB::table(self::LINKS)->where('publication_event_id', $current->id)->where('configuration_id', $config->id)->first()
                : null;
            $publishedConfigRevision = $link
                ? DB::table(self::REVISIONS)->where('id', $link->configuration_revision_id)->value('revision')
                : null;
            $out[$config->venue_id][] = [
                'id' => $config->id, 'name' => $config->name, 'status' => $config->status,
                'revision' => (int) ($latest?->revision ?? 0),
                'seat_count' => $latest ? count((json_decode($latest->plan, true, 512, JSON_THROW_ON_ERROR)['seats'] ?? [])) : 0,
                'published' => (bool) $link,
                'published_configuration_revision' => $publishedConfigRevision !== null ? (int) $publishedConfigRevision : null,
            ];
        }
        return $out;
    }

    public function selected(object $provider, string $venueId, string $configId): array
    {
        $config = $this->owned($provider, $venueId, $configId);
        abort_unless($config->status === 'active', 404);
        $latest = $this->latest($configId);
        abort_unless($latest, 404);
        return [
            'configuration' => ['id' => $config->id, 'name' => $config->name, 'revision' => (int) $latest->revision],
            'layout' => $latest,
        ];
    }

    public function create(object $provider, string $venueId, int $userId, string $name, ?int $sourceVersion): void
    {
        DB::transaction(function () use ($provider, $venueId, $userId, $name, $sourceVersion): void {
            $this->venue($provider, $venueId, true);
            $name = trim($name);
            if ($name === '') $this->fail('name', 'Le nom ne peut pas être vide.');
            $exists = DB::table(self::CONFIGS)->where('venue_id', $venueId)->where('name', $name)->exists();
            if ($exists) $this->fail('name', 'Ce nom de configuration existe déjà.');
            $source = $sourceVersion === null ? $this->store->latestLayout($venueId)
                : DB::table('booketik_venue_layout_revisions')->where('venue_id', $venueId)->where('revision', $sourceVersion)->first();
            if (!$source) $this->fail('source_revision', 'Enregistrez d’abord un plan de salle.');
            $id = (string) Str::uuid();
            DB::table(self::CONFIGS)->insert([
                'id' => $id, 'venue_id' => $venueId, 'name' => $name,
                'status' => 'active', 'created_by_user_id' => $userId,
                'created_at' => now(), 'updated_at' => now(),
            ]);
            $this->revision($id, $venueId, $userId, 1, $this->normalize(json_decode($source->plan, true, 512, JSON_THROW_ON_ERROR)));
        }, 3);
    }

    public function save(object $provider, string $venueId, string $configId, int $userId, array $raw, int $expected): void
    {
        $plan = $this->normalize($raw);
        DB::transaction(function () use ($provider, $venueId, $configId, $userId, $plan, $expected): void {
            $config = $this->owned($provider, $venueId, $configId, true);
            abort_unless($config->status === 'active', 404);
            $current = (int) ($this->latest($configId)?->revision ?? 0);
            if ($current !== $expected) $this->fail('expected_revision', 'Cette configuration a changé. Actualisez la page.');
            $this->revision($configId, $venueId, $userId, $current + 1, $plan);
        }, 3);
    }

    public function rename(object $provider, string $venueId, string $configId, string $name): void
    {
        DB::transaction(function () use ($provider, $venueId, $configId, $name): void {
            $config = $this->owned($provider, $venueId, $configId, true);
            abort_unless($config->status === 'active', 404);
            $name = trim($name);
            if ($name === '') $this->fail('name', 'Le nom ne peut pas être vide.');
            if (DB::table(self::CONFIGS)->where('venue_id', $venueId)->where('name', $name)->where('id', '!=', $configId)->exists()) {
                $this->fail('name', 'Ce nom existe déjà pour cette salle.');
            }
            DB::table(self::CONFIGS)->where('id', $configId)->update(['name' => $name, 'updated_at' => now()]);
        }, 3);
    }

    public function archive(object $provider, string $venueId, string $configId, int $actor, bool $restore): void
    {
        DB::transaction(function () use ($provider, $venueId, $configId, $actor, $restore): void {
            $config = $this->owned($provider, $venueId, $configId, true);
            if (!$restore) {
                $current = $this->publication->current($venueId);
                if ($current && $current->action === 'published' &&
                    DB::table(self::LINKS)->where('publication_event_id', $current->id)->where('configuration_id', $configId)->exists()) {
                    $this->fail('configuration', 'Retirez ou remplacez la publication avant d’archiver cette configuration.');
                }
            }
            DB::table(self::CONFIGS)->where('id', $configId)->update([
                'status' => $restore ? 'active' : 'archived',
                'archived_at' => $restore ? null : now(),
                'archived_by_user_id' => $restore ? null : $actor,
                'updated_at' => now(),
            ]);
        }, 3);
    }

    public function publish(object $provider, string $venueId, string $configId, int $actor, int $expectedConfigRevision, ?int $expectedEventId): void
    {
        DB::transaction(function () use ($provider, $venueId, $configId, $actor, $expectedConfigRevision, $expectedEventId): void {
            $config = $this->owned($provider, $venueId, $configId, true);
            abort_unless($config->status === 'active', 404);
            $current = $this->publication->current($venueId);
            if (($current ? (int) $current->id : null) !== $expectedEventId) {
                $this->fail('publication', 'Le plan publié a changé. Actualisez la page.');
            }
            $draft = $this->latest($configId);
            if (!$draft || (int) $draft->revision !== $expectedConfigRevision) {
                $this->fail('revision', 'La configuration a changé. Actualisez la page.');
            }
            $plan = json_decode($draft->plan, true, 512, JSON_THROW_ON_ERROR);
            if (!is_array($plan['seats'] ?? null) || !count($plan['seats']) || !is_array($plan['zones'] ?? null) || !count($plan['zones'])) {
                $this->fail('plan', 'Une configuration publiée doit contenir des sièges et des zones.');
            }
            // An organizer can only ever receive a canonical immutable layout revision.
            $legacyExpected = (int) ($this->store->latestLayout($venueId)?->revision ?? 0);
            $snapshot = $this->store->saveLayout($provider, $venueId, $actor, $plan, $legacyExpected);
            $eventId = DB::table('booketik_venue_publication_events')->insertGetId([
                'venue_id' => $venueId, 'layout_revision_id' => $snapshot->id,
                'action' => 'published', 'actor_user_id' => $actor, 'created_at' => now(),
            ]);
            DB::table(self::LINKS)->insert([
                'venue_id' => $venueId, 'configuration_id' => $configId,
                'configuration_revision_id' => $draft->id,
                'layout_revision_id' => $snapshot->id,
                'publication_event_id' => $eventId, 'created_at' => now(),
            ]);
        }, 3);
    }
}
