#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
service=(root/'backend/app/Services/Studios/VenueNamedConfigurations.php').read_text()
controller=(root/'backend/app/Http/Controllers/Studios/StudioController.php').read_text()
layout=(root/'frontend/resources/js/Themes/civic/components/dashboard/VenueManager/Layouts.jsx').read_text()
routes=(root/'backend/routes/booketik_studios.php').read_text()
migration=(root/'backend/database/migrations/2026_11_11_160001_create_booketik_venue_named_configurations.php').read_text()
checks = {
 'provider_owner_guard': 'ownsVenue($provider, $venueId' in service,
 'seat_contract_normalization': 'SeatingPlanContract::normalize' in service,
 'independent_append_only_revisions': 'booketik_venue_configuration_revisions' in migration and "$this->revision($configId, $venueId, $userId, $current + 1, $plan)" in service,
 'optimistic_revision_lock': '$current !== $expected' in service,
 'published_optimistic_lock': '(int) $current->id : null) !== $expectedEventId' in service,
 'canonical_snapshot': '$this->store->saveLayout(' in service and "'layout_revision_id' => $snapshot->id" in service,
 'canonical_publication_event': "'action' => 'published'" in service,
 'no_update_legacy_publications': "DB::table('booketik_venue_publication_events')->update" not in service,
 'no_schema_destructive_change': 'Schema::table(' not in migration,
 'archived_publish_guard': "abort_unless($config->status === 'active', 404)" in service,
 'published_archive_guard': 'Retirez ou remplacez la publication' in service,
 'named_catalog_ui': 'NamedConfigurations' in layout,
 'history_publication_fix': 'setServerPublished(data.published_revision)' in layout,
 'edit_route': 'configuration.layout.save' in routes,
 'publication_route': 'configuration.publish' in routes,
 'legacy_save_still_present': "'saveLayout'" in controller,
 'no_checkout_changes': 'checkout' not in routes.lower(),
}
for key,good in checks.items(): print(f'{key}={"PASS" if good else "FAIL"}')
if not all(checks.values()): raise SystemExit(3)
print('S6A3_STATIC_CONTRACT=PASS')
