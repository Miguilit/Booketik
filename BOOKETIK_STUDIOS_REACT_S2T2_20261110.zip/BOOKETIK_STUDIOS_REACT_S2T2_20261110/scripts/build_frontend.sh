#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
REPO="${1:-${GITHUB_WORKSPACE:-$PWD}}"
REPO="$(cd "$REPO" && pwd -P)"
cd "$KIT"
sha256sum -c package_manifest.sha256
if [[ -f "$REPO/resources/js/app.jsx" && -f "$REPO/package-lock.json" ]]; then
  SRC="$REPO"
elif [[ -f "$REPO/source/resources/js/app.jsx" && -f "$REPO/source/package-lock.json" ]]; then
  SRC="$REPO/source"
elif [[ -f "$REPO/BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz" ]]; then
  SRC="$REPO/_studios_build_source"
  mkdir -p "$SRC"
  tar -xzf "$REPO/BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz" -C "$SRC" --strip-components=1
  [[ -f "$SRC/resources/js/app.jsx" && -f "$SRC/package-lock.json" ]] || { echo 'SOURCE_LAYOUT_INVALID'; exit 1; }
else
  echo 'CURRENT_REACT_SOURCE_MISSING'
  exit 1
fi
[[ -f "$SRC/resources/js/pages.jsx" && -f "$SRC/vite.config.js" ]] || { echo 'BOOKETIK_VITE_MISSING'; exit 1; }
while IFS= read -r -d '' source; do
  rel="${source#"$KIT/overlay/"}"
  target="$SRC/$rel"
  if [[ -e "$target" ]]; then echo "TARGET_EXISTS:$rel"; exit 1; fi
done < <(find "$KIT/overlay" -type f -print0)
while IFS= read -r -d '' source; do
  rel="${source#"$KIT/overlay/"}"
  mkdir -p "$(dirname "$SRC/$rel")"
  cp "$source" "$SRC/$rel"
done < <(find "$KIT/overlay" -type f -print0)
cd "$SRC"
npm ci --no-audit --no-fund
npm run build
MANIFEST="$SRC/public/build/manifest.json"
[[ -s "$MANIFEST" ]] || { echo 'VITE_MANIFEST_MISSING'; exit 1; }
grep -q 'BooketikStudios' "$MANIFEST" || { echo 'STUDIOS_CHUNK_MISSING'; exit 1; }
OUT="$REPO/BOOKETIK_STUDIOS_S2T2_COMPILED_20261110.tar.gz"
PARTS=(public/build)
[[ -d bootstrap/ssr ]] && PARTS+=(bootstrap/ssr)
tar -czf "$OUT" "${PARTS[@]}"
(cd "$REPO" && sha256sum "$(basename "$OUT")" > "$(basename "$OUT").sha256")
echo "PASS_REACT_BUILD=$(basename "$OUT")"
echo 'NO_SERVER_CHANGES=YES'
