# BOOKETIK S2/T2 — React build

React 19 + Inertia + Laravel 13. Aucun nouveau package npm.

## Inclus

- `Dashboard/BooketikStudios.jsx` : page Inertia compilée par le résolveur existant.
- `VenueProvider.jsx` : fournisseur de salle, géométrie, rangées, zones, autorisations organisateurs.
- `OrganizerSeating.jsx` : zone → type de billet, sélection simulée, sans vente.
- `TicketStudio.jsx` : personnalisation visuelle, QR factice, contrôle contraste.
- `VenueGovernance.jsx` : uniquement vérification et litiges.

## Règle métier

Le fournisseur de salle est un rôle métier natif, **sans dépendance aux abonnements ni feature gating par plan**. Un fournisseur peut gérer plusieurs salles. Une salle peut être autorisée à plusieurs organisateurs. Les tarifs restent par événement via `TicketType`. Seul Laravel décide des autorisations effectives.

## Compiler

Dans le dépôt de compilation GitHub, utiliser une copie du frontend **actuel** (notamment les modifications FR/NL déployées) : racine Laravel, `source/` ou archive `BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz`. Ajouter le package complet et lancer le workflow `booketik-studios-react.yml` fourni sous `.github/workflows/`.

Le script refuse d'écraser des sources déjà présentes et ne modifie pas `package.json`, `package-lock.json`, `vite.config.js` ou les fichiers existants.

## Limites

La compilation crée des chunks, **pas des routes**. Les pages ne sont pas accessibles tant que Laravel n'a pas de routes protégées et n'injecte pas les props correspondant au rôle vérifié en base. Aucun CRUD réel, aucun siège vendu, aucune donnée enregistrée. Ne pas déployer des anciens assets à la place d'une version frontend récente.

## Backend nécessaire ensuite

- `venue_providers` (identité et gouvernance du fournisseur), `venues`/liens fournisseurs existants, `venue_layouts` et révisions, `venue_access_grants`.
- Rôles `venue_provider` distincts d'`organizer`, policies par propriétaire et délégation.
- Contrats API venue/organisateur sur les mêmes plans, sans référence à `SubscriptionPlan` ou `activePlan` pour ces fonctionnalités.
- Inventaire transactionnel de sièges et réservation/vente atomique avant activation client.
- Ticket Studio versionné par organisateur/événement, QR natif inchangé.
- Superadmin seulement vérification fournisseurs, doublons, contestations et audit.
