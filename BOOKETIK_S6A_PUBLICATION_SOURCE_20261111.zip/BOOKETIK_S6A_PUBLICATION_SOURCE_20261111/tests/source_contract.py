from pathlib import Path
root = Path(__file__).resolve().parents[1]
c = (root/'backend/app/Http/Controllers/Studios/StudioController.php').read_text()
s = (root/'backend/app/Services/Studios/StudioStore.php').read_text()
p = (root/'backend/app/Services/Studios/VenuePublication.php').read_text()
r = (root/'backend/routes/booketik_studios.php').read_text()
m = (root/'backend/database/migrations/2026_11_11_120001_create_booketik_venue_publication_events.php').read_text()
f = (root/'frontend/resources/js/Themes/civic/components/dashboard/VenueManager/Publication.jsx').read_text()
checks = {
    'publish_route': "name('provider.layout.publish')" in r,
    'withdraw_route': "name('provider.layout.withdraw')" in r,
    'catalog_route': "name('venues.list')" in r and 'organizer.page:editor' in r,
    'published_not_draft': '$this->publication->publishedLayout($venue->id)' in c,
    'pinned_immutable': "where('id', $draft->layout_revision_id)" in c,
    'map_validation': 'VenuePublication::allowedForEvent' in s,
    'owner_gate': "where('provider_id', $provider->id)" in p,
    'grant_gate': "where('g.organizer_id', $organizerId)" in p,
    'no_payment_change': 'payment' not in r.lower(),
    'append_only_events': 'bigIncrements' in m and "'action'" in m,
    'preview_confirmation': 'window.confirm' in f,
}
for key, value in checks.items():
    if not value: raise SystemExit('S6A_CONTRACT_FAIL_'+key)
print('S6A_CONTRACT_CHECKS=PASS',len(checks))
