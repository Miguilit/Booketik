<?php

declare(strict_types=1);

require_once __DIR__.'/../backend/app/Services/Studios/VenuePublication.php';

use App\Services\Studios\VenuePublication;

$cases = [
    [null, 'rev-a', null, false],
    ['rev-a', 'rev-a', null, true],
    ['rev-b', 'rev-a', null, false],
    ['rev-b', 'rev-a', 'rev-b', true],
    ['rev-c', null, 'rev-b', false],
    ['rev-b', null, 'rev-b', true],
    ['rev-c', null, null, false],
];
foreach ($cases as [$wanted, $published, $pinned, $expected]) {
    if (VenuePublication::allowedForEvent($wanted, $published, $pinned) !== $expected) {
        throw new RuntimeException('S6A_ALLOWLIST_RULE_FAIL');
    }
}
echo 'S6A_EVENT_REVISION_PIN_RULES=PASS'.PHP_EOL;
