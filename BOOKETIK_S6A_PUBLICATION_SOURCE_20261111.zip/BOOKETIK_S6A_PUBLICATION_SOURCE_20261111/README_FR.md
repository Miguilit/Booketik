# BOOKETIK — S6A Publication des plans et catalogue organisateur

**Statut : kit SOURCE, pas un déploiement.** Architecture : Laravel 13 monolithe + Inertia/React Civic. Aucune modification des ventes, réservations, stocks, TicketType ou paiements.

## Ce qui est développé

- Publier explicitement la dernière révision valide d'un plan de salle ; une sauvegarde Studio seule reste un brouillon.
- Retirer une publication du catalogue des nouveaux utilisateurs, sans supprimer l'historique ni les anciennes révisions.
- Historique immuable `booketik_venue_publication_events` (publish/withdraw), avec acteur, horodatage et lien vers la révision exacte.
- Verrouillage optimiste : changement de brouillon ou de publication entre affichage et soumission = refus.
- Lecture par organisateurs autorisés uniquement : `GET /{locale}/organizer/dashboard/{org}/studios/venues` et `.../venues/{venue}/published`. Middleware existant `organizer.page:editor`; vérification des grants, de l'activité fournisseur et de l'archivage.
- Dans le Studio organisateur, si un mapping d'événement est déjà lié à une révision, il reste épinglé à celle-ci. Sinon, seul le plan publié est proposé. `saveMapping` refuse toute nouvelle révision non publiée, sauf celle déjà épinglée.
- Frontend : nouvel onglet « Publication », état brouillon/publié, publication/retrait confirmés, historique, choix de salle.

## Limitations explicites

- S6A **ne** raccorde **pas encore** la sélection de salle au formulaire EventNew d'Eventgoo ; il fournit les API sécurisées nécessaires. Cela appartient à S6B.
- Calendrier d'occupation, invitations et rôles d'équipe appartiennent à S6C. Pas de simulation de fonctionnalités terminées.
- Les zones physiques peuvent être nommées VIP/Standard/etc. Le prix réel reste le `TicketType` propre à chaque événement et n'est jamais modifié par le fournisseur.
- Le retrait empêche de *nouvelles* associations ; les événements dont les brouillons sont déjà épinglés continuent à utiliser leur version, sous réserve des droits organisateurs existants.
- Aucune migration n'est exécutée par le kit source. Une sauvegarde SQL récente, un gate de migration ciblée et un package de déploiement coordonné Laravel+React sont obligatoires avant activation.

## GitHub — compilation

Placer ces 5 archives à la racine du dépôt GitHub :

1. `BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz`
2. `BOOKETIK_S4C_CRUD_20261111.zip`
3. `BOOKETIK_S5C_GEOMETRY_SOURCE_20261111.zip`
4. `BOOKETIK_S5D_AUTO_SEATING_SOURCE_20261111.zip`
5. `BOOKETIK_S6A_PUBLICATION_SOURCE_20261111.zip`

Créer `.github/workflows/booketik-venue-publication-s6a.yml` en copiant `github/booketik-venue-publication-s6a.yml` puis exécuter **BOOKETIK S6A Venue Publication React**.

L'artefact GitHub sera `booketik-venue-publication-s6a-compiled.zip`, avec :

- `BOOKETIK_S6A_PUBLICATION_COMPILED_20261111.tar.gz`
- `BOOKETIK_S6A_PUBLICATION_COMPILED_20261111.tar.gz.sha256`

La compilation remet en place les couches frontend S4C + S5C + S5D avant de superposer S6A. Le Seat/Geometry Studio S5D est conservé.

## Hostinger — préflight lecture seule

Placer le ZIP source dans `booketik.com/_private/`, puis depuis `booketik.com` :

```bash
unzip -q _private/BOOKETIK_S6A_PUBLICATION_SOURCE_20261111.zip -d _private/
bash _private/BOOKETIK_S6A_PUBLICATION_SOURCE_20261111/scripts/check_hostinger.sh
```

Attendu : `S6A_READONLY_PREFLIGHT=PASS`, `APPLICATION_WRITES=0`, `DATABASE_WRITES=0`.

**Ne pas lancer** `php artisan migrate`, `--activate`, ni remplacer `public/build` ou `bootstrap/ssr` avec ce kit. Pour la mise en production, le protocole suivant est obligatoire : backup SQL avec SHA et restauration possible, gate de la migration spécifique, build GitHub vérifié, préflight des SHA live, merge additif des assets, sauvegarde PHP/assets et rollback.

## Manifeste

L'empreinte de chaque fichier composant le kit est référencée dans `scripts/package_files.sha256`. Les fichiers protégés de production S5D restent inchangés jusqu'à l'étape d'activation explicite.
