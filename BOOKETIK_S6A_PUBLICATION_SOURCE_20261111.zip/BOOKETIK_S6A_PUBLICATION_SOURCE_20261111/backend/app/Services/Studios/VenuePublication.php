<?php

declare(strict_types=1);

namespace App\Services\Studios;

use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/** Publication is append-only. Draft layouts and event-pinned revisions never mutate. */
final class VenuePublication
{
    private const TABLE = 'booketik_venue_publication_events';

    private function fail(string $message): never
    {
        throw ValidationException::withMessages(['publication' => $message]);
    }

    private function owned(object $provider, string $venueId, bool $lock = false): object
    {
        abort_unless($provider->status === 'active', 403);
        $query = DB::table('booketik_provider_venues')->where('provider_id', $provider->id)->where('venue_id', $venueId);
        $row = ($lock ? $query->lockForUpdate() : $query)->first();
        abort_unless($row && $row->archived_at === null, 404);
        return $row;
    }

    public function current(string $venueId): ?object
    {
        return DB::table(self::TABLE)->where('venue_id', $venueId)->orderByDesc('id')->first();
    }

    public static function allowedForEvent(?string $requestedRevision, ?string $publishedRevision, ?string $existingPinnedRevision): bool
    {
        return $requestedRevision !== null &&
            ($requestedRevision === $publishedRevision ||
            ($existingPinnedRevision !== null && $requestedRevision === $existingPinnedRevision));
    }

    private function summary(string $venueId, bool $history): array
    {
        $latest = DB::table('booketik_venue_layout_revisions')->where('venue_id', $venueId)
            ->orderByDesc('revision')->first(['id', 'revision', 'plan']);
        $current = $this->current($venueId);
        $published = $current && $current->action === 'published'
            ? DB::table('booketik_venue_layout_revisions')->where('id', $current->layout_revision_id)
                ->where('venue_id', $venueId)->first(['id', 'revision', 'plan'])
            : null;
        $items = [];
        if ($history) {
            $items = DB::table(self::TABLE.' as e')
                ->leftJoin('booketik_venue_layout_revisions as l', 'l.id', '=', 'e.layout_revision_id')
                ->where('e.venue_id', $venueId)->orderByDesc('e.id')->limit(25)
                ->get(['e.id', 'e.action', 'e.created_at', 'e.actor_user_id', 'l.revision'])
                ->map(fn ($e) => [
                    'id' => (int) $e->id, 'action' => $e->action, 'revision' => $e->revision === null ? null : (int) $e->revision,
                    'created_at' => (string) $e->created_at,
                ])->all();
        }
        $publishedPlan = $published ? json_decode($published->plan, true, 512, JSON_THROW_ON_ERROR) : null;
        $latestPlan = $latest ? json_decode($latest->plan, true, 512, JSON_THROW_ON_ERROR) : null;
        return [
            'status' => $published ? 'published' : 'unpublished',
            'event_id' => $current ? (int) $current->id : null,
            'latest_revision' => (int) ($latest?->revision ?? 0),
            'latest_revision_id' => $latest?->id,
            'latest_seat_count' => is_array($latestPlan['seats'] ?? null) ? count($latestPlan['seats']) : 0,
            'published_revision' => $published ? (int) $published->revision : null,
            'published_revision_id' => $published?->id,
            'published_seat_count' => is_array($publishedPlan['seats'] ?? null) ? count($publishedPlan['seats']) : 0,
            'has_newer_draft' => $published && $latest && $latest->id !== $published->id,
            'history' => $items,
        ];
    }

    public function forProvider(object $provider): array
    {
        $venues = DB::table('booketik_provider_venues')->where('provider_id', $provider->id)
            ->whereNull('archived_at')->pluck('venue_id')->all();
        $output = [];
        foreach ($venues as $id) {
            $output[$id] = $this->summary($id, false);
        }
        return $output;
    }

    public function forProviderVenue(object $provider, string $venueId): array
    {
        $this->owned($provider, $venueId);
        return $this->summary($venueId, true);
    }

    public function publish(object $provider, string $venueId, int $actor, int $expectedRevision, ?int $expectedEventId): void
    {
        DB::transaction(function () use ($provider, $venueId, $actor, $expectedRevision, $expectedEventId): void {
            $this->owned($provider, $venueId, true);
            $latest = DB::table('booketik_venue_layout_revisions')->where('venue_id', $venueId)
                ->orderByDesc('revision')->first();
            if (!$latest || (int) $latest->revision !== $expectedRevision) {
                $this->fail('Le brouillon a changé. Rechargez la page avant de publier.');
            }
            $current = $this->current($venueId);
            if (($current ? (int) $current->id : null) !== $expectedEventId) {
                $this->fail('La publication a changé. Rechargez la page.');
            }
            $plan = json_decode($latest->plan, true, 512, JSON_THROW_ON_ERROR);
            if (!is_array($plan['seats'] ?? null) || count($plan['seats']) === 0 ||
                !is_array($plan['zones'] ?? null) || count($plan['zones']) === 0) {
                $this->fail('Un plan publiable doit contenir des sièges et au moins une zone.');
            }
            if ($current && $current->action === 'published' && $current->layout_revision_id === $latest->id) {
                $this->fail('Cette version est déjà publiée.');
            }
            DB::table(self::TABLE)->insert([
                'venue_id' => $venueId, 'layout_revision_id' => $latest->id,
                'action' => 'published', 'actor_user_id' => $actor, 'created_at' => now(),
            ]);
        }, 3);
    }

    public function withdraw(object $provider, string $venueId, int $actor, ?int $expectedEventId): void
    {
        DB::transaction(function () use ($provider, $venueId, $actor, $expectedEventId): void {
            $this->owned($provider, $venueId, true);
            $current = $this->current($venueId);
            if (!$current || $current->action !== 'published') {
                $this->fail('Aucun plan publié à retirer.');
            }
            if ((int) $current->id !== $expectedEventId) {
                $this->fail('La publication a changé. Rechargez la page.');
            }
            DB::table(self::TABLE)->insert([
                'venue_id' => $venueId, 'layout_revision_id' => null,
                'action' => 'withdrawn', 'actor_user_id' => $actor, 'created_at' => now(),
            ]);
        }, 3);
    }

    public function publishedLayout(string $venueId): ?object
    {
        $current = $this->current($venueId);
        if (!$current || $current->action !== 'published') {
            return null;
        }
        return DB::table('booketik_venue_layout_revisions')->where('id', $current->layout_revision_id)
            ->where('venue_id', $venueId)->first();
    }

    public function organizerCatalog(string $organizerId): array
    {
        $venues = DB::table('booketik_venue_grants as g')
            ->join('booketik_provider_venues as pv', 'pv.venue_id', '=', 'g.venue_id')
            ->join('booketik_venue_providers as p', 'p.id', '=', 'pv.provider_id')
            ->join('venues as v', 'v.id', '=', 'g.venue_id')
            ->where('g.organizer_id', $organizerId)->where('g.status', 'granted')
            ->whereNull('pv.archived_at')->where('p.status', 'active')
            ->orderBy('v.name')->limit(100)->get(['v.id', 'v.name', 'v.city', 'v.address_line1']);
        $catalog = [];
        foreach ($venues as $venue) {
            $revision = $this->publishedLayout($venue->id);
            if (!$revision) {
                continue;
            }
            $plan = json_decode($revision->plan, true, 512, JSON_THROW_ON_ERROR);
            $catalog[] = [
                'id' => $venue->id, 'name' => $venue->name, 'city' => $venue->city,
                'address' => $venue->address_line1, 'layout_revision_id' => $revision->id,
                'layout_revision' => (int) $revision->revision,
                'seat_count' => is_array($plan['seats'] ?? null) ? count($plan['seats']) : 0,
                'zones' => array_map(static fn (array $z) => [
                    'id' => $z['id'], 'name' => $z['name'] ?? $z['label'] ?? 'Zone',
                ], is_array($plan['zones'] ?? null) ? $plan['zones'] : []),
            ];
        }
        return $catalog;
    }
}
