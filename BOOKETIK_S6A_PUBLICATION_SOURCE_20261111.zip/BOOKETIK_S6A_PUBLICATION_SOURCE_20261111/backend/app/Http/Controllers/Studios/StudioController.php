<?php

declare(strict_types=1);

namespace App\Http\Controllers\Studios;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Dashboard\Concerns\RendersDashboard;
use App\Models\Event;
use App\Models\Venue;
use App\Services\Studios\StudioStore;
use App\Services\Studios\VenueManagerReadModel;
use App\Services\Studios\VenueLifecycle;
use App\Services\Studios\VenuePublication;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Inertia\Inertia;
use Inertia\Response;

final class StudioController extends Controller
{
    use RendersDashboard;

    public function __construct(private readonly StudioStore $store, private readonly VenueManagerReadModel $venueReadModel, private readonly VenueLifecycle $lifecycle, private readonly VenuePublication $publication) {}

    private function ready(): void
    {
        abort_unless(Schema::hasTable('booketik_venue_providers') && Schema::hasTable('booketik_ticket_design_revisions') && Schema::hasTable('booketik_venue_publication_events'), 503);
    }

    private function provider(Request $request): object
    {
        $this->ready();
        $provider = $this->store->provider((int) $request->user()->id);
        abort_unless($provider, 403);
        return $provider;
    }

    private function eventFor(Request $request, string $event): Event
    {
        $this->ready();
        $org = $request->attributes->get('organizer');
        abort_unless($org, 403);
        return Event::query()->where('organizer_id', $org->id)->where('id', $event)->firstOrFail();
    }

    public function providerPage(Request $request): Response
    {
        $this->ready();
        $provider = $this->store->provider((int) $request->user()->id);
        $venues = $provider ? $this->store->venues($provider) : [];
        $chosen = $request->query('venue') ?: ($venues[0]['id'] ?? null);
        if ($chosen && !in_array($chosen, array_column($venues, 'id'), true)) {
            abort(404);
        }
        $venue = $chosen ? Venue::query()->findOrFail($chosen) : null;
        $layout = $chosen ? $this->store->latestLayout($chosen) : null;
        return Inertia::render('Dashboard/BooketikVenueManager', [
            'audience' => 'venue_provider',
            'overview' => $provider ? $this->venueReadModel->forProvider($provider) : [
                'metrics' => ['venue_count' => 0, 'configured_venue_count' => 0, 'seat_count' => 0, 'partner_count' => 0, 'archived_count' => 0],
                'rooms' => [],
            ],
            'provider' => $provider ? ['id' => $provider->id, 'name' => $provider->name, 'status' => $provider->status] : null,
            'venues' => $venues,
            'venue' => $venue ? ['id' => $venue->id, 'name' => $venue->name, 'address' => $venue->address_line1, 'visibility' => 'private', 'access' => $this->store->grants($venue->id)] : null,
            'plan' => $layout ? json_decode($layout->plan, true, 512, JSON_THROW_ON_ERROR) : null,
            'layoutRevision' => (int) ($layout?->revision ?? 0),
            'publications' => $provider ? $this->publication->forProvider($provider) : [],
            'urls' => ['register' => route('booketik.studios.provider.register'), 'createVenue' => route('booketik.studios.provider.venues.create'),
                'saveLayout' => $venue ? route('booketik.studios.provider.layout.save', ['venue' => $venue->id]) : null,
                'saveVenue' => $venue ? route('booketik.studios.provider.venue.update', ['venue' => $venue->id]) : null,
                'grant' => $venue ? route('booketik.studios.provider.grant', ['venue' => $venue->id]) : null,
                'venueUpdatePattern' => route('booketik.studios.provider.venue.update', ['venue' => '00000000-0000-0000-0000-000000000000']),
                'venueArchivePattern' => route('booketik.studios.provider.venue.archive', ['venue' => '00000000-0000-0000-0000-000000000000']),
                'venueRestorePattern' => route('booketik.studios.provider.venue.restore', ['venue' => '00000000-0000-0000-0000-000000000000']),
                'organizerSearch' => route('booketik.studios.provider.organizers.search'),
                'updateProvider' => route('booketik.studios.provider.profile.update'),
                'publishPattern' => route('booketik.studios.provider.layout.publish', ['venue' => '00000000-0000-0000-0000-000000000000']),
                'withdrawPattern' => route('booketik.studios.provider.layout.withdraw', ['venue' => '00000000-0000-0000-0000-000000000000']),
                'publicationDetailPattern' => route('booketik.studios.provider.layout.publication', ['venue' => '00000000-0000-0000-0000-000000000000'])],
        ]);
    }

    public function register(Request $request): RedirectResponse
    {
        $this->ready();
        $data = $request->validate(['name' => ['required', 'string', 'max:160']]);
        $this->store->register((int) $request->user()->id, $data['name']);
        return back()->with('success', 'Fournisseur enregistré.');
    }

    public function createVenue(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:160'],
            'address_line1' => ['nullable', 'string', 'max:255'],
            'city' => ['nullable', 'string', 'max:160'],
            'timezone' => ['required', 'timezone'],
        ]);
        $venue = $this->store->createVenue($this->provider($request), $data);
        return redirect()->route('booketik.studios.provider.page', ['venue' => $venue->id])->with('success', 'Salle créée.');
    }

    public function updateVenue(Request $request, string $locale, string $venue): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:160'],
            'address_line1' => ['nullable', 'string', 'max:255'],
            'city' => ['nullable', 'string', 'max:160'],
            'timezone' => ['sometimes', 'timezone'],
        ]);
        $this->lifecycle->update($this->provider($request), $venue, $data);
        return back()->with('success', 'Informations de salle enregistrées.');
    }

    public function saveLayout(Request $request, string $locale, string $venue): RedirectResponse
    {
        $data = $request->validate(['plan' => ['required', 'array'], 'expected_revision' => ['required', 'integer', 'min:0']]);
        $this->store->saveLayout($this->provider($request), $venue, (int) $request->user()->id, $data['plan'], (int) $data['expected_revision']);
        return back()->with('success', 'Brouillon de salle enregistré.');
    }

    public function grant(Request $request, string $locale, string $venue): RedirectResponse
    {
        $data = $request->validate(['organizer_id' => ['required', 'uuid'], 'enabled' => ['required', 'boolean']]);
        $this->store->grant($this->provider($request), $venue, $data['organizer_id'], (int) $request->user()->id, (bool) $data['enabled']);
        return back()->with('success', 'Autorisation mise à jour.');
    }

    public function archiveVenue(Request $request, string $locale, string $venue): RedirectResponse
    {
        $this->lifecycle->archive($this->provider($request), $venue, (int) $request->user()->id);
        return redirect()->route('booketik.studios.provider.page', ['locale' => $locale, 'tab' => 'rooms'])->with('success', 'Salle archivée. Les plans ont été conservés.');
    }

    public function restoreVenue(Request $request, string $locale, string $venue): RedirectResponse
    {
        $this->lifecycle->restore($this->provider($request), $venue);
        return redirect()->route('booketik.studios.provider.page', ['locale' => $locale, 'tab' => 'rooms'])->with('success', 'Salle réactivée.');
    }

    public function renameProvider(Request $request): RedirectResponse
    {
        $data = $request->validate(['name' => ['required', 'string', 'max:160']]);
        $this->lifecycle->renameProvider($this->provider($request), $data['name']);
        return back()->with('success', 'Identité du fournisseur mise à jour.');
    }

    public function searchOrganizers(Request $request): JsonResponse
    {
        $data = $request->validate(['q' => ['required', 'string', 'min:2', 'max:80']]);
        return response()->json(['items' => $this->lifecycle->searchOrganizers($this->provider($request), $data['q'])]);
    }

    public function publishLayout(Request $request, string $locale, string $venue): RedirectResponse
    {
        $data = $request->validate([
            'expected_revision' => ['required', 'integer', 'min:1'],
            'expected_event_id' => ['nullable', 'integer', 'min:1'],
        ]);
        $this->publication->publish($this->provider($request), $venue, (int) $request->user()->id,
            (int) $data['expected_revision'], isset($data['expected_event_id']) ? (int) $data['expected_event_id'] : null);
        return back()->with('success', 'Plan publié. Les événements existants conservent leurs versions associées.');
    }

    public function withdrawLayout(Request $request, string $locale, string $venue): RedirectResponse
    {
        $data = $request->validate(['expected_event_id' => ['required', 'integer', 'min:1']]);
        $this->publication->withdraw($this->provider($request), $venue, (int) $request->user()->id,
            (int) $data['expected_event_id']);
        return back()->with('success', 'Plan retiré du catalogue des nouvelles utilisations. Les plans associés aux événements sont conservés.');
    }

    public function providerPublicationDetail(Request $request, string $locale, string $venue): JsonResponse
    {
        $data = $this->publication->forProviderVenue($this->provider($request), $venue);
        return response()->json($data, 200, ['Cache-Control' => 'private, no-store']);
    }

    public function organizerAvailableVenues(Request $request, string $locale, string $org): JsonResponse
    {
        $this->ready();
        $organizer = $request->attributes->get('organizer');
        abort_unless($organizer, 403);
        return response()->json(['items' => $this->publication->organizerCatalog($organizer->id)], 200, ['Cache-Control' => 'private, no-store']);
    }

    public function organizerVenuePreview(Request $request, string $locale, string $org, string $venue): JsonResponse
    {
        $this->ready();
        $organizer = $request->attributes->get('organizer');
        abort_unless($organizer && $this->store->canUse($venue, $organizer->id), 403);
        $layout = $this->publication->publishedLayout($venue);
        abort_unless($layout, 404);
        return response()->json([
            'venue_id' => $venue, 'layout_revision_id' => $layout->id,
            'revision' => (int) $layout->revision,
            'plan' => json_decode($layout->plan, true, 512, JSON_THROW_ON_ERROR),
        ], 200, ['Cache-Control' => 'private, no-store']);
    }

    public function organizerPage(Request $request, string $locale, string $org, string $event): Response
    {
        $model = $this->eventFor($request, $event);
        $venue = $model->venue_id ? Venue::query()->find($model->venue_id) : null;
        $access = $venue && $this->store->canUse($venue->id, $model->organizer_id);
        $draft = $this->store->seatingDraft($model->id);
        $layout = null;
        if ($access) {
            if ($draft) {
                // Events keep their pinned revision even if a newer one is published.
                $layout = DB::table('booketik_venue_layout_revisions')
                    ->where('id', $draft->layout_revision_id)->where('venue_id', $venue->id)->first();
            } else {
                $managed = DB::table('booketik_provider_venues')->where('venue_id', $venue->id)->exists();
                $layout = $managed ? $this->publication->publishedLayout($venue->id) : $this->store->latestLayout($venue->id);
            }
        }
        $design = $this->store->latestDesign($model->id);
        return $this->page($request, 'BooketikStudios', [
            'audience' => 'organizer', 'eventId' => $model->id,
            'venue' => $venue ? ['id' => $venue->id, 'name' => $venue->name] : null,
            'plan' => $layout ? json_decode($layout->plan, true, 512, JSON_THROW_ON_ERROR) : null,
            'layoutRevisionId' => $layout?->id,
            'ticketTypes' => DB::table('ticket_types')->where('event_id', $model->id)->orderBy('sort_order')->get(['id', 'name', 'price_cents', 'currency'])->map(fn ($t) => [
                'id' => $t->id, 'name' => $t->name, 'amount' => (int) $t->price_cents, 'currency' => $t->currency,
            ])->all(),
            'initialMapping' => $draft ? json_decode($draft->zone_ticket_types, true, 512, JSON_THROW_ON_ERROR) : [],
            'ticketDesign' => $design ? json_decode($design->design, true, 512, JSON_THROW_ON_ERROR) : null,
            'designRevision' => (int) ($design?->revision ?? 0),
            'access' => ['canUseVenue' => (bool) ($access && $layout)],
            'urls' => [
                'saveMapping' => route('booketik.studios.organizer.mapping.save', ['org' => $org, 'event' => $model->id]),
                'availableVenues' => route('booketik.studios.organizer.venues.list', ['org' => $org]),
                'saveDesign' => route('booketik.studios.organizer.design.save', ['org' => $org, 'event' => $model->id]),
            ],
        ]);
    }

    public function saveMapping(Request $request, string $locale, string $org, string $event): RedirectResponse
    {
        $model = $this->eventFor($request, $event);
        $data = $request->validate([
            'layout_revision_id' => ['required', 'uuid'],
            'zone_ticket_types' => ['required', 'array', 'max:100'],
            'zone_ticket_types.*' => ['required', 'uuid'],
        ]);
        $this->store->saveMapping($model, (int) $request->user()->id, $data['layout_revision_id'], $data['zone_ticket_types']);
        return back()->with('success', 'Tarifs par zone enregistrés en brouillon.');
    }

    public function saveDesign(Request $request, string $locale, string $org, string $event): RedirectResponse
    {
        $model = $this->eventFor($request, $event);
        $data = $request->validate(['design' => ['required', 'array'], 'expected_revision' => ['required', 'integer', 'min:0']]);
        $this->store->saveDesign($model, (int) $request->user()->id, $data['design'], (int) $data['expected_revision']);
        return back()->with('success', 'Modèle de billet enregistré en brouillon.');
    }

    public function governance(Request $request): Response
    {
        $this->ready();
        abort_unless($request->user()?->isAdmin(), 403);
        $rows = DB::table('booketik_provider_venues as pv')
            ->join('venues as v', 'v.id', '=', 'pv.venue_id')
            ->join('booketik_venue_providers as p', 'p.id', '=', 'pv.provider_id')
            ->orderByDesc('pv.created_at')->limit(100)
            ->get(['pv.id', 'v.name as venue_name', 'p.name as provider_name', 'p.status'])
            ->map(fn ($r) => ['id' => $r->id, 'venue_name' => $r->venue_name, 'kind' => 'Fournisseur : '.$r->provider_name, 'status' => $r->status])->all();
        return Inertia::render('Dashboard/BooketikStudiosStandalone', ['audience' => 'superadmin', 'governance' => $rows]);
    }
}
