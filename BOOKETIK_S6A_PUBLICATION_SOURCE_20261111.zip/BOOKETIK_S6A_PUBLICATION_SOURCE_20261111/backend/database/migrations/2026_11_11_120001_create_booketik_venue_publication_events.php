<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('booketik_venue_publication_events', function (Blueprint $table): void {
            $table->bigIncrements('id');
            $table->foreignUuid('venue_id')->constrained('venues')->restrictOnDelete();
            $table->foreignUuid('layout_revision_id')->nullable()
                ->constrained('booketik_venue_layout_revisions')->restrictOnDelete();
            $table->string('action', 16); // published | withdrawn
            $table->foreignId('actor_user_id')->constrained('users')->restrictOnDelete();
            $table->timestamp('created_at')->useCurrent();
            $table->index(['venue_id', 'id'], 'bkt_pub_event_venue_id_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('booketik_venue_publication_events');
    }
};
