#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
DOMAIN="$(pwd -P)"
if [[ -f "$DOMAIN/eventgoo/artisan" ]]; then APP="$DOMAIN/eventgoo"
elif [[ -f "$DOMAIN/artisan" ]]; then APP="$DOMAIN"
else echo 'S6A_APP_ROOT=NOT_FOUND'; exit 2; fi
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'S6A_PACKAGE_SHA=FAIL'; exit 3; }
base_check () {
  local file="$1" expected="$2" actual
  [[ -f "$APP/$file" ]] || { echo "S6A_MISSING_SOURCE=$file"; exit 4; }
  actual="$(sha256sum "$APP/$file" | cut -d' ' -f1)"
  if [[ "$actual" != "$expected" ]]; then echo "S6A_SOURCE_DRIFT=$file"; exit 5; fi
}
base_check app/Http/Controllers/Studios/StudioController.php bb94fa2e970b7171b9f6ec33381c1cdf050a488d040fadd93100b1810245b1a3
base_check app/Services/Studios/StudioStore.php 5b1c0e0bef62e67108d50eb8177862d878c4d7593d34ed37c6c0bc3f62c80154
base_check routes/booketik_studios.php 769444aee4541b28d6e3b9759dfcf15dc78f35b0f6d4f1a4b65323cd6570b614
base_check app/Services/Seating/SeatingPlanContract.php 39fb3ab438cd1a3866cc2d668ef58ba0d6507f745bd1f45eba373b1df1e8931d
base_check public/build/manifest.json 79e4d728d3cc0c369986f0730459aa237522469fd0360ebaab454b91e91809c2
base_check bootstrap/ssr/ssr-manifest.json 3af87f8edc65d40d3f0533ae019d10ce591768a2200695bac4fc3523fe3f9499
# This is a read-only source preflight. A separate SQL backup + targeted migration gate
# must inspect booketik_venue_publication_events before any PHP/React activation.
echo 'S6A_S5D_BASELINE=PASS'
echo 'S6A_SOURCE_SHA=PASS'
echo 'S6A_READONLY_PREFLIGHT=PASS'
echo 'S6A_MIGRATION=NOT_APPLIED_BY_THIS_SCRIPT'
echo 'APPLICATION_WRITES=0'
echo 'DATABASE_WRITES=0'
