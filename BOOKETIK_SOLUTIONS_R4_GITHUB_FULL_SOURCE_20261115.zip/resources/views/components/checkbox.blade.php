<input type="checkbox" {!! $attributes->merge(['class' => 'rounded border-gray-300 text-teal-600 shadow-sm focus:ring-indigo-500']) !!}>
