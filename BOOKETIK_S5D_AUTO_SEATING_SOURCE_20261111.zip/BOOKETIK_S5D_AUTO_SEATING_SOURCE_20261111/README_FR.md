# BOOKETIK S5D — Auto-Seating Engine (code source)

## Statut

Source React + Laravel générée et tests de contrat/algorithmes locaux PASS. Le **build Vite/SSR via GitHub reste à effectuer**. Rien n’est déployé. Aucune migration SQL, route, tarif, paiement, QR, hold, inventaire ou checkout ne sont modifiés.

## Fonctionnalités

- Échelle **métrique déclarée** : l’opérateur renseigne la largeur physique du plan ; la hauteur est déduite du ratio du canevas. Aucune précision réglementaire ni mesure réelle n’est garantie sans mesure vérifiée sur site.
- Espacement **centre à centre** des sièges et entre rangées ; diamètre de siège, marge intérieure et recul des allées personnalisables.
- Disposition droite, courbe, radiale ou en quinconce ; placement à l’intérieur d’une section, d’une ellipse ou d’un polygone.
- Exclusion de la scène, des escaliers, des allées et des collisions avec les places existantes ; quantité plafonnée et aucune opération destructrice implicite.
- **Ajouter** des sièges sans écraser les anciens, ou **réaligner** les sièges existants à l’intérieur de la forme : les identifiants, libellés de rangées, numéros et indicateurs PMR sont conservés.
- Prévisualisation non persistante, validation explicite, Undo/Redo avant sauvegarde et révision serveur existante.
- La calibration est enregistrée dans `measurement: { version: 1, unit: "m", canvas_width_m: ... }` à la sauvegarde. L’ancienne version `booketik.seating.v1` reste compatible ; les plans non calibrés restent valides.
- Algorithme déterministe de positions à partir des paramètres (identifiants nouveaux générés lors de la prévisualisation) ; aucune génération ou changement des prix et places vendues.

**Important :** Ceci n'est pas un moteur de conformité réglementaire ou de sécurité du public. Les sorties doivent être vérifiées physiquement et validées avant billetterie.

## Compilation GitHub

Déposer à la racine du dépôt les quatre sources déjà utilisées au cours du chantier (ne pas écraser les versions) :

1. `BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz`
2. `BOOKETIK_S4C_CRUD_20261111.zip`
3. `BOOKETIK_S5C_GEOMETRY_SOURCE_20261111.zip`
4. `BOOKETIK_S5D_AUTO_SEATING_SOURCE_20261111.zip`

Créer `.github/workflows/booketik-auto-seating-s5d.yml` depuis `github/booketik-auto-seating-s5d.yml` et lancer dans GitHub Actions **BOOKETIK S5D Auto Seating React**.

L’artefact produit sera `booketik-auto-seating-s5d-compiled.zip` contenant `BOOKETIK_S5D_AUTO_SEATING_COMPILED_20261111.tar.gz` et son SHA256.

## Vérification Hostinger lecture seule

Déposer le ZIP source dans `booketik.com/_private/` et depuis `booketik.com` lancer :

```bash
unzip -q _private/BOOKETIK_S5D_AUTO_SEATING_SOURCE_20261111.zip -d _private/
bash _private/BOOKETIK_S5D_AUTO_SEATING_SOURCE_20261111/scripts/check_hostinger.sh
```

Attendu `S5D_PREFLIGHT=PASS`, `S5D_S5C_BASELINE=PASS`, `APPLICATION_WRITES=0`, `DATABASE_WRITES=0`.

Si les hashes de manifeste ou du contrat ne sont plus ceux du build S5C, le contrôle **refuse**. Ne corriger aucune empreinte manuellement. Ne pas copier l’archive React compilée dans le répertoire public sans package de déploiement sécurisé : fusion des assets, backup et rollback vers S5C requis.

## Vérifications locales

```bash
node tests/autoseating.mjs
php tests/contract.php
```

Les tests couvrent les rectangles/ovales/polygones, les exclusions scène/aisles, l’ajout non destructif, les quatre dispositions, le réalignement conservant les identifiants et PMR, ainsi que les limites de densité. Les tests côté serveur protègent la persistance de la calibration et les anciennes révisions.
