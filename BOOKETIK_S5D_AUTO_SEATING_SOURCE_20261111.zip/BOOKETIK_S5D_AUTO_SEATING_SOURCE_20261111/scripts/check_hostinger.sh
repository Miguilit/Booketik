#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
DOMAIN="$(cd "$KIT/../.." && pwd -P)"
APP="$DOMAIN/eventgoo"
[[ -f "$APP/artisan" && -f "$APP/app/Services/Seating/SeatingPlanContract.php" ]] || { echo 'S5D_APP_ROOT=FAIL'; exit 4; }
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'S5D_PACKAGE_SHA=FAIL'; exit 3; }
while read -r expected rel; do
  [[ -z "$expected" ]] && continue
  file="$APP/$rel"
  [[ -f "$file" ]] || { echo "S5D_MISSING_SOURCE=$rel"; exit 5; }
  actual="$(sha256sum "$file" | cut -d ' ' -f 1)"
  [[ "$actual" == "$expected" ]] || { echo "S5D_SOURCE_DRIFT=$rel"; exit 6; }
done < "$KIT/scripts/host_baseline.tsv"
PHP84=/opt/alt/php84/usr/bin/php
[[ -x "$PHP84" ]] || PHP84="$(command -v php)"
"$PHP84" -l "$KIT/backend/app/Services/Seating/SeatingPlanContract.php" | grep -q '^No syntax errors'
"$PHP84" "$KIT/tests/contract.php" | grep -q 'S5D_MEASUREMENT_GUARDS=PASS'
[[ ! -f "$APP/public/build/manifest.json" ]] && { echo 'S5D_NO_CLIENT_MANIFEST=FAIL'; exit 7; }
while read -r expected rel; do
  [[ -z "$expected" ]] && continue
  file="$APP/$rel"
  [[ -f "$file" && "$(sha256sum "$file" | cut -d ' ' -f 1)" == "$expected" ]] || { echo "S5D_VITE_BASELINE_DRIFT=$rel"; exit 8; }
done < "$KIT/scripts/host_vite_baseline.tsv"
echo 'S5D_S5C_BASELINE=PASS'
echo 'S5D_PHP_CONTRACT=PASS'
echo 'S5D_PREFLIGHT=PASS'
echo 'APPLICATION_WRITES=0'
echo 'DATABASE_WRITES=0'
