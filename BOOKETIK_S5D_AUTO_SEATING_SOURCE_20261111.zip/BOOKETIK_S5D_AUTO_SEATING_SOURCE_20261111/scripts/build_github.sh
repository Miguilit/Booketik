#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
REPO="$(cd "${1:-$PWD}" && pwd -P)"
(cd "$KIT" && sha256sum -c scripts/package_files.sha256 >/dev/null) || { echo 'S5D_PACKAGE_SHA=FAIL'; exit 3; }
S4C="$REPO/BOOKETIK_S4C_CRUD_20261111"
S5C="$REPO/BOOKETIK_S5C_GEOMETRY_SOURCE_20261111"
SOURCE="$REPO/BOOKETIK_FRONTEND_CURRENT_SOURCE.tar.gz"
[[ -s "$SOURCE" && -f "$S4C/scripts/build_github.sh" && -f "$S5C/scripts/build_github.sh" ]] || { echo 'S5D_DEPENDENCIES=MISSING'; exit 4; }
python3 - "$KIT" "$S4C" "$S5C" <<'PY_CHECK'
import pathlib,hashlib,sys
kit,s4c,s5c=[pathlib.Path(p) for p in sys.argv[1:]]
s5cbase=s5c/'frontend/resources/js/Themes/civic/components/dashboard/VenueManager'
for line in (kit/'scripts/s5c_baseline.sha256').read_text().splitlines():
    expected,rel=line.split(maxsplit=1)
    path=s5c/'frontend'/rel
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        raise SystemExit('S5D_S5C_SOURCE_DRIFT='+rel)
print('S5D_S5C_SOURCE_BASELINE=PASS')
PY_CHECK
DEST="$REPO/_booketik_s5d_build"
[[ ! -e "$DEST" ]] || { echo 'S5D_BUILD_DIR=EXISTS'; exit 5; }
mkdir -p "$DEST"
python3 - "$SOURCE" "$DEST" <<'PY_UNPACK'
import pathlib,sys,tarfile
src,dest=sys.argv[1:]
with tarfile.open(src,'r:gz') as ar:
    seen=set()
    for e in ar:
        parts=pathlib.PurePosixPath(e.name).parts
        if not e.name or e.name.startswith('/') or '..' in parts or e.issym() or e.islnk() or e.isdev() or not (e.isfile() or e.isdir()) or e.name in seen or any(p in ('.env','vendor','node_modules','.git') for p in parts):
            raise SystemExit('S5D_SOURCE_ARCHIVE=UNSAFE')
        seen.add(e.name)
    ar.extractall(dest,filter='data')
PY_UNPACK
if [[ ! -f "$DEST/package.json" && -f "$DEST/source/package.json" ]]; then
    shopt -s dotglob nullglob
    mv "$DEST"/source/* "$DEST"/
    rmdir "$DEST/source"
    shopt -u dotglob nullglob
fi
[[ -f "$DEST/package-lock.json" && -f "$DEST/vite.config.js" && -f "$DEST/resources/js/pages.jsx" ]] || { echo 'S5D_SOURCE_LAYOUT=FAIL'; exit 6; }
python3 - "$KIT" "$S4C" "$S5C" "$DEST" <<'PY_OVERLAY'
import pathlib,sys,shutil
kit,s4c,s5c,dest=[pathlib.Path(p) for p in sys.argv[1:]]
def overlay(root,prior=None,strict_new=False):
    if not root.is_dir():raise SystemExit('S5D_MISSING_LAYER='+str(root))
    for src in sorted(root.rglob('*')):
        if not src.is_file():continue
        rel=src.relative_to(root);target=dest/rel
        if target.is_file():
            if not prior or not (prior/rel).is_file() or target.read_bytes()!=(prior/rel).read_bytes():
                raise SystemExit('S5D_SOURCE_DRIFT='+str(rel))
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,target)
for root in (s4c/'dependencies/s3t3-react',s4c/'frontend'):
    for src in sorted(root.rglob('*')):
        if not src.is_file():continue
        rel=src.relative_to(root);target=dest/rel
        if target.is_file() and target.read_bytes()!=src.read_bytes():raise SystemExit('S5D_S4C_BASE_CONFLICT='+str(rel))
        target.parent.mkdir(parents=True,exist_ok=True)
        if not target.exists():shutil.copy2(src,target)
overlay(s5c/'frontend',s4c/'frontend')
overlay(kit/'frontend',s5c/'frontend')
print('S5D_SOURCE_LAYERS=S4C_S5C_S5D_PASS')
PY_OVERLAY
cd "$DEST"
npm ci --no-audit --no-fund
npm run build
node - <<'JS'
const fs=require('fs');
const client=JSON.parse(fs.readFileSync('public/build/manifest.json','utf8'));
const ssr=JSON.parse(fs.readFileSync('bootstrap/ssr/ssr-manifest.json','utf8'));
for(const [name,manifest] of [['CLIENT',client],['SSR',ssr]]){
  for(const page of ['BooketikVenueManager.jsx','BooketikStudiosStandalone.jsx'])
    if(!Object.keys(manifest).some(k=>k.endsWith('/'+page))) throw Error('S5D_'+name+'_MISSING_'+page);
  console.log('S5D_'+name+'_ENTRIES='+Object.keys(manifest).length);
}
if(!fs.readFileSync('resources/js/Themes/civic/components/dashboard/VenueManager/Studio.jsx','utf8').includes('Auto-Seating'))throw Error('S5D_STUDIO_OVERLAY_MISSING');
JS
OUT="$REPO/BOOKETIK_S5D_AUTO_SEATING_COMPILED_20261111.tar.gz"
tar -czf "$OUT" public/build bootstrap/ssr
(cd "$REPO" && sha256sum "$(basename "$OUT")" > "$(basename "$OUT").sha256")
echo 'S5D_REACT_BUILD=PASS'
