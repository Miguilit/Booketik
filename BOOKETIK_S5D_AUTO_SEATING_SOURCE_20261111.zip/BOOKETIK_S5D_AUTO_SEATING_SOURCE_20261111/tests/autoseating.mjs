import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const source=readFileSync(new URL('../frontend/resources/js/Themes/civic/components/dashboard/VenueManager/autoSeating.js',import.meta.url),'utf8');
const {pointInShape,buildAutoSeatingPreview,applyAutoSeatingPreview}=await import('data:text/javascript;charset=utf-8,'+encodeURIComponent(source));
const rect={id:'geo-a',kind:'section',shape:'rect',zone_id:'vip',x:100,y:160,width:800,height:510,label:'Main'};
const plan={canvas:{width:1200,height:780},stage:{x:400,y:50,width:350,height:95},zones:[{id:'vip'},{id:'eco'}],geometry:{objects:[rect,{id:'geo-b',kind:'aisle',shape:'rect',x:465,y:170,width:70,height:500}]},seats:[]};
const cfg={canvasWidthM:24,seatPitchM:.55,rowPitchM:.9,seatDiameterM:.44,boundaryMarginM:.2,aisleClearanceM:.45,layout:'straight',mode:'add',zoneId:'vip'};
let res=buildAutoSeatingPreview(plan,'geo-a',cfg);
assert.equal(res.error,undefined,res.error);assert.ok(res.count>100&&res.count<1000,res.count);
for(const s of res.placements){
    assert.equal(pointInShape(rect,s,(.2+.22)*50),true);
    assert.ok(!(s.x>450&&s.x<550));
    assert.ok(!(s.x>=400-21&&s.x<=750+21&&s.y>=50-21&&s.y<=145+21));
}
for(let i=0;i<res.placements.length;i++)for(let j=i+1;j<res.placements.length;j++){
    const a=res.placements[i],b=res.placements[j];
    assert.ok(Math.hypot(a.x-b.x,a.y-b.y)>=.55*50-.2,'Metrological pitch collision');
}
let after=applyAutoSeatingPreview(plan,res);assert.equal(after.seats.length,res.count);assert.equal(after.measurement.canvas_width_m,24);
assert.equal(plan.seats.length,0);
const ids=after.seats.map(s=>s.id);assert.equal(new Set(ids).size,ids.length);
let collide=buildAutoSeatingPreview(after,'geo-a',cfg);assert.ok(collide.error,'No room to add another seat');
const staggered=buildAutoSeatingPreview(plan,'geo-a',{...cfg,layout:'staggered'});assert.ok(staggered.count>40);
const curved=buildAutoSeatingPreview(plan,'geo-a',{...cfg,layout:'curved'});assert.ok(curved.count>40);
const radial=buildAutoSeatingPreview(plan,'geo-a',{...cfg,layout:'radial'});assert.ok(radial.count>40);
const oval={...rect,shape:'ellipse'};
assert.equal(pointInShape(oval,{x:rect.x,y:rect.y}),false);
assert.equal(pointInShape(oval,{x:500,y:400}),true);
const poly={...rect,shape:'polygon',points:[[0,0],[1,0],[1,1],[.5,.45],[0,1]]};
assert.equal(pointInShape(poly,{x:500,y:450},10),false);
assert.equal(pointInShape(poly,{x:500,y:230},10),true);
const invalid=buildAutoSeatingPreview(plan,'geo-a',{...cfg,seatPitchM:.1});assert.ok(invalid.error);
const sourceRow1=after.seats.filter(s=>s.row===after.seats[0].row).slice(0,4);
const sourceRow2=after.seats.filter(s=>s.row!==after.seats[0].row).slice(0,3);
const base={...plan,seats:[...sourceRow1,...sourceRow2].map(s=>({...s,accessible:true}))};
const aligned=buildAutoSeatingPreview(base,'geo-a',{...cfg,mode:'align'});
assert.equal(aligned.error,undefined,aligned.error);
assert.equal(aligned.count,7);
const realigned=applyAutoSeatingPreview(base,aligned);
assert.deepEqual(realigned.seats.map(s=>s.id),base.seats.map(s=>s.id));
assert.ok(realigned.seats.every(s=>s.accessible));
assert.deepEqual(realigned.seats.map(s=>s.row),base.seats.map(s=>s.row));
assert.ok(realigned.seats.some((s,i)=>s.x!==base.seats[i].x||s.y!==base.seats[i].y));
console.log('S5D_TESTS=PASS; generated='+res.count+' curved='+curved.count+' radial='+radial.count+' aligned='+aligned.count);

const giant=buildAutoSeatingPreview(plan,'geo-a',{...cfg,canvasWidthM:500,seatPitchM:.3,rowPitchM:.3,seatDiameterM:.3});
assert.ok(giant.error && giant.error.includes('limite'));
const blankBoundary={...rect,kind:'boundary',zone_id:null};
const boundaryPreview=buildAutoSeatingPreview({...plan,geometry:{objects:[blankBoundary]}},'geo-a',{...cfg,zoneId:''});
assert.ok(boundaryPreview.count>20,'Boundary falls back to first zone');
console.log('S5D_LIMITS_AND_BOUNDARIES=PASS');
