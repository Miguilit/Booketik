<?php
require __DIR__ . '/../backend/app/Services/Seating/SeatingPlanContract.php';
use App\Services\Seating\SeatingPlanContract as Contract;
$legacy = ['schema'=>'booketik.seating.v1','canvas'=>['width'=>1200,'height'=>780],
    'stage'=>['label'=>'Scène','x'=>350,'y'=>55,'width'=>500,'height'=>105],
    'zones'=>[['id'=>'vip','label'=>'VIP','color'=>'#DAA942']],
    'seats'=>[['id'=>'A-01','row'=>'A','number'=>'1','x'=>180,'y'=>240,'zone_id'=>'vip','accessible'=>true]]];
$normalized=Contract::normalize($legacy);
if (isset($normalized['geometry']) || count($normalized['seats'])!==1 || !$normalized['seats'][0]['accessible']) throw new Exception('LEGACY=FAIL');
$next=$legacy;
$next['geometry']=['version'=>1,'objects'=>[['id'=>'geo-test-1','kind'=>'section','shape'=>'polygon',
    'label'=>'Parterre','color'=>'#00AABB','zone_id'=>'vip','x'=>100,'y'=>200,'width'=>200,'height'=>100,
    'points'=>[[0,0],[1,0],[1,1],[0,1]]]]];
$done=Contract::normalize($next);
if ($done['geometry']['objects'][0]['zone_id'] !== 'vip' || $done['geometry']['objects'][0]['points'][2] !== [1,1]) throw new Exception('GEOMETRY=FAIL');
$invalid=$next; $invalid['geometry']['objects'][0]['zone_id']='nonexistent';
try { Contract::normalize($invalid); throw new Exception('INVALID=ACCEPTED'); }
catch (InvalidArgumentException $e) { /* fail-closed as expected */ }
$invalid=$next; $invalid['geometry']['objects'][0]['x']=1100;
try { Contract::normalize($invalid); throw new Exception('OUTSIDE=ACCEPTED'); }
catch (InvalidArgumentException $e) { /* fail-closed as expected */ }
$invalid=$next; $invalid['geometry']['objects'][0]['label']='<script>alert(1)</script>';
// It is treated as plain text; React escapes rendering and no markup is executed.
if (Contract::normalize($invalid)['geometry']['objects'][0]['label'] !== '<script>alert(1)</script>') throw new Exception('TEXT=FAIL');
echo "S5C_LEGACY=PASS\nS5C_GEOMETRY=PASS\nS5C_INVALID_GUARDS=PASS\n";

$metric = $next;
$metric['measurement'] = ['version'=>1,'unit'=>'m','canvas_width_m'=>24.5];
$stored = Contract::normalize($metric);
if (($stored['measurement']['canvas_width_m'] ?? null) !== 24.5 || count($stored['seats']) !== 1 || count($stored['geometry']['objects']) !== 1) throw new Exception('MEASUREMENT_PERSISTENCE=FAIL');
foreach ([0, 1, 501, INF, NAN] as $badWidth) {
    $invalid = $metric;
    $invalid['measurement']['canvas_width_m'] = $badWidth;
    try { Contract::normalize($invalid); throw new Exception('MEASUREMENT_INVALID_ACCEPTED'); }
    catch (InvalidArgumentException $e) { /* invalid scale rejected */ }
}
$invalid = $metric; $invalid['measurement']['unit'] = 'ft';
try { Contract::normalize($invalid); throw new Exception('UNSUPPORTED_UNIT_ACCEPTED'); }
catch (InvalidArgumentException $e) { /* unsupported units rejected */ }
$invalid = $metric; $invalid['measurement']['version'] = 2;
try { Contract::normalize($invalid); throw new Exception('UNSUPPORTED_MEASUREMENT_ACCEPTED'); }
catch (InvalidArgumentException $e) { /* strict schema */ }
echo "S5D_LEGACY_REVISIONS=PASS\nS5D_MEASUREMENT_PERSISTENCE=PASS\nS5D_MEASUREMENT_GUARDS=PASS\n";
