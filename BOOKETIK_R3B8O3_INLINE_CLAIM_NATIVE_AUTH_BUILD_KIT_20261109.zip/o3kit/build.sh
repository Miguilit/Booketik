#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
INPUT="${1:?Pass the R3B8O2 frontend source tar.gz as argument}"
OUT="${2:-$PWD}"
INPUT="$(cd "$(dirname "$INPUT")" && pwd -P)/$(basename "$INPUT")"
mkdir -p "$OUT"
OUT="$(cd "$OUT" && pwd -P)"
[[ "$(sha256sum "$INPUT" | cut -d' ' -f1)" == '181cbe78ccfa1668c0fb8efec4377ad0faf9980cb42bb9bc38fedb5ed361a92f' ]] || { echo 'SOURCE_ARCHIVE_SHA_GUARD=FAIL'; exit 2; }
command -v node >/dev/null && command -v npm >/dev/null || { echo 'NODE_NPM_REQUIRED'; exit 2; }
node -e 'const v=process.versions.node.split(".").map(Number);if(v[0]<22||(v[0]===22&&v[1]<12))process.exit(1)' || { echo 'NODE_22_12_REQUIRED'; exit 2; }
if tar -tzf "$INPUT" | grep -Eq '(^/|(^|/)\.\.(/|$))'; then echo 'UNSAFE_SOURCE_ARCHIVE'; exit 2; fi
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
tar -xzf "$INPUT" -C "$WORK"
SRC="$WORK/source"
( cd "$SRC" && sha256sum -c "$WORK/source_sha256.txt" >/dev/null ) || { echo 'ORIGINAL_SOURCE_HASHES=FAIL'; exit 2; }
( cd "$KIT/patch/files" && sha256sum -c "$KIT/patch/package_hashes.txt" >/dev/null ) || { echo 'PATCH_HASHES=FAIL'; exit 2; }
( cd "$SRC" && sha256sum -c "$KIT/frontend_base_hashes.txt" >/dev/null ) || { echo 'FRONTEND_THEME_BASELINE=FAIL'; exit 2; }
for THEME in civic almanac marquee; do
  path="resources/js/Themes/$THEME/Pages/Site/Event.jsx"
  cp "$KIT/patch/files/$path" "$SRC/$path"
done
mkdir -p "$SRC/resources/js/Core/components"
cp "$KIT/patch/files/resources/js/Core/components/ExternalClaimInline.jsx" "$SRC/resources/js/Core/components/ExternalClaimInline.jsx"
echo '===== NPM INSTALL ====='
(cd "$SRC" && npm ci --no-audit --no-fund)
echo '===== VITE BUILD ====='
(cd "$SRC" && npm run build)
node "$KIT/verify_manifest.mjs" "$SRC"
test -f "$SRC/bootstrap/ssr/ssr.js" || { echo 'SSR_OUTPUT_MISSING'; exit 2; }
RELEASE="$WORK/release"
mkdir -p "$RELEASE/assets/public" "$RELEASE/assets/bootstrap"
cp -a "$KIT/patch" "$RELEASE/package"
cp -a "$SRC/public/build" "$RELEASE/assets/public/build"
cp -a "$SRC/bootstrap/ssr" "$RELEASE/assets/bootstrap/ssr"
( cd "$RELEASE" && find assets -type f -print0 | sort -z | xargs -0 sha256sum > asset_hashes.txt )
( cd "$RELEASE" && sha256sum -c asset_hashes.txt >/dev/null )
printf 'BUILD=R3B8O3_INLINE_NATIVE_AUTH\nNODE=%s\nNPM=%s\n' "$(node -v)" "$(npm -v)" > "$RELEASE/BUILD_INFO.txt"
FILE='BOOKETIK_R3B8O3_COMPILED_FOR_HOSTINGER_20261109.tar.gz'
( cd "$WORK" && tar -czf "$OUT/$FILE" release )
( cd "$OUT" && sha256sum "$FILE" > "$FILE.sha256" )
echo "BUILD=PASS CLIENT=PASS SSR_FILES=PASS"
echo "ARTIFACT=$OUT/$FILE"
