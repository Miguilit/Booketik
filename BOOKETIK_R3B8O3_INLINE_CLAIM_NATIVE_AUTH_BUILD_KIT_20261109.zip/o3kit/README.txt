BOOKETIK R3-B8-O3 — native inline claim, guarded build kit.

PURPOSE
Native claim panel inside Eventgoo's three theme event pages.
Existing Eventgoo login/register and email verification stay authoritative.
Explicit session intent; once email verified, a pending claim enters admin inbox.
A provisional unverified Organizer is created only when the user owns no organizer profile.
Proof is then added via the same inline panel; admin verifies and approves separately.
No event transfer, ticket, subscription, plan assignment or payment is activated.

COMPILATION (GitHub Actions)
1. Keep the previously uploaded private frontend source TAR.GZ in the repo root.
2. Upload this build kit ZIP to the private repo root.
3. Add the workflow .github/workflows/booketik-o3.yml from the accompanying instructions.
4. Run the workflow, download compiled artifact containing TAR.GZ and .sha256.

DEPLOYMENT (NOT BEFORE VERIFYING BUILD)
Upload only the two compiled files to ~/domains/booketik.com; upload deploy.sh separately from this kit.
Make a SQL backup before applying: the release makes verification_url nullable for provisional claims.
  bash deploy.sh "$HOME/domains/booketik.com" --apply
Code/asset SHA preflight guards must match O2 production exactly. Any drift blocks the release.
The previous event pages remain active until assets are swapped.
The DB alteration is preserved on rollback to protect existing human-submitted claim rows.
After the first functional smoke test confirm user verification, claim inbox and no ticketing grant.

Manual rollback after successful deployment:
 bash o3kit/rollback_full.sh <root> <RELEASE_STAGE> <BACKUP_PATH> <CODE_BACKUP_PATH>
Use the three paths printed at deployment. SSR process restart remains manual if active.
