#!/usr/bin/env bash
set -euo pipefail
APP="$(cd "${1:?Laravel root required}" && pwd -P)"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
[[ -f "$APP/artisan" && -f "$APP/routes/web.php" ]] || { echo 'APP_ROOT_INVALID'; exit 2; }
( cd "$PKG/files" && sha256sum -c "$PKG/package_hashes.txt" >/dev/null ) || { echo 'PACKAGE_SHA_GUARDS=FAIL'; exit 2; }
( cd "$APP" && sha256sum -c "$PKG/source_hashes.txt" >/dev/null ) || { echo 'SOURCE_SHA_GUARDS=FAIL'; exit 2; }
while IFS= read -r path; do
  [[ -n "$path" ]] || continue
  [[ ! -e "$APP/$path" ]] || { echo "NEW_FILE_ALREADY_EXISTS=$path"; exit 2; }
done < "$PKG/new_paths.txt"
[[ -f "$APP/app/Models/ExternalEventClaim.php" && -f "$APP/app/Services/Events/OrganizerService.php" ]] || { echo 'NATIVE_CLAIM_DEPENDENCIES_MISSING'; exit 2; }
[[ -f "$APP/database/migrations/2026_11_09_150001_create_external_event_claims_table.php" ]] || { echo 'CLAIMS_SCHEMA_MISSING'; exit 2; }
PHP="${BOOKETIK_PHP_BIN:-/opt/alt/php84/usr/bin/php}"
[[ -x "$PHP" ]] || { echo 'PHP84_MISSING'; exit 2; }
for f in $(find "$PKG/files" -type f -name '*.php'); do "$PHP" -l "$f" >/dev/null || { echo "PHP_LINT=FAIL $f"; exit 2; }; done
for theme in almanac civic marquee; do
  grep -Fq '<ExternalClaimInline claim={externalClaim} />' "$PKG/files/resources/js/Themes/$theme/Pages/Site/Event.jsx" || exit 2
done
grep -Fq 'EMAIL_VERIFICATION_REQUIRED' "$PKG/files/app/Services/Events/External/ExternalEventClaimIntake.php" || exit 2
grep -Fq 'CLAIM_EVIDENCE_REQUIRED' "$PKG/files/app/Http/Controllers/Admin/ExternalEventClaimController.php" || exit 2
echo "SOURCE_SHA_GUARDS=PASS PACKAGE_SHA_GUARDS=PASS PHP_LINT=PASS FILE_COUNT=$(wc -l < "$PKG/package_hashes.txt")"
echo 'PREFLIGHT=PASS EXISTING_EVENT_WRITES=0 ENV_WRITES=0 PROVIDER_CALLS=0 NATIVE_PRICING_UNCHANGED=YES'
