#!/usr/bin/env bash
set -euo pipefail
APP="$(cd "${1:?app}" && pwd -P)"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
( cd "$APP" && sha256sum -c "$PKG/package_hashes.txt" >/dev/null ) || { echo 'VERIFY_SHA=FAIL'; exit 1; }
PHP="${BOOKETIK_PHP_BIN:-/opt/alt/php84/usr/bin/php}"
for f in $(find "$PKG/files" -type f -name '*.php'); do "$PHP" -l "$f" >/dev/null || exit 1; done
echo "VERIFY_SHA=PASS PHP_LINT=PASS FILE_COUNT=$(wc -l < "$PKG/package_hashes.txt")"
