<?php

declare(strict_types=1);

namespace App\Services\Events\External;

use App\Enums\OrganizerRole;
use App\Models\Event;
use App\Models\ExternalEventClaim;
use App\Models\ExternalEventListing;
use App\Models\Organizer;
use App\Models\User;
use App\Services\Events\OrganizerService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/** Session-scoped, explicit claim intent; never grants event ownership or sales. */
final class ExternalEventClaimIntake
{
    private const KEY = 'booketik.external_claim_intent';
    private const TTL = 86400;

    public function __construct(private readonly ExternalEventVisibility $visibility, private readonly OrganizerService $organizers) {}

    public function begin(Request $request, string $slug): void
    {
        $event = $this->eligible($slug);
        $user = $request->user();
        $selected = $request->validate(['organizer_id' => ['nullable', 'uuid']])['organizer_id'] ?? null;
        if ($selected !== null) {
            abort_unless($user !== null && $this->manageable($user, $selected), 403);
        }
        $request->session()->put(self::KEY, [
            'listing_id' => (string) $event->externalListing->id,
            'slug' => $slug,
            'at' => time(),
            'user_id' => $user?->id,
            'organizer_id' => $selected,
        ]);
    }

    public function pending(Request $request, string $slug, string $listingId): bool
    {
        $intent = $request->session()->get(self::KEY);
        return is_array($intent) && hash_equals((string) ($intent['listing_id'] ?? ''), $listingId)
            && ($intent['slug'] ?? '') === $slug && is_numeric($intent['at'] ?? null)
            && (time() - (int) $intent['at']) <= self::TTL
            && (time() - (int) $intent['at']) >= 0;
    }

    public function finish(Request $request, string $slug): ExternalEventClaim
    {
        $user = $request->user();
        abort_unless($user && $user->email_verified_at !== null, 403, 'EMAIL_VERIFICATION_REQUIRED');
        $event = $this->eligible($slug);
        abort_unless($this->pending($request, $slug, (string) $event->externalListing->id), 409, 'CLAIM_INTENT_MISSING_OR_EXPIRED');
        $intent = $request->session()->get(self::KEY);
        if (($intent['user_id'] ?? null) !== null) {
            abort_unless((string) $intent['user_id'] === (string) $user->id, 403);
        }
        $claim = DB::transaction(function () use ($event, $user, $intent): ExternalEventClaim {
            $listing = ExternalEventListing::query()->whereKey($event->externalListing->id)->lockForUpdate()->firstOrFail();
            $event->setRelation('externalListing', $listing);
            abort_unless($this->visibility->mayShow($event), 409, 'EVENT_NOT_ELIGIBLE');
            abort_if(ExternalEventClaim::query()->where('listing_id', $listing->id)
                ->where('status', ExternalEventClaim::APPROVED)->exists(), 409, 'CLAIM_ALREADY_APPROVED');
            $existing = ExternalEventClaim::query()->where('listing_id', $listing->id)
                ->where('requested_by', $user->id)->first();
            if ($existing !== null) {
                return $existing; // Never duplicate requests after reload/retry.
            }
            $org = $this->resolveOrganizer($user, $intent['organizer_id'] ?? null);
            return ExternalEventClaim::query()->create([
                'listing_id' => $listing->id,
                'organizer_id' => $org->id,
                'requested_by' => $user->id,
                'verification_url' => null,
                'verification_note' => 'Demande initiée depuis la fiche BOOKETIK Culture ; justificatif non fourni à ce stade. Vérification manuelle requise.',
                'status' => ExternalEventClaim::PENDING,
            ]);
        });
        $request->session()->forget(self::KEY);
        return $claim;
    }

    public function evidence(Request $request, string $slug): void
    {
        $user = $request->user();
        abort_unless($user && $user->email_verified_at !== null, 403);
        $event = $this->eligible($slug);
        $data = $request->validate([
            'verification_url' => ['required', 'url:https', 'max:2048'],
            'verification_note' => ['required', 'string', 'min:20', 'max:2000'],
        ]);
        $changed = ExternalEventClaim::query()->where('listing_id', $event->externalListing->id)
            ->where('requested_by', $user->id)->where('status', ExternalEventClaim::PENDING)
            ->update($data);
        abort_unless($changed === 1, 409, 'CLAIM_NOT_PENDING');
    }

    private function resolveOrganizer(User $user, mixed $selected): Organizer
    {
        if (is_string($selected) && $selected !== '') {
            abort_unless($this->manageable($user, $selected), 403);
            return Organizer::query()->active()->findOrFail($selected);
        }
        $organizations = Organizer::query()->active()->whereHas('members', fn ($q) => $q
            ->where('user_id', $user->id)->whereIn('role', [OrganizerRole::Owner->value, OrganizerRole::Admin->value]))
            ->limit(2)->get();
        if ($organizations->count() === 1) return $organizations->first();
        abort_if($organizations->count() > 1, 422, 'SELECT_ORGANIZER_REQUIRED');
        $name = trim((string) $user->name) ?: Str::before((string) $user->email, '@');
        return $this->organizers->create($user, [
            'name' => mb_substr($name, 0, 180),
            'contact_email' => $user->email,
            'is_verified' => false,
        ]);
    }

    private function manageable(User $user, string $id): bool
    {
        return Organizer::query()->active()->whereKey($id)->whereHas('members', fn ($q) => $q
            ->where('user_id', $user->id)->whereIn('role', [OrganizerRole::Owner->value, OrganizerRole::Admin->value]))->exists();
    }

    private function eligible(string $slug): Event
    {
        $event = Event::query()->with(['externalListing.source'])->where('slug', $slug)->firstOrFail();
        abort_unless($event->externalListing !== null && $this->visibility->mayShow($event), 404);
        return $event;
    }
}
