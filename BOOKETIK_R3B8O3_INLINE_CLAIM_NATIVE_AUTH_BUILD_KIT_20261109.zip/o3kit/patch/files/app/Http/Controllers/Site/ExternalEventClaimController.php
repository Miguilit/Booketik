<?php

declare(strict_types=1);

namespace App\Http\Controllers\Site;

use App\Enums\OrganizerRole;
use App\Enums\PlanAudience;
use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\ExternalEventClaim;
use App\Models\ExternalEventListing;
use App\Models\Organizer;
use App\Models\SubscriptionPlan;
use App\Services\Events\External\ExternalEventVisibility;
use App\Support\Money;
use App\Support\Pricing;
use App\Services\Events\External\ExternalEventClaimIntake;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

/** Public intake is authenticated, verified-email, throttled and claim-only. */
final class ExternalEventClaimController extends Controller
{
    /** Legacy /culture/claim URL: keep old links working without a satellite page. */
    public function show(Request $request, string $locale, string $slug, ExternalEventVisibility $visibility): RedirectResponse
    {
        $this->eligibleEvent($slug, $visibility);
        return redirect()->to(route('site.event', compact('locale', 'slug')).'#claim');
    }

    /** Explicit visitor intent, tied to the server session (not a query string). */
    public function begin(Request $request, string $locale, string $slug, ExternalEventClaimIntake $intake): RedirectResponse
    {
        abort_if(config('eventgoo.demo_mode'), 403, 'DEMO_MODE');
        $this->eligibleEvent($slug, app(ExternalEventVisibility::class));
        $intake->begin($request, $slug);
        return redirect()->to(route('site.event', compact('locale', 'slug')).'#claim');
    }

    /** Finalize the claim after *verified* native sign-up/sign-in. */
    public function finish(Request $request, string $locale, string $slug, ExternalEventClaimIntake $intake): RedirectResponse
    {
        abort_if(config('eventgoo.demo_mode'), 403, 'DEMO_MODE');
        $intake->finish($request, $slug);
        return redirect()->to(route('site.event', compact('locale', 'slug')).'#claim')
            ->with('success', 'Votre demande a été transmise pour vérification.');
    }

    /** Optional evidence is supplied later; the claim is NEVER automatically approved. */
    public function evidence(Request $request, string $locale, string $slug, ExternalEventClaimIntake $intake): RedirectResponse
    {
        abort_if(config('eventgoo.demo_mode'), 403, 'DEMO_MODE');
        $intake->evidence($request, $slug);
        return redirect()->to(route('site.event', compact('locale', 'slug')).'#claim')
            ->with('success', 'Vos justificatifs ont été enregistrés.');
    }

    public function store(Request $request, string $locale, string $slug, ExternalEventVisibility $visibility): RedirectResponse
    {
        abort_if(config('eventgoo.demo_mode'), 403, 'DEMO_MODE');
        $data = $request->validate([
            'organizer_id' => ['required', 'uuid', 'exists:organizers,id'],
            'verification_url' => ['required', 'url:https', 'max:2048'],
            'verification_note' => ['required', 'string', 'min:20', 'max:2000'],
            'confirmation' => ['accepted'],
        ]);
        $user = $request->user();
        $org = Organizer::query()->whereKey($data['organizer_id'])->active()->firstOrFail();
        abort_unless($org->hasMemberWithRole($user, OrganizerRole::Admin), 403);

        DB::transaction(function () use ($slug, $visibility, $data, $org, $user): void {
            $event = Event::query()->where('slug', $slug)->firstOrFail();
            $listing = ExternalEventListing::query()->where('event_id', $event->id)->lockForUpdate()->firstOrFail();
            $event->setRelation('externalListing', $listing);
            abort_unless($visibility->mayShow($event), 404);
            abort_if(ExternalEventClaim::query()->where('listing_id', $listing->id)
                ->where('status', ExternalEventClaim::APPROVED)->exists(), 409, 'CLAIM_ALREADY_APPROVED');
            abort_if(ExternalEventClaim::query()->where('listing_id', $listing->id)
                ->where('organizer_id', $org->id)->exists(), 409, 'CLAIM_ALREADY_SUBMITTED');
            ExternalEventClaim::query()->create([
                'listing_id' => $listing->id,
                'organizer_id' => $org->id,
                'requested_by' => $user->id,
                'verification_url' => $data['verification_url'],
                'verification_note' => $data['verification_note'],
                'status' => ExternalEventClaim::PENDING,
            ]);
        });

        return redirect()->route('site.external-claims.show', compact('locale', 'slug'))
            ->with('success', __('booketik_claims.submitted'));
    }

    private function eligibleEvent(string $slug, ExternalEventVisibility $visibility): Event
    {
        $event = Event::query()->with(['externalListing.source', 'organizer'])->where('slug', $slug)->firstOrFail();
        abort_unless($event->externalListing !== null && $visibility->mayShow($event), 404);
        return $event;
    }
}
