<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ExternalEventClaim;
use App\Models\ExternalEventListing;
use App\Services\Events\External\ExternalEventVisibility;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Admin review of organizer identity; approval never enables checkout. */
final class ExternalEventClaimController extends Controller
{
    public function index(Request $request, string $locale): View
    {
        $status = (string) $request->query('status', ExternalEventClaim::PENDING);
        abort_unless(in_array($status, [ExternalEventClaim::PENDING, ExternalEventClaim::APPROVED, ExternalEventClaim::REJECTED], true), 422);
        $claims = ExternalEventClaim::query()
            ->where('status', $status)
            ->with(['listing.event', 'listing.source', 'organizer', 'requester', 'reviewer'])
            ->orderBy('created_at')
            ->paginate(20)->withQueryString();
        return view('admin.external-claims.index', compact('claims', 'status', 'locale'));
    }

    public function approve(Request $request, string $locale, string $claim, ExternalEventVisibility $visibility): RedirectResponse
    {
        abort_if(config('eventgoo.demo_mode'), 403, 'DEMO_MODE');
        $request->validate(['review_confirmed' => ['accepted'], 'review_note' => ['required', 'string', 'min:10', 'max:2000']]);
        DB::transaction(function () use ($request, $claim, $visibility): void {
            $model = ExternalEventClaim::query()->lockForUpdate()->findOrFail($claim);
            abort_unless($model->status === ExternalEventClaim::PENDING, 409, 'CLAIM_NOT_PENDING');
            abort_unless($model->requester?->email_verified_at !== null, 409, 'REQUESTER_EMAIL_NOT_VERIFIED');
            abort_unless(filled($model->verification_url), 409, 'CLAIM_EVIDENCE_REQUIRED');
            // A platform admin may not approve their own claim.
            abort_if($model->requested_by === $request->user()->id, 403, 'SELF_REVIEW_NOT_ALLOWED');
            $listing = ExternalEventListing::query()->whereKey($model->listing_id)->lockForUpdate()->firstOrFail();
            abort_if(ExternalEventClaim::query()->where('listing_id', $listing->id)
                ->where('status', ExternalEventClaim::APPROVED)->exists(), 409, 'CLAIM_ALREADY_APPROVED');
            $event = $listing->event;
            abort_unless($event !== null && $visibility->mayShow($event), 409, 'EVENT_NOT_ELIGIBLE');
            abort_unless($model->organizer?->isActive(), 409, 'ORGANIZER_NOT_ACTIVE');
            $model->forceFill([
                'status' => ExternalEventClaim::APPROVED,
                'reviewed_by' => $request->user()->id,
                'reviewed_at' => now(),
                'review_note' => $request->string('review_note')->toString(),
            ])->save();
            // Critically: DO NOT change event.organizer_id, modules.tickets,
            // subscription, price, fee, checkout, catalog, or sync gates.
        });
        return back()->with('success', __('booketik_claims.verified'));
    }

    public function reject(Request $request, string $locale, string $claim): RedirectResponse
    {
        abort_if(config('eventgoo.demo_mode'), 403, 'DEMO_MODE');
        $request->validate(['review_note' => ['required', 'string', 'min:10', 'max:2000']]);
        DB::transaction(function () use ($request, $claim): void {
            $model = ExternalEventClaim::query()->lockForUpdate()->findOrFail($claim);
            abort_unless($model->status === ExternalEventClaim::PENDING, 409, 'CLAIM_NOT_PENDING');
            $model->forceFill([
                'status' => ExternalEventClaim::REJECTED,
                'reviewed_by' => $request->user()->id,
                'reviewed_at' => now(),
                'review_note' => $request->string('review_note')->toString(),
            ])->save();
        });
        return back()->with('success', __('booketik_claims.rejected'));
    }
}
