<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // A registration-based claim is a lead, NOT evidence of ownership.
        Schema::table('external_event_claims', function (Blueprint $table): void {
            $table->string('verification_url', 2048)->nullable()->change();
        });
    }

    public function down(): void
    {
        // Retain human-created leads and their data. Never force a NOT NULL or discard rows.
    }
};
