#!/usr/bin/env bash
set -euo pipefail
APP="$(cd "${1:?app}" && pwd -P)"
BACKUP="$(cd "${2:?backup}" && pwd -P)"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
[[ -f "$BACKUP/routes/web.php" ]] || { echo 'BACKUP_INVALID'; exit 2; }
( cd "$APP" && sha256sum -c "$PKG/package_hashes.txt" >/dev/null ) || { echo 'LIVE_CODE_DRIFT_REFUSAL'; exit 2; }
while read -r digest path; do
  cp -p "$BACKUP/$path" "$APP/$path"
done < "$PKG/source_hashes.txt"
while IFS= read -r path; do
  [[ -n "$path" ]] || continue
  rm -f "$APP/$path"
done < "$PKG/new_paths.txt"
echo 'ROLLBACK_CODE=PASS MIGRATION_SCHEMA_RETAINED=YES'
