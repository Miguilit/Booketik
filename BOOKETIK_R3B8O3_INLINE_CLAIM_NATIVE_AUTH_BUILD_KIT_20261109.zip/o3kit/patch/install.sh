#!/usr/bin/env bash
set -euo pipefail
APP="$(cd "${1:?Laravel root required}" && pwd -P)"
[[ "${2:-}" == '--apply' ]] || { echo 'APPLY_CONFIRMATION_REQUIRED'; exit 2; }
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
bash "$PKG/preflight.sh" "$APP"
ROOT="$(dirname "$APP")"
BACKUP="$(mktemp -d "$ROOT/booketik_r3b8o3_code_backup_$(date -u +%Y%m%dT%H%M%SZ)_XXXX")"
while read -r digest path; do
  mkdir -p "$BACKUP/$(dirname "$path")"
  cp -p "$APP/$path" "$BACKUP/$path"
done < "$PKG/source_hashes.txt"
echo "CODE_BACKUP_PATH=$BACKUP"
trap 'status=$?; if (( status != 0 )); then echo "INSTALL_FAILED=$status CODE_ROLLBACK_ATTEMPT=YES"; bash "$PKG/rollback.sh" "$APP" "$BACKUP" || echo "MANUAL_CODE_ROLLBACK_REQUIRED"; fi' EXIT
while read -r digest path; do
  mkdir -p "$APP/$(dirname "$path")"
  cp -p "$PKG/files/$path" "$APP/$path"
done < "$PKG/package_hashes.txt"
bash "$PKG/verify.sh" "$APP"
PHP="${BOOKETIK_PHP_BIN:-/opt/alt/php84/usr/bin/php}"
( cd "$APP" && "$PHP" artisan migrate --path=database/migrations/2026_11_09_170001_allow_pending_claim_without_evidence.php --force --no-interaction )
trap - EXIT
echo 'INSTALL=PASS MIGRATION=ALLOW_PENDING_CLAIMS_WITHOUT_EVIDENCE EVENTS_UNCHANGED=YES NO_TICKETING_OR_PRICING_CHANGES=YES'
echo 'SCHEMA_ROLLBACK=NOT_AUTOMATIC (nullable column retained to preserve submitted claims)'
