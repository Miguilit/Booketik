#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "${1:?root}" && pwd -P)"
STAGE="$(cd "${2:?release stage}" && pwd -P)"
BACKUP="$(cd "${3:?full asset backup}" && pwd -P)"
CODE="$(cd "${4:?code backup}" && pwd -P)"
APP="$ROOT/eventgoo"; REL="$STAGE/release"; PKG="$REL/package"
[[ -f "$REL/asset_hashes.txt" && -d "$BACKUP/assets/build" && -f "$PKG/rollback.sh" ]] || { echo 'BACKUP_OR_RELEASE_INVALID'; exit 2; }
( cd "$APP" && sha256sum -c "$PKG/package_hashes.txt" >/dev/null ) || { echo 'LIVE_CODE_DRIFT_REFUSAL'; exit 2; }
( cd "$REL" && while read -r digest path; do
  live="$APP/${path#assets/}"
  [[ -f "$live" && "$(sha256sum "$live" | cut -d' ' -f1)" == "$digest" ]] || { echo "LIVE_ASSET_DRIFT_REFUSAL=$path"; exit 2; }
done < asset_hashes.txt )
rm -rf "$APP/public/build" "$APP/bootstrap/ssr"
cp -a "$BACKUP/assets/build" "$APP/public/build"
if [[ -d "$BACKUP/assets/ssr" ]]; then cp -a "$BACKUP/assets/ssr" "$APP/bootstrap/ssr"; fi
bash "$PKG/rollback.sh" "$APP" "$CODE"
"${BOOKETIK_PHP_BIN:-/opt/alt/php84/usr/bin/php}" "$APP/artisan" optimize:clear
echo 'FULL_ROLLBACK=PASS CLAIM_MIGRATION_SCHEMA_RETAINED=YES SSR_SERVICE_RESTART=MANUAL_IF_RUNNING'
