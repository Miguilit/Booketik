#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "${1:?Pass Hostinger ~/domains/booketik.com}" && pwd -P)"
[[ "${2:-}" == '--apply' ]] || { echo 'CONFIRMATION_REQUIRED'; exit 2; }
APP="$ROOT/eventgoo"
FILE="$ROOT/BOOKETIK_R3B8O3_COMPILED_FOR_HOSTINGER_20261109.tar.gz"
SUM="$FILE.sha256"
[[ -f "$APP/artisan" && -f "$FILE" && -f "$SUM" ]] || { echo 'INPUTS_MISSING'; exit 2; }
( cd "$ROOT" && sha256sum -c "$(basename "$SUM")" ) || { echo 'RELEASE_SHA=FAIL'; exit 2; }
if tar -tzf "$FILE" | grep -Eq '(^/|(^|/)\.\.(/|$))'; then echo 'UNSAFE_RELEASE'; exit 2; fi
[[ "$(sha256sum "$APP/public/build/manifest.json" | cut -d' ' -f1)" == '9d1c6291c6ab89fdca18a03ac2d3a5234717ef0f5f005aed32fd272963a4cd5b' ]] || { echo 'LIVE_MANIFEST_DRIFT_REFUSAL'; exit 2; }
STAGE="$(mktemp -d "$ROOT/_private_r3b8o3_release_XXXXXX")"
tar -xzf "$FILE" -C "$STAGE"
REL="$STAGE/release"
PKG="$REL/package"
( cd "$REL" && sha256sum -c asset_hashes.txt >/dev/null ) || { echo 'ASSET_SHA=FAIL'; exit 2; }
[[ -f "$REL/assets/public/build/manifest.json" && -f "$REL/assets/bootstrap/ssr/ssr.js" ]] || { echo 'ASSETS_MISSING'; exit 2; }
bash "$PKG/preflight.sh" "$APP"
PHP="${BOOKETIK_PHP_BIN:-/opt/alt/php84/usr/bin/php}"
[[ -x "$PHP" ]] || { echo 'PHP84_MISSING'; exit 2; }
BACKUP="$(mktemp -d "$ROOT/booketik_r3b8o3_full_backup_$(date -u +%Y%m%dT%H%M%SZ)_XXXX")"
mkdir -p "$BACKUP/assets"
cp -a "$APP/public/build" "$BACKUP/assets/build"
if [[ -d "$APP/bootstrap/ssr" ]]; then cp -a "$APP/bootstrap/ssr" "$BACKUP/assets/ssr"; fi
NEXT_BUILD="$(mktemp -d "$APP/public/.booketik_o3_next_build_XXXXXX")"
NEXT_SSR="$(mktemp -d "$APP/bootstrap/.booketik_o3_next_ssr_XXXXXX")"
cp -a "$REL/assets/public/build/." "$NEXT_BUILD/"
cp -a "$REL/assets/bootstrap/ssr/." "$NEXT_SSR/"
CODE_BACKUP=''; CODE_INSTALLED=0; ASSETS_TOUCHED=0
recover() {
  status=$?
  if (( status != 0 )); then
    echo "DEPLOY_FAILED=$status ROLLBACK_ATTEMPT=YES"
    if (( ASSETS_TOUCHED )); then
      rm -rf "$APP/public/build" "$APP/bootstrap/ssr"
      cp -a "$BACKUP/assets/build" "$APP/public/build" || echo 'MANUAL_ASSET_ROLLBACK_REQUIRED'
      if [[ -d "$BACKUP/assets/ssr" ]]; then cp -a "$BACKUP/assets/ssr" "$APP/bootstrap/ssr"; fi
    fi
    if (( CODE_INSTALLED )) && [[ -n "$CODE_BACKUP" ]]; then
      bash "$PKG/rollback.sh" "$APP" "$CODE_BACKUP" || echo 'MANUAL_CODE_ROLLBACK_REQUIRED'
    fi
  fi
}
trap recover EXIT
CODE_OUTPUT="$(bash "$PKG/install.sh" "$APP" --apply)" || { printf '%s\n' "$CODE_OUTPUT"; exit 1; }
printf '%s\n' "$CODE_OUTPUT"
CODE_BACKUP="$(printf '%s\n' "$CODE_OUTPUT" | sed -n 's/^CODE_BACKUP_PATH=//p' | tail -1)"
[[ -d "$CODE_BACKUP" ]] || { echo 'CODE_BACKUP_MISSING'; exit 2; }
CODE_INSTALLED=1
ASSETS_TOUCHED=1
rm -rf "$APP/public/build"; mv "$NEXT_BUILD" "$APP/public/build"
rm -rf "$APP/bootstrap/ssr"; mv "$NEXT_SSR" "$APP/bootstrap/ssr"
( cd "$REL" && while read -r digest path; do
  live="$APP/${path#assets/}"
  [[ -f "$live" && "$(sha256sum "$live" | cut -d' ' -f1)" == "$digest" ]] || { echo "LIVE_ASSET_SHA=FAIL $path"; exit 1; }
done < asset_hashes.txt )
bash "$PKG/verify.sh" "$APP"
"$PHP" "$APP/artisan" optimize:clear
trap - EXIT
echo 'DEPLOYMENT=PASS CLIENT=PASS SSR_FILES=PASS CLAIM_INTENT=INSTALLED'
echo "BACKUP_PATH=$BACKUP"
echo "CODE_BACKUP_PATH=$CODE_BACKUP"
echo "RELEASE_STAGE=$STAGE"
echo 'SSR_SERVICE_RESTART=MANUAL_IF_RUNNING'
echo 'NO_EVENT_OWNERSHIP_OR_TICKETING_GRANTS=YES'
